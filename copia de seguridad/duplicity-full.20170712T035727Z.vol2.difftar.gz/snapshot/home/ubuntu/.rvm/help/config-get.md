# Read ruby configuration

Usage:

    rvm config-get [<variable-name>|--all]

Displays single variable from `RbConfig::CONFIG` or all of them.
