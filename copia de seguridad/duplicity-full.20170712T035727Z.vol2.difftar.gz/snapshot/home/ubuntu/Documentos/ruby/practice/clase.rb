def menor_2 (c,a)
	if c<a
		c
	elsif a<c
	   a

	end
end

def mayor_2(c,a)
	if c>a
		c
	elsif a>c
	 a
	end

end

def comparar (c,a,tipo)
	y=mayor_2
	n=menor_2
	if t==y
		"#{y}"
	elsif t ==n
	  "#{n}"
	end

end


comparar 3, 50
comparar 3. 90
