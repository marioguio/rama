print "digite su nombre:"
name = gets.chomp

puts "hola #{name}"
