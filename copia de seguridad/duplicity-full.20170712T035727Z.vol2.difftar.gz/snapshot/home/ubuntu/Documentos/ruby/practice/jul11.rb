ascii = rand(97..122)
letra = ascii.chr
#puts letra
intentos =5
play = true
while play
  puts "adivina el codigo ascii de  #{letra} ,tiene #{intentos} "
	a = gets.chomp.to_i
  play = false if a == ascii #|| intentos == 1
  puts "subale"if a < ascii && play == true
	puts "bajele"if a > ascii && play == true
	intentos -= 1
end

if intentos >= 0
	puts ' ¬ ¬ "gano felicidades"'
else
	puts "perdedor!!"
end
