print "escriba un numero: "

number =gets.chomp.to_i

puts "la mitad de #{number} es #{number/2}"
