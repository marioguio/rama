print "Escriba su edad: "

edad = gets.chomp.to_i



puts " y en 5 años va a tener #{edad+5} años".upcase
