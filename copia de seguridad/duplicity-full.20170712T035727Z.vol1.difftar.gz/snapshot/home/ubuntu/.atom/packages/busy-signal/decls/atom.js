/* @flow */

declare module 'atom' {
  declare var Emitter: any;
  declare var Disposable: any;
  declare var CompositeDisposable: any;
}

declare var it: any;
declare var atom: any;
declare var spyOn: any;
declare var expect: any;
declare var jasmine: any;
declare var describe: any;
declare var afterEach: any;
declare var beforeEach: any;
