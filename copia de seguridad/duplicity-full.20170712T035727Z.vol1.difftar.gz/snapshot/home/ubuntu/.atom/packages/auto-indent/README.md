# auto-indent package

This package will allow you to auto-indent your current file. Use the auto-indent:apply command.
