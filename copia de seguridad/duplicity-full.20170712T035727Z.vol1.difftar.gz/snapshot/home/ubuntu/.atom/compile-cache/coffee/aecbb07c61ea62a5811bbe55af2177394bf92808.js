(function() {
  var $, _, path;

  _ = require('underscore-plus');

  $ = require('atom-space-pen-views').$;

  path = require('path');

  describe("RubyBlock", function() {
    var bottomPanels, editor, editorElement, editorView, getResultDecorations, lineNumbers, markers, ref, rubyBlockElement, workspaceElement;
    ref = [], workspaceElement = ref[0], editor = ref[1], editorView = ref[2], editorElement = ref[3], markers = ref[4], lineNumbers = ref[5], rubyBlockElement = ref[6], bottomPanels = ref[7];
    getResultDecorations = function(editor, clazz, type) {
      var decoration, decorations, i, id, len, markerId, markerIdForDecorations, ref1, resultDecorations;
      if (editor.decorationsStateForScreenRowRange != null) {
        resultDecorations = [];
        ref1 = editor.decorationsStateForScreenRowRange(0, editor.getLineCount());
        for (id in ref1) {
          decoration = ref1[id];
          if (decoration.properties["class"] === clazz && decoration.properties.type === type) {
            resultDecorations.push(decoration);
          }
        }
      } else {
        markerIdForDecorations = editor.decorationsForScreenRowRange(0, editor.getLineCount());
        resultDecorations = [];
        for (markerId in markerIdForDecorations) {
          decorations = markerIdForDecorations[markerId];
          for (i = 0, len = decorations.length; i < len; i++) {
            decoration = decorations[i];
            if (decoration.getProperties()["class"] === clazz && decoration.getProperties.type === type) {
              resultDecorations.push(decoration);
            }
          }
        }
      }
      return resultDecorations;
    };
    beforeEach(function() {
      workspaceElement = atom.views.getView(atom.workspace);
      atom.project.setPaths([path.join(__dirname, 'fixtures')]);
      waitsForPromise(function() {
        return atom.workspace.open('test.rb');
      });
      waitsForPromise(function() {
        return atom.packages.activatePackage('language-ruby');
      });
      return runs(function() {
        var activationPromise;
        jasmine.attachToDOM(workspaceElement);
        editor = atom.workspace.getActiveTextEditor();
        editorView = editor.getElement();
        return activationPromise = atom.packages.activatePackage("ruby-block").then(function(arg) {
          var findView, mainModule;
          mainModule = arg.mainModule;
          mainModule.createViews();
          return findView = mainModule.findView, mainModule;
        });
      });
    });
    describe("when cursor is on the 'end'", function() {
      describe("when highlightLineNumber option is 'true'", function() {
        beforeEach(function() {
          atom.config.set('ruby-block.highlightLineNumber', true);
          spyOn(_._, "now").andCallFake(function() {
            return window.now;
          });
          editor.setCursorBufferPosition([3, 0]);
          advanceClock(100);
          return bottomPanels = atom.workspace.getBottomPanels();
        });
        it('highlights line', function() {
          return expect(getResultDecorations(editor, 'ruby-block-highlight', 'highlight')).toHaveLength(1);
        });
        it('highlights gutter', function() {
          return expect(getResultDecorations(editor, 'ruby-block-highlight', 'line-number')).toHaveLength(1);
        });
        return it('shows view in bottom panel', function() {
          return expect(workspaceElement.querySelector('.ruby-block')).toBe(bottomPanels[0].item);
        });
      });
      return describe("when highlightLineNumber option is 'false'", function() {
        beforeEach(function() {
          atom.config.set('ruby-block.highlightLineNumber', false);
          spyOn(_._, "now").andCallFake(function() {
            return window.now;
          });
          editor.setCursorBufferPosition([3, 0]);
          advanceClock(100);
          return bottomPanels = atom.workspace.getBottomPanels();
        });
        it('highlights line', function() {
          return expect(getResultDecorations(editor, 'ruby-block-highlight', 'highlight')).toHaveLength(1);
        });
        it('highlights gutter', function() {
          return expect(getResultDecorations(editor, 'ruby-block-highlight', 'line-number')).toHaveLength(0);
        });
        return it('shows view in bottom panel', function() {
          return expect(workspaceElement.querySelector('.ruby-block')).toBe(bottomPanels[0].item);
        });
      });
    });
    return describe("when cursor is not on the 'end'", function() {
      beforeEach(function() {
        editor.setCursorBufferPosition([4, 0]);
        return advanceClock(100);
      });
      it('highlights line', function() {
        return expect(getResultDecorations(editor, 'ruby-block-highlight', 'highlight')).toHaveLength(0);
      });
      it('highlights gutter', function() {
        return expect(getResultDecorations(editor, 'ruby-block-highlight', 'line-number')).toHaveLength(0);
      });
      return it('shows view in bottom panel', function() {
        return expect(bottomPanels).toHaveLength(0);
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktYmxvY2svc3BlYy9ydWJ5LWJsb2NrLXNwZWMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxDQUFBLEdBQUksT0FBQSxDQUFRLGlCQUFSOztFQUNILElBQUssT0FBQSxDQUFRLHNCQUFSOztFQUVOLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUjs7RUFFUCxRQUFBLENBQVMsV0FBVCxFQUFzQixTQUFBO0FBQ3BCLFFBQUE7SUFBQSxNQUErRyxFQUEvRyxFQUFDLHlCQUFELEVBQW1CLGVBQW5CLEVBQTJCLG1CQUEzQixFQUF1QyxzQkFBdkMsRUFBc0QsZ0JBQXRELEVBQStELG9CQUEvRCxFQUE0RSx5QkFBNUUsRUFBOEY7SUFFOUYsb0JBQUEsR0FBdUIsU0FBQyxNQUFELEVBQVMsS0FBVCxFQUFnQixJQUFoQjtBQUNyQixVQUFBO01BQUEsSUFBRyxnREFBSDtRQUNFLGlCQUFBLEdBQW9CO0FBQ3BCO0FBQUEsYUFBQSxVQUFBOztVQUNFLElBQUcsVUFBVSxDQUFDLFVBQVUsRUFBQyxLQUFELEVBQXJCLEtBQStCLEtBQS9CLElBQXlDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBdEIsS0FBOEIsSUFBMUU7WUFDRSxpQkFBaUIsQ0FBQyxJQUFsQixDQUF1QixVQUF2QixFQURGOztBQURGLFNBRkY7T0FBQSxNQUFBO1FBTUUsc0JBQUEsR0FBeUIsTUFBTSxDQUFDLDRCQUFQLENBQW9DLENBQXBDLEVBQXVDLE1BQU0sQ0FBQyxZQUFQLENBQUEsQ0FBdkM7UUFDekIsaUJBQUEsR0FBb0I7QUFDcEIsYUFBQSxrQ0FBQTs7QUFDRSxlQUFBLDZDQUFBOztZQUNFLElBQXFDLFVBQVUsQ0FBQyxhQUFYLENBQUEsQ0FBMEIsRUFBQyxLQUFELEVBQTFCLEtBQW9DLEtBQXBDLElBQThDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBekIsS0FBaUMsSUFBcEg7Y0FBQSxpQkFBaUIsQ0FBQyxJQUFsQixDQUF1QixVQUF2QixFQUFBOztBQURGO0FBREYsU0FSRjs7YUFXQTtJQVpxQjtJQWN2QixVQUFBLENBQVcsU0FBQTtNQUNULGdCQUFBLEdBQW1CLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWCxDQUFtQixJQUFJLENBQUMsU0FBeEI7TUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFiLENBQXNCLENBQUMsSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFWLEVBQXFCLFVBQXJCLENBQUQsQ0FBdEI7TUFFQSxlQUFBLENBQWdCLFNBQUE7ZUFDZCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQWYsQ0FBb0IsU0FBcEI7TUFEYyxDQUFoQjtNQUdBLGVBQUEsQ0FBZ0IsU0FBQTtlQUNkLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZCxDQUE4QixlQUE5QjtNQURjLENBQWhCO2FBR0EsSUFBQSxDQUFLLFNBQUE7QUFDSCxZQUFBO1FBQUEsT0FBTyxDQUFDLFdBQVIsQ0FBb0IsZ0JBQXBCO1FBQ0EsTUFBQSxHQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQWYsQ0FBQTtRQUNULFVBQUEsR0FBYSxNQUFNLENBQUMsVUFBUCxDQUFBO2VBRWIsaUJBQUEsR0FBb0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFkLENBQThCLFlBQTlCLENBQTJDLENBQUMsSUFBNUMsQ0FBaUQsU0FBQyxHQUFEO0FBQ25FLGNBQUE7VUFEcUUsYUFBRDtVQUNwRSxVQUFVLENBQUMsV0FBWCxDQUFBO2lCQUNDLDhCQUFELEVBQWE7UUFGc0QsQ0FBakQ7TUFMakIsQ0FBTDtJQVZTLENBQVg7SUFtQkEsUUFBQSxDQUFTLDZCQUFULEVBQXdDLFNBQUE7TUFDdEMsUUFBQSxDQUFTLDJDQUFULEVBQXNELFNBQUE7UUFDcEQsVUFBQSxDQUFXLFNBQUE7VUFDVCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsZ0NBQWhCLEVBQWtELElBQWxEO1VBQ0EsS0FBQSxDQUFNLENBQUMsQ0FBQyxDQUFSLEVBQVcsS0FBWCxDQUFpQixDQUFDLFdBQWxCLENBQThCLFNBQUE7bUJBQUcsTUFBTSxDQUFDO1VBQVYsQ0FBOUI7VUFDQSxNQUFNLENBQUMsdUJBQVAsQ0FBK0IsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUEvQjtVQUNBLFlBQUEsQ0FBYSxHQUFiO2lCQUNBLFlBQUEsR0FBZSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWYsQ0FBQTtRQUxOLENBQVg7UUFPQSxFQUFBLENBQUcsaUJBQUgsRUFBc0IsU0FBQTtpQkFDcEIsTUFBQSxDQUFPLG9CQUFBLENBQXFCLE1BQXJCLEVBQTZCLHNCQUE3QixFQUFxRCxXQUFyRCxDQUFQLENBQXlFLENBQUMsWUFBMUUsQ0FBdUYsQ0FBdkY7UUFEb0IsQ0FBdEI7UUFHQSxFQUFBLENBQUcsbUJBQUgsRUFBd0IsU0FBQTtpQkFDdEIsTUFBQSxDQUFPLG9CQUFBLENBQXFCLE1BQXJCLEVBQTZCLHNCQUE3QixFQUFxRCxhQUFyRCxDQUFQLENBQTJFLENBQUMsWUFBNUUsQ0FBeUYsQ0FBekY7UUFEc0IsQ0FBeEI7ZUFHQSxFQUFBLENBQUcsNEJBQUgsRUFBaUMsU0FBQTtpQkFDL0IsTUFBQSxDQUFPLGdCQUFnQixDQUFDLGFBQWpCLENBQStCLGFBQS9CLENBQVAsQ0FBcUQsQ0FBQyxJQUF0RCxDQUEyRCxZQUFhLENBQUEsQ0FBQSxDQUFFLENBQUMsSUFBM0U7UUFEK0IsQ0FBakM7TUFkb0QsQ0FBdEQ7YUFpQkEsUUFBQSxDQUFTLDRDQUFULEVBQXVELFNBQUE7UUFDckQsVUFBQSxDQUFXLFNBQUE7VUFDVCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsZ0NBQWhCLEVBQWtELEtBQWxEO1VBQ0EsS0FBQSxDQUFNLENBQUMsQ0FBQyxDQUFSLEVBQVcsS0FBWCxDQUFpQixDQUFDLFdBQWxCLENBQThCLFNBQUE7bUJBQUcsTUFBTSxDQUFDO1VBQVYsQ0FBOUI7VUFDQSxNQUFNLENBQUMsdUJBQVAsQ0FBK0IsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUEvQjtVQUNBLFlBQUEsQ0FBYSxHQUFiO2lCQUNBLFlBQUEsR0FBZSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWYsQ0FBQTtRQUxOLENBQVg7UUFPQSxFQUFBLENBQUcsaUJBQUgsRUFBc0IsU0FBQTtpQkFDcEIsTUFBQSxDQUFPLG9CQUFBLENBQXFCLE1BQXJCLEVBQTZCLHNCQUE3QixFQUFxRCxXQUFyRCxDQUFQLENBQXlFLENBQUMsWUFBMUUsQ0FBdUYsQ0FBdkY7UUFEb0IsQ0FBdEI7UUFHQSxFQUFBLENBQUcsbUJBQUgsRUFBd0IsU0FBQTtpQkFDdEIsTUFBQSxDQUFPLG9CQUFBLENBQXFCLE1BQXJCLEVBQTZCLHNCQUE3QixFQUFxRCxhQUFyRCxDQUFQLENBQTJFLENBQUMsWUFBNUUsQ0FBeUYsQ0FBekY7UUFEc0IsQ0FBeEI7ZUFHQSxFQUFBLENBQUcsNEJBQUgsRUFBaUMsU0FBQTtpQkFDL0IsTUFBQSxDQUFPLGdCQUFnQixDQUFDLGFBQWpCLENBQStCLGFBQS9CLENBQVAsQ0FBcUQsQ0FBQyxJQUF0RCxDQUEyRCxZQUFhLENBQUEsQ0FBQSxDQUFFLENBQUMsSUFBM0U7UUFEK0IsQ0FBakM7TUFkcUQsQ0FBdkQ7SUFsQnNDLENBQXhDO1dBb0NBLFFBQUEsQ0FBUyxpQ0FBVCxFQUE0QyxTQUFBO01BQzFDLFVBQUEsQ0FBVyxTQUFBO1FBQ1QsTUFBTSxDQUFDLHVCQUFQLENBQStCLENBQUMsQ0FBRCxFQUFJLENBQUosQ0FBL0I7ZUFDQSxZQUFBLENBQWEsR0FBYjtNQUZTLENBQVg7TUFJQSxFQUFBLENBQUcsaUJBQUgsRUFBc0IsU0FBQTtlQUNwQixNQUFBLENBQU8sb0JBQUEsQ0FBcUIsTUFBckIsRUFBNkIsc0JBQTdCLEVBQXFELFdBQXJELENBQVAsQ0FBeUUsQ0FBQyxZQUExRSxDQUF1RixDQUF2RjtNQURvQixDQUF0QjtNQUdBLEVBQUEsQ0FBRyxtQkFBSCxFQUF3QixTQUFBO2VBQ3RCLE1BQUEsQ0FBTyxvQkFBQSxDQUFxQixNQUFyQixFQUE2QixzQkFBN0IsRUFBcUQsYUFBckQsQ0FBUCxDQUEyRSxDQUFDLFlBQTVFLENBQXlGLENBQXpGO01BRHNCLENBQXhCO2FBR0EsRUFBQSxDQUFHLDRCQUFILEVBQWlDLFNBQUE7ZUFDL0IsTUFBQSxDQUFPLFlBQVAsQ0FBb0IsQ0FBQyxZQUFyQixDQUFrQyxDQUFsQztNQUQrQixDQUFqQztJQVgwQyxDQUE1QztFQXhFb0IsQ0FBdEI7QUFMQSIsInNvdXJjZXNDb250ZW50IjpbIl8gPSByZXF1aXJlICd1bmRlcnNjb3JlLXBsdXMnXG57JH0gPSByZXF1aXJlICdhdG9tLXNwYWNlLXBlbi12aWV3cydcblxucGF0aCA9IHJlcXVpcmUgJ3BhdGgnXG5cbmRlc2NyaWJlIFwiUnVieUJsb2NrXCIsIC0+XG4gIFt3b3Jrc3BhY2VFbGVtZW50LCBlZGl0b3IsIGVkaXRvclZpZXcsIGVkaXRvckVsZW1lbnQsIG1hcmtlcnMsIGxpbmVOdW1iZXJzLCBydWJ5QmxvY2tFbGVtZW50LCBib3R0b21QYW5lbHNdID0gIFtdXG5cbiAgZ2V0UmVzdWx0RGVjb3JhdGlvbnMgPSAoZWRpdG9yLCBjbGF6eiwgdHlwZSkgLT5cbiAgICBpZiBlZGl0b3IuZGVjb3JhdGlvbnNTdGF0ZUZvclNjcmVlblJvd1JhbmdlP1xuICAgICAgcmVzdWx0RGVjb3JhdGlvbnMgPSBbXVxuICAgICAgZm9yIGlkLCBkZWNvcmF0aW9uIG9mIGVkaXRvci5kZWNvcmF0aW9uc1N0YXRlRm9yU2NyZWVuUm93UmFuZ2UoMCwgZWRpdG9yLmdldExpbmVDb3VudCgpKVxuICAgICAgICBpZiBkZWNvcmF0aW9uLnByb3BlcnRpZXMuY2xhc3MgaXMgY2xhenogYW5kIGRlY29yYXRpb24ucHJvcGVydGllcy50eXBlIGlzIHR5cGVcbiAgICAgICAgICByZXN1bHREZWNvcmF0aW9ucy5wdXNoKGRlY29yYXRpb24pXG4gICAgZWxzZVxuICAgICAgbWFya2VySWRGb3JEZWNvcmF0aW9ucyA9IGVkaXRvci5kZWNvcmF0aW9uc0ZvclNjcmVlblJvd1JhbmdlKDAsIGVkaXRvci5nZXRMaW5lQ291bnQoKSlcbiAgICAgIHJlc3VsdERlY29yYXRpb25zID0gW11cbiAgICAgIGZvciBtYXJrZXJJZCwgZGVjb3JhdGlvbnMgb2YgbWFya2VySWRGb3JEZWNvcmF0aW9uc1xuICAgICAgICBmb3IgZGVjb3JhdGlvbiBpbiBkZWNvcmF0aW9uc1xuICAgICAgICAgIHJlc3VsdERlY29yYXRpb25zLnB1c2ggZGVjb3JhdGlvbiBpZiBkZWNvcmF0aW9uLmdldFByb3BlcnRpZXMoKS5jbGFzcyBpcyBjbGF6eiBhbmQgZGVjb3JhdGlvbi5nZXRQcm9wZXJ0aWVzLnR5cGUgaXMgdHlwZVxuICAgIHJlc3VsdERlY29yYXRpb25zXG4gICAgXG4gIGJlZm9yZUVhY2ggLT5cbiAgICB3b3Jrc3BhY2VFbGVtZW50ID0gYXRvbS52aWV3cy5nZXRWaWV3KGF0b20ud29ya3NwYWNlKVxuICAgIGF0b20ucHJvamVjdC5zZXRQYXRocyhbcGF0aC5qb2luKF9fZGlybmFtZSwgJ2ZpeHR1cmVzJyldKVxuXG4gICAgd2FpdHNGb3JQcm9taXNlIC0+IFxuICAgICAgYXRvbS53b3Jrc3BhY2Uub3BlbigndGVzdC5yYicpXG4gICAgICBcbiAgICB3YWl0c0ZvclByb21pc2UgLT4gXG4gICAgICBhdG9tLnBhY2thZ2VzLmFjdGl2YXRlUGFja2FnZSgnbGFuZ3VhZ2UtcnVieScpXG5cbiAgICBydW5zIC0+XG4gICAgICBqYXNtaW5lLmF0dGFjaFRvRE9NKHdvcmtzcGFjZUVsZW1lbnQpXG4gICAgICBlZGl0b3IgPSBhdG9tLndvcmtzcGFjZS5nZXRBY3RpdmVUZXh0RWRpdG9yKClcbiAgICAgIGVkaXRvclZpZXcgPSBlZGl0b3IuZ2V0RWxlbWVudCgpXG5cbiAgICAgIGFjdGl2YXRpb25Qcm9taXNlID0gYXRvbS5wYWNrYWdlcy5hY3RpdmF0ZVBhY2thZ2UoXCJydWJ5LWJsb2NrXCIpLnRoZW4gKHttYWluTW9kdWxlfSkgLT5cbiAgICAgICAgbWFpbk1vZHVsZS5jcmVhdGVWaWV3cygpXG4gICAgICAgIHtmaW5kVmlld30gPSBtYWluTW9kdWxlXG5cbiAgZGVzY3JpYmUgXCJ3aGVuIGN1cnNvciBpcyBvbiB0aGUgJ2VuZCdcIiwgLT5cbiAgICBkZXNjcmliZSBcIndoZW4gaGlnaGxpZ2h0TGluZU51bWJlciBvcHRpb24gaXMgJ3RydWUnXCIsIC0+XG4gICAgICBiZWZvcmVFYWNoIC0+XG4gICAgICAgIGF0b20uY29uZmlnLnNldCAncnVieS1ibG9jay5oaWdobGlnaHRMaW5lTnVtYmVyJywgdHJ1ZVxuICAgICAgICBzcHlPbihfLl8sIFwibm93XCIpLmFuZENhbGxGYWtlIC0+IHdpbmRvdy5ub3dcbiAgICAgICAgZWRpdG9yLnNldEN1cnNvckJ1ZmZlclBvc2l0aW9uIFszLCAwXVxuICAgICAgICBhZHZhbmNlQ2xvY2soMTAwKVxuICAgICAgICBib3R0b21QYW5lbHMgPSBhdG9tLndvcmtzcGFjZS5nZXRCb3R0b21QYW5lbHMoKVxuICAgICAgICBcbiAgICAgIGl0ICdoaWdobGlnaHRzIGxpbmUnLCAtPlxuICAgICAgICBleHBlY3QoZ2V0UmVzdWx0RGVjb3JhdGlvbnMoZWRpdG9yLCAncnVieS1ibG9jay1oaWdobGlnaHQnLCAnaGlnaGxpZ2h0JykpLnRvSGF2ZUxlbmd0aCAxXG4gICAgICAgIFxuICAgICAgaXQgJ2hpZ2hsaWdodHMgZ3V0dGVyJywgLT5cbiAgICAgICAgZXhwZWN0KGdldFJlc3VsdERlY29yYXRpb25zKGVkaXRvciwgJ3J1YnktYmxvY2staGlnaGxpZ2h0JywgJ2xpbmUtbnVtYmVyJykpLnRvSGF2ZUxlbmd0aCAxXG4gICAgICAgIFxuICAgICAgaXQgJ3Nob3dzIHZpZXcgaW4gYm90dG9tIHBhbmVsJywgLT5cbiAgICAgICAgZXhwZWN0KHdvcmtzcGFjZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLnJ1YnktYmxvY2snKSkudG9CZSBib3R0b21QYW5lbHNbMF0uaXRlbVxuXG4gICAgZGVzY3JpYmUgXCJ3aGVuIGhpZ2hsaWdodExpbmVOdW1iZXIgb3B0aW9uIGlzICdmYWxzZSdcIiwgLT5cbiAgICAgIGJlZm9yZUVhY2ggLT5cbiAgICAgICAgYXRvbS5jb25maWcuc2V0ICdydWJ5LWJsb2NrLmhpZ2hsaWdodExpbmVOdW1iZXInLCBmYWxzZVxuICAgICAgICBzcHlPbihfLl8sIFwibm93XCIpLmFuZENhbGxGYWtlIC0+IHdpbmRvdy5ub3dcbiAgICAgICAgZWRpdG9yLnNldEN1cnNvckJ1ZmZlclBvc2l0aW9uIFszLCAwXVxuICAgICAgICBhZHZhbmNlQ2xvY2soMTAwKVxuICAgICAgICBib3R0b21QYW5lbHMgPSBhdG9tLndvcmtzcGFjZS5nZXRCb3R0b21QYW5lbHMoKVxuICAgICAgICBcbiAgICAgIGl0ICdoaWdobGlnaHRzIGxpbmUnLCAtPlxuICAgICAgICBleHBlY3QoZ2V0UmVzdWx0RGVjb3JhdGlvbnMoZWRpdG9yLCAncnVieS1ibG9jay1oaWdobGlnaHQnLCAnaGlnaGxpZ2h0JykpLnRvSGF2ZUxlbmd0aCAxXG5cbiAgICAgIGl0ICdoaWdobGlnaHRzIGd1dHRlcicsIC0+XG4gICAgICAgIGV4cGVjdChnZXRSZXN1bHREZWNvcmF0aW9ucyhlZGl0b3IsICdydWJ5LWJsb2NrLWhpZ2hsaWdodCcsICdsaW5lLW51bWJlcicpKS50b0hhdmVMZW5ndGggMFxuXG4gICAgICBpdCAnc2hvd3MgdmlldyBpbiBib3R0b20gcGFuZWwnLCAtPlxuICAgICAgICBleHBlY3Qod29ya3NwYWNlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcucnVieS1ibG9jaycpKS50b0JlIGJvdHRvbVBhbmVsc1swXS5pdGVtXG5cblxuICBkZXNjcmliZSBcIndoZW4gY3Vyc29yIGlzIG5vdCBvbiB0aGUgJ2VuZCdcIiwgLT5cbiAgICBiZWZvcmVFYWNoIC0+XG4gICAgICBlZGl0b3Iuc2V0Q3Vyc29yQnVmZmVyUG9zaXRpb24gWzQsIDBdXG4gICAgICBhZHZhbmNlQ2xvY2soMTAwKVxuXG4gICAgaXQgJ2hpZ2hsaWdodHMgbGluZScsIC0+XG4gICAgICBleHBlY3QoZ2V0UmVzdWx0RGVjb3JhdGlvbnMoZWRpdG9yLCAncnVieS1ibG9jay1oaWdobGlnaHQnLCAnaGlnaGxpZ2h0JykpLnRvSGF2ZUxlbmd0aCAwXG5cbiAgICBpdCAnaGlnaGxpZ2h0cyBndXR0ZXInLCAtPlxuICAgICAgZXhwZWN0KGdldFJlc3VsdERlY29yYXRpb25zKGVkaXRvciwgJ3J1YnktYmxvY2staGlnaGxpZ2h0JywgJ2xpbmUtbnVtYmVyJykpLnRvSGF2ZUxlbmd0aCAwXG5cbiAgICBpdCAnc2hvd3MgdmlldyBpbiBib3R0b20gcGFuZWwnLCAtPlxuICAgICAgZXhwZWN0KGJvdHRvbVBhbmVscykudG9IYXZlTGVuZ3RoIDBcbiAgICAgIFxuIl19
