(function() {
  var execSync, gemHome, getExecPathFromGemEnv, platformHome;

  execSync = require('child_process').execSync;

  platformHome = process.env[process.platform === 'win32' ? 'USERPROFILE' : 'HOME'];

  getExecPathFromGemEnv = function() {
    var line, stdout;
    stdout = execSync('gem environment');
    line = stdout.toString().split(/\r?\n/).find(function(l) {
      return ~l.indexOf('EXECUTABLE DIRECTORY');
    });
    if (line) {
      return line.slice(line.indexOf(': ') + 2);
    } else {
      return void 0;
    }
  };

  gemHome = function() {
    var ref;
    if (process.env.GEM_HOME) {
      return process.env.GEM_HOME + "/bin";
    } else {
      return (ref = getExecPathFromGemEnv()) != null ? ref : platformHome + "/.gem/ruby/2.3.0";
    }
  };

  module.exports = gemHome();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1ydWJ5L2xpYi9nZW0taG9tZS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLFFBQUEsR0FBVyxPQUFBLENBQVEsZUFBUixDQUF3QixDQUFDOztFQUVwQyxZQUFBLEdBQWUsT0FBTyxDQUFDLEdBQUksQ0FBRyxPQUFPLENBQUMsUUFBUixLQUFvQixPQUF2QixHQUFvQyxhQUFwQyxHQUF1RCxNQUF2RDs7RUFFM0IscUJBQUEsR0FBd0IsU0FBQTtBQUN0QixRQUFBO0lBQUEsTUFBQSxHQUFTLFFBQUEsQ0FBUyxpQkFBVDtJQUVULElBQUEsR0FBTyxNQUFNLENBQUMsUUFBUCxDQUFBLENBQWlCLENBQUMsS0FBbEIsQ0FBd0IsT0FBeEIsQ0FDRSxDQUFDLElBREgsQ0FDUSxTQUFDLENBQUQ7YUFBTyxDQUFDLENBQUMsQ0FBQyxPQUFGLENBQVUsc0JBQVY7SUFBUixDQURSO0lBRVAsSUFBRyxJQUFIO2FBQ0UsSUFBSywrQkFEUDtLQUFBLE1BQUE7YUFHRSxPQUhGOztFQUxzQjs7RUFVeEIsT0FBQSxHQUFVLFNBQUE7QUFDUixRQUFBO0lBQUEsSUFBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQWY7YUFDSyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQWIsR0FBc0IsT0FEMUI7S0FBQSxNQUFBOzZEQUcrQixZQUFELEdBQWMsbUJBSDVDOztFQURROztFQU1WLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLE9BQUEsQ0FBQTtBQXBCakIiLCJzb3VyY2VzQ29udGVudCI6WyJleGVjU3luYyA9IHJlcXVpcmUoJ2NoaWxkX3Byb2Nlc3MnKS5leGVjU3luY1xuXG5wbGF0Zm9ybUhvbWUgPSBwcm9jZXNzLmVudltpZiBwcm9jZXNzLnBsYXRmb3JtIGlzICd3aW4zMicgdGhlbiAnVVNFUlBST0ZJTEUnIGVsc2UgJ0hPTUUnXVxuXG5nZXRFeGVjUGF0aEZyb21HZW1FbnYgPSAtPlxuICBzdGRvdXQgPSBleGVjU3luYyAnZ2VtIGVudmlyb25tZW50J1xuXG4gIGxpbmUgPSBzdGRvdXQudG9TdHJpbmcoKS5zcGxpdCgvXFxyP1xcbi8pXG4gICAgICAgICAgIC5maW5kKChsKSAtPiB+bC5pbmRleE9mKCdFWEVDVVRBQkxFIERJUkVDVE9SWScpKVxuICBpZiBsaW5lXG4gICAgbGluZVtsaW5lLmluZGV4T2YoJzogJykgKyAyLi5dXG4gIGVsc2VcbiAgICB1bmRlZmluZWRcblxuZ2VtSG9tZSA9IC0+XG4gIGlmIHByb2Nlc3MuZW52LkdFTV9IT01FXG4gICAgXCIje3Byb2Nlc3MuZW52LkdFTV9IT01FfS9iaW5cIlxuICBlbHNlXG4gICAgZ2V0RXhlY1BhdGhGcm9tR2VtRW52KCkgPyBcIiN7cGxhdGZvcm1Ib21lfS8uZ2VtL3J1YnkvMi4zLjBcIlxuXG5tb2R1bGUuZXhwb3J0cyA9IGdlbUhvbWUoKVxuIl19
