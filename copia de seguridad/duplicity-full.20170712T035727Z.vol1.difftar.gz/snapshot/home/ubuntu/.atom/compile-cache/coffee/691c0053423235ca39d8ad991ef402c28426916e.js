(function() {
  var Utility;

  module.exports = Utility = (function() {
    function Utility() {}

    Utility.prototype.saveFile = function() {
      if (this.filePath()) {
        return this.editor().save();
      }
    };

    Utility.prototype.filePath = function() {
      return this.editor() && this.editor().buffer && this.editor().buffer.file && this.editor().buffer.file.path;
    };

    Utility.prototype.editor = function() {
      return atom.workspace.getActiveTextEditor();
    };

    return Utility;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9saWIvdXRpbGl0eS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQ007OztzQkFDSixRQUFBLEdBQVUsU0FBQTtNQUNSLElBQW9CLElBQUMsQ0FBQSxRQUFELENBQUEsQ0FBcEI7ZUFBQSxJQUFDLENBQUEsTUFBRCxDQUFBLENBQVMsQ0FBQyxJQUFWLENBQUEsRUFBQTs7SUFEUTs7c0JBR1YsUUFBQSxHQUFVLFNBQUE7YUFDUixJQUFDLENBQUEsTUFBRCxDQUFBLENBQUEsSUFDRSxJQUFDLENBQUEsTUFBRCxDQUFBLENBQVMsQ0FBQyxNQURaLElBRUUsSUFBQyxDQUFBLE1BQUQsQ0FBQSxDQUFTLENBQUMsTUFBTSxDQUFDLElBRm5CLElBR0UsSUFBQyxDQUFBLE1BQUQsQ0FBQSxDQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztJQUpoQjs7c0JBTVYsTUFBQSxHQUFRLFNBQUE7YUFDTixJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFmLENBQUE7SUFETTs7Ozs7QUFYViIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID1cbmNsYXNzIFV0aWxpdHlcbiAgc2F2ZUZpbGU6IC0+XG4gICAgQGVkaXRvcigpLnNhdmUoKSBpZiBAZmlsZVBhdGgoKVxuXG4gIGZpbGVQYXRoOiAtPlxuICAgIEBlZGl0b3IoKSBhbmRcbiAgICAgIEBlZGl0b3IoKS5idWZmZXIgYW5kXG4gICAgICBAZWRpdG9yKCkuYnVmZmVyLmZpbGUgYW5kXG4gICAgICBAZWRpdG9yKCkuYnVmZmVyLmZpbGUucGF0aFxuXG4gIGVkaXRvcjogLT5cbiAgICBhdG9tLndvcmtzcGFjZS5nZXRBY3RpdmVUZXh0RWRpdG9yKClcbiJdfQ==
