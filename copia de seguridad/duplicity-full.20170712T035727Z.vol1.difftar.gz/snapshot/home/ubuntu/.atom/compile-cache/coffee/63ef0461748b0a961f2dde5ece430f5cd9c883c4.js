(function() {
  var Command, SourceInfo, TestRunner;

  TestRunner = require('../lib/test-runner');

  SourceInfo = require('../lib/source-info');

  Command = require('../lib/command');

  describe("TestRunner", function() {
    beforeEach(function() {
      this.mockRun = jasmine.createSpy('run');
      this.mockClick = jasmine.createSpy('click');
      this.mockGetTerminalViews = [
        {
          closeBtn: {
            click: this.mockClick
          }
        }
      ];
      this.mockTerminal = {
        run: this.mockRun,
        getTerminalViews: (function(_this) {
          return function() {
            return _this.mockGetTerminalViews;
          };
        })(this)
      };
      this.testRunnerParams = {};
      spyOn(SourceInfo.prototype, 'activeFile').andReturn('fooTestFile');
      spyOn(SourceInfo.prototype, 'currentLine').andReturn(100);
      spyOn(SourceInfo.prototype, 'minitestRegExp').andReturn('test foo');
      spyOn(Command, 'testFileCommand').andReturn('fooTestCommand {relative_path}');
      return spyOn(Command, 'testSingleCommand').andReturn('fooTestCommand {relative_path}:{line_number}');
    });
    return describe("::run", function() {
      it("constructs a single-test command when testScope is 'single'", function() {
        var runner;
        this.testRunnerParams.testScope = "single";
        runner = new TestRunner(this.testRunnerParams, this.mockTerminal);
        runner.run();
        expect(this.mockRun).toHaveBeenCalledWith(["fooTestCommand fooTestFile:100"]);
        return expect(this.mockClick).not.toHaveBeenCalled();
      });
      it("constructs a single-minitest command when testScope is 'single'", function() {
        var runner;
        Command.testSingleCommand.andReturn('fooTestCommand {relative_path} -n \"/{regex}/\"');
        this.testRunnerParams.testScope = "single";
        runner = new TestRunner(this.testRunnerParams, this.mockTerminal);
        runner.run();
        return expect(this.mockRun).toHaveBeenCalledWith(["fooTestCommand fooTestFile -n \"/test foo/\""]);
      });
      return it("closes the previous terminal used for testing", function() {
        var runner;
        this.testRunnerParams.testScope = "single";
        runner = new TestRunner(this.testRunnerParams, this.mockTerminal);
        runner.run();
        runner = new TestRunner(this.testRunnerParams, this.mockTerminal);
        runner.run();
        return expect(this.mockClick).toHaveBeenCalled();
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9zcGVjL3Rlc3QtcnVubmVyLXNwZWMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxVQUFBLEdBQWEsT0FBQSxDQUFRLG9CQUFSOztFQUNiLFVBQUEsR0FBYSxPQUFBLENBQVEsb0JBQVI7O0VBQ2IsT0FBQSxHQUFVLE9BQUEsQ0FBUSxnQkFBUjs7RUFFVixRQUFBLENBQVMsWUFBVCxFQUF1QixTQUFBO0lBRXJCLFVBQUEsQ0FBVyxTQUFBO01BQ1QsSUFBQyxDQUFBLE9BQUQsR0FBVyxPQUFPLENBQUMsU0FBUixDQUFrQixLQUFsQjtNQUNYLElBQUMsQ0FBQSxTQUFELEdBQWEsT0FBTyxDQUFDLFNBQVIsQ0FBa0IsT0FBbEI7TUFDYixJQUFDLENBQUEsb0JBQUQsR0FBd0I7UUFBRTtVQUFFLFFBQUEsRUFBVTtZQUFFLEtBQUEsRUFBTyxJQUFDLENBQUEsU0FBVjtXQUFaO1NBQUY7O01BQ3hCLElBQUMsQ0FBQSxZQUFELEdBQWdCO1FBQ2QsR0FBQSxFQUFLLElBQUMsQ0FBQSxPQURRO1FBQ0MsZ0JBQUEsRUFBa0IsQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQTttQkFBRyxLQUFDLENBQUE7VUFBSjtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEbkI7O01BR2hCLElBQUMsQ0FBQSxnQkFBRCxHQUFvQjtNQUVwQixLQUFBLENBQU0sVUFBVSxDQUFDLFNBQWpCLEVBQTRCLFlBQTVCLENBQXlDLENBQUMsU0FBMUMsQ0FBb0QsYUFBcEQ7TUFDQSxLQUFBLENBQU0sVUFBVSxDQUFDLFNBQWpCLEVBQTRCLGFBQTVCLENBQTBDLENBQUMsU0FBM0MsQ0FBcUQsR0FBckQ7TUFDQSxLQUFBLENBQU0sVUFBVSxDQUFDLFNBQWpCLEVBQTRCLGdCQUE1QixDQUE2QyxDQUFDLFNBQTlDLENBQXdELFVBQXhEO01BQ0EsS0FBQSxDQUFNLE9BQU4sRUFBZSxpQkFBZixDQUFpQyxDQUFDLFNBQWxDLENBQTRDLGdDQUE1QzthQUNBLEtBQUEsQ0FBTSxPQUFOLEVBQWUsbUJBQWYsQ0FBbUMsQ0FBQyxTQUFwQyxDQUE4Qyw4Q0FBOUM7SUFiUyxDQUFYO1dBZUEsUUFBQSxDQUFTLE9BQVQsRUFBa0IsU0FBQTtNQUNoQixFQUFBLENBQUcsNkRBQUgsRUFBa0UsU0FBQTtBQUNoRSxZQUFBO1FBQUEsSUFBQyxDQUFBLGdCQUFnQixDQUFDLFNBQWxCLEdBQThCO1FBQzlCLE1BQUEsR0FBYSxJQUFBLFVBQUEsQ0FBVyxJQUFDLENBQUEsZ0JBQVosRUFBOEIsSUFBQyxDQUFBLFlBQS9CO1FBQ2IsTUFBTSxDQUFDLEdBQVAsQ0FBQTtRQUNBLE1BQUEsQ0FBTyxJQUFDLENBQUEsT0FBUixDQUFnQixDQUFDLG9CQUFqQixDQUFzQyxDQUFDLGdDQUFELENBQXRDO2VBQ0EsTUFBQSxDQUFPLElBQUMsQ0FBQSxTQUFSLENBQWtCLENBQUMsR0FBRyxDQUFDLGdCQUF2QixDQUFBO01BTGdFLENBQWxFO01BT0EsRUFBQSxDQUFHLGlFQUFILEVBQXNFLFNBQUE7QUFDcEUsWUFBQTtRQUFBLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxTQUExQixDQUFvQyxpREFBcEM7UUFDQSxJQUFDLENBQUEsZ0JBQWdCLENBQUMsU0FBbEIsR0FBOEI7UUFDOUIsTUFBQSxHQUFhLElBQUEsVUFBQSxDQUFXLElBQUMsQ0FBQSxnQkFBWixFQUE4QixJQUFDLENBQUEsWUFBL0I7UUFDYixNQUFNLENBQUMsR0FBUCxDQUFBO2VBQ0EsTUFBQSxDQUFPLElBQUMsQ0FBQSxPQUFSLENBQWdCLENBQUMsb0JBQWpCLENBQXNDLENBQUMsOENBQUQsQ0FBdEM7TUFMb0UsQ0FBdEU7YUFPQSxFQUFBLENBQUcsK0NBQUgsRUFBb0QsU0FBQTtBQUNsRCxZQUFBO1FBQUEsSUFBQyxDQUFBLGdCQUFnQixDQUFDLFNBQWxCLEdBQThCO1FBQzlCLE1BQUEsR0FBYSxJQUFBLFVBQUEsQ0FBVyxJQUFDLENBQUEsZ0JBQVosRUFBOEIsSUFBQyxDQUFBLFlBQS9CO1FBQ2IsTUFBTSxDQUFDLEdBQVAsQ0FBQTtRQUNBLE1BQUEsR0FBYSxJQUFBLFVBQUEsQ0FBVyxJQUFDLENBQUEsZ0JBQVosRUFBOEIsSUFBQyxDQUFBLFlBQS9CO1FBQ2IsTUFBTSxDQUFDLEdBQVAsQ0FBQTtlQUNBLE1BQUEsQ0FBTyxJQUFDLENBQUEsU0FBUixDQUFrQixDQUFDLGdCQUFuQixDQUFBO01BTmtELENBQXBEO0lBZmdCLENBQWxCO0VBakJxQixDQUF2QjtBQUpBIiwic291cmNlc0NvbnRlbnQiOlsiVGVzdFJ1bm5lciA9IHJlcXVpcmUgJy4uL2xpYi90ZXN0LXJ1bm5lcidcblNvdXJjZUluZm8gPSByZXF1aXJlICcuLi9saWIvc291cmNlLWluZm8nXG5Db21tYW5kID0gcmVxdWlyZSAnLi4vbGliL2NvbW1hbmQnXG5cbmRlc2NyaWJlIFwiVGVzdFJ1bm5lclwiLCAtPlxuXG4gIGJlZm9yZUVhY2ggLT5cbiAgICBAbW9ja1J1biA9IGphc21pbmUuY3JlYXRlU3B5KCdydW4nKVxuICAgIEBtb2NrQ2xpY2sgPSBqYXNtaW5lLmNyZWF0ZVNweSgnY2xpY2snKVxuICAgIEBtb2NrR2V0VGVybWluYWxWaWV3cyA9IFsgeyBjbG9zZUJ0bjogeyBjbGljazogQG1vY2tDbGljayB9IH0gXVxuICAgIEBtb2NrVGVybWluYWwgPSB7XG4gICAgICBydW46IEBtb2NrUnVuLCBnZXRUZXJtaW5hbFZpZXdzOiA9PiBAbW9ja0dldFRlcm1pbmFsVmlld3NcbiAgICB9XG4gICAgQHRlc3RSdW5uZXJQYXJhbXMgPSB7fVxuXG4gICAgc3B5T24oU291cmNlSW5mby5wcm90b3R5cGUsICdhY3RpdmVGaWxlJykuYW5kUmV0dXJuKCdmb29UZXN0RmlsZScpXG4gICAgc3B5T24oU291cmNlSW5mby5wcm90b3R5cGUsICdjdXJyZW50TGluZScpLmFuZFJldHVybigxMDApXG4gICAgc3B5T24oU291cmNlSW5mby5wcm90b3R5cGUsICdtaW5pdGVzdFJlZ0V4cCcpLmFuZFJldHVybigndGVzdCBmb28nKVxuICAgIHNweU9uKENvbW1hbmQsICd0ZXN0RmlsZUNvbW1hbmQnKS5hbmRSZXR1cm4oJ2Zvb1Rlc3RDb21tYW5kIHtyZWxhdGl2ZV9wYXRofScpXG4gICAgc3B5T24oQ29tbWFuZCwgJ3Rlc3RTaW5nbGVDb21tYW5kJykuYW5kUmV0dXJuKCdmb29UZXN0Q29tbWFuZCB7cmVsYXRpdmVfcGF0aH06e2xpbmVfbnVtYmVyfScpXG5cbiAgZGVzY3JpYmUgXCI6OnJ1blwiLCAtPlxuICAgIGl0IFwiY29uc3RydWN0cyBhIHNpbmdsZS10ZXN0IGNvbW1hbmQgd2hlbiB0ZXN0U2NvcGUgaXMgJ3NpbmdsZSdcIiwgLT5cbiAgICAgIEB0ZXN0UnVubmVyUGFyYW1zLnRlc3RTY29wZSA9IFwic2luZ2xlXCJcbiAgICAgIHJ1bm5lciA9IG5ldyBUZXN0UnVubmVyKEB0ZXN0UnVubmVyUGFyYW1zLCBAbW9ja1Rlcm1pbmFsKVxuICAgICAgcnVubmVyLnJ1bigpXG4gICAgICBleHBlY3QoQG1vY2tSdW4pLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFtcImZvb1Rlc3RDb21tYW5kIGZvb1Rlc3RGaWxlOjEwMFwiXSlcbiAgICAgIGV4cGVjdChAbW9ja0NsaWNrKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpXG5cbiAgICBpdCBcImNvbnN0cnVjdHMgYSBzaW5nbGUtbWluaXRlc3QgY29tbWFuZCB3aGVuIHRlc3RTY29wZSBpcyAnc2luZ2xlJ1wiLCAtPlxuICAgICAgQ29tbWFuZC50ZXN0U2luZ2xlQ29tbWFuZC5hbmRSZXR1cm4oJ2Zvb1Rlc3RDb21tYW5kIHtyZWxhdGl2ZV9wYXRofSAtbiBcXFwiL3tyZWdleH0vXFxcIicpXG4gICAgICBAdGVzdFJ1bm5lclBhcmFtcy50ZXN0U2NvcGUgPSBcInNpbmdsZVwiXG4gICAgICBydW5uZXIgPSBuZXcgVGVzdFJ1bm5lcihAdGVzdFJ1bm5lclBhcmFtcywgQG1vY2tUZXJtaW5hbClcbiAgICAgIHJ1bm5lci5ydW4oKVxuICAgICAgZXhwZWN0KEBtb2NrUnVuKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChbXCJmb29UZXN0Q29tbWFuZCBmb29UZXN0RmlsZSAtbiBcXFwiL3Rlc3QgZm9vL1xcXCJcIl0pXG5cbiAgICBpdCBcImNsb3NlcyB0aGUgcHJldmlvdXMgdGVybWluYWwgdXNlZCBmb3IgdGVzdGluZ1wiLCAtPlxuICAgICAgQHRlc3RSdW5uZXJQYXJhbXMudGVzdFNjb3BlID0gXCJzaW5nbGVcIlxuICAgICAgcnVubmVyID0gbmV3IFRlc3RSdW5uZXIoQHRlc3RSdW5uZXJQYXJhbXMsIEBtb2NrVGVybWluYWwpXG4gICAgICBydW5uZXIucnVuKClcbiAgICAgIHJ1bm5lciA9IG5ldyBUZXN0UnVubmVyKEB0ZXN0UnVubmVyUGFyYW1zLCBAbW9ja1Rlcm1pbmFsKVxuICAgICAgcnVubmVyLnJ1bigpXG4gICAgICBleHBlY3QoQG1vY2tDbGljaykudG9IYXZlQmVlbkNhbGxlZCgpXG4iXX0=
