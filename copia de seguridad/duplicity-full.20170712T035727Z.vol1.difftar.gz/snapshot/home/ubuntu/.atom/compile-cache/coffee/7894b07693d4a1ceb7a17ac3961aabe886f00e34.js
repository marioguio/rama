(function() {
  var RubyTestView;

  RubyTestView = require('./ruby-test-view');

  module.exports = {
    config: {
      minitestAllCommand: {
        title: "Minitest command: Run all tests",
        type: 'string',
        "default": "ruby -I test test"
      },
      minitestFileCommand: {
        title: "Minitest command: Run test file",
        type: 'string',
        "default": "ruby -I test {relative_path}"
      },
      minitestSingleCommand: {
        title: "Minitest command: Run current test",
        type: 'string',
        "default": "ruby -I test {relative_path} -n \"/{regex}/\""
      },
      testAllCommand: {
        title: "Ruby Test command: Run all tests",
        type: 'string',
        "default": "ruby -I test test"
      },
      testFileCommand: {
        title: "Ruby Test command: Run test in file",
        type: 'string',
        "default": "ruby -I test {relative_path}"
      },
      testSingleCommand: {
        title: "Ruby Test command: Run test at line number",
        type: 'string',
        "default": "ruby -I test {relative_path}:{line_number}"
      },
      rspecAllCommand: {
        title: "RSpec command: run all specs",
        type: 'string',
        "default": "rspec --tty spec"
      },
      rspecFileCommand: {
        title: "RSpec command: run spec file",
        type: 'string',
        "default": "rspec --tty {relative_path}"
      },
      rspecSingleCommand: {
        title: "RSpec command: run spec at current line",
        type: 'string',
        "default": "rspec --tty {relative_path}:{line_number}"
      },
      cucumberAllCommand: {
        title: "Cucumber command: Run all features",
        type: 'string',
        "default": "cucumber --color features"
      },
      cucumberFileCommand: {
        title: "Cucumber command: Run features file",
        type: 'string',
        "default": "cucumber --color {relative_path}"
      },
      cucumberSingleCommand: {
        title: "Cucumber command: Run features at current line",
        type: 'string',
        "default": "cucumber --color {relative_path}:{line_number}"
      },
      specFramework: {
        type: 'string',
        "default": '',
        "enum": ['', 'rspec', 'minitest'],
        description: 'RSpec and Minitest spec files look very similar to each other, and ruby-test often can\'t tell them apart. Choose your preferred *_spec.rb framework.'
      },
      testFramework: {
        type: 'string',
        "default": '',
        "enum": ['', 'minitest', 'test'],
        description: 'Minitest test files and Test::Unit files look very similar to each other, and ruby-test often can\'t tell them apart. Choose your preferred *_test.rb framework.'
      }
    },
    rubyTestView: null,
    activate: function(state) {
      this.state = state;
      return require('atom-package-deps').install('ruby-test');
    },
    consumeRunInTerminal: function(runInTerminalProvider) {
      return this.rubyTestView = new RubyTestView(this.state.rubyTestViewState, runInTerminalProvider);
    },
    deactivate: function() {
      return this.rubyTestView.destroy();
    },
    serialize: function() {
      if (this.rubyTestView) {
        return {
          rubyTestViewState: this.rubyTestView.serialize()
        };
      }
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9saWIvcnVieS10ZXN0LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsWUFBQSxHQUFlLE9BQUEsQ0FBUSxrQkFBUjs7RUFFZixNQUFNLENBQUMsT0FBUCxHQUNFO0lBQUEsTUFBQSxFQUNFO01BQUEsa0JBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyxpQ0FBUDtRQUNBLElBQUEsRUFBTSxRQUROO1FBRUEsQ0FBQSxPQUFBLENBQUEsRUFBUyxtQkFGVDtPQURGO01BSUEsbUJBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyxpQ0FBUDtRQUNBLElBQUEsRUFBTSxRQUROO1FBRUEsQ0FBQSxPQUFBLENBQUEsRUFBUyw4QkFGVDtPQUxGO01BUUEscUJBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyxvQ0FBUDtRQUNBLElBQUEsRUFBTSxRQUROO1FBRUEsQ0FBQSxPQUFBLENBQUEsRUFBUywrQ0FGVDtPQVRGO01BWUEsY0FBQSxFQUNFO1FBQUEsS0FBQSxFQUFPLGtDQUFQO1FBQ0EsSUFBQSxFQUFNLFFBRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLG1CQUZUO09BYkY7TUFnQkEsZUFBQSxFQUNFO1FBQUEsS0FBQSxFQUFPLHFDQUFQO1FBQ0EsSUFBQSxFQUFNLFFBRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLDhCQUZUO09BakJGO01Bb0JBLGlCQUFBLEVBQ0U7UUFBQSxLQUFBLEVBQU8sNENBQVA7UUFDQSxJQUFBLEVBQU0sUUFETjtRQUVBLENBQUEsT0FBQSxDQUFBLEVBQVMsNENBRlQ7T0FyQkY7TUF3QkEsZUFBQSxFQUNFO1FBQUEsS0FBQSxFQUFPLDhCQUFQO1FBQ0EsSUFBQSxFQUFNLFFBRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLGtCQUZUO09BekJGO01BNEJBLGdCQUFBLEVBQ0U7UUFBQSxLQUFBLEVBQU8sOEJBQVA7UUFDQSxJQUFBLEVBQU0sUUFETjtRQUVBLENBQUEsT0FBQSxDQUFBLEVBQVMsNkJBRlQ7T0E3QkY7TUFnQ0Esa0JBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyx5Q0FBUDtRQUNBLElBQUEsRUFBTSxRQUROO1FBRUEsQ0FBQSxPQUFBLENBQUEsRUFBUywyQ0FGVDtPQWpDRjtNQW9DQSxrQkFBQSxFQUNFO1FBQUEsS0FBQSxFQUFPLG9DQUFQO1FBQ0EsSUFBQSxFQUFNLFFBRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLDJCQUZUO09BckNGO01Bd0NBLG1CQUFBLEVBQ0U7UUFBQSxLQUFBLEVBQU8scUNBQVA7UUFDQSxJQUFBLEVBQU0sUUFETjtRQUVBLENBQUEsT0FBQSxDQUFBLEVBQVMsa0NBRlQ7T0F6Q0Y7TUE0Q0EscUJBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyxnREFBUDtRQUNBLElBQUEsRUFBTSxRQUROO1FBRUEsQ0FBQSxPQUFBLENBQUEsRUFBUyxnREFGVDtPQTdDRjtNQWdEQSxhQUFBLEVBQ0U7UUFBQSxJQUFBLEVBQU0sUUFBTjtRQUNBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFEVDtRQUVBLENBQUEsSUFBQSxDQUFBLEVBQU0sQ0FBQyxFQUFELEVBQUssT0FBTCxFQUFjLFVBQWQsQ0FGTjtRQUdBLFdBQUEsRUFBYSx1SkFIYjtPQWpERjtNQXFEQSxhQUFBLEVBQ0U7UUFBQSxJQUFBLEVBQU0sUUFBTjtRQUNBLENBQUEsT0FBQSxDQUFBLEVBQVMsRUFEVDtRQUVBLENBQUEsSUFBQSxDQUFBLEVBQU0sQ0FBQyxFQUFELEVBQUssVUFBTCxFQUFpQixNQUFqQixDQUZOO1FBR0EsV0FBQSxFQUFhLGtLQUhiO09BdERGO0tBREY7SUE0REEsWUFBQSxFQUFjLElBNURkO0lBOERBLFFBQUEsRUFBVSxTQUFDLEtBQUQ7TUFBQyxJQUFDLENBQUEsUUFBRDthQUNULE9BQUEsQ0FBUSxtQkFBUixDQUE0QixDQUFDLE9BQTdCLENBQXFDLFdBQXJDO0lBRFEsQ0E5RFY7SUFpRUEsb0JBQUEsRUFBc0IsU0FBQyxxQkFBRDthQUNwQixJQUFDLENBQUEsWUFBRCxHQUFvQixJQUFBLFlBQUEsQ0FBYSxJQUFDLENBQUEsS0FBSyxDQUFDLGlCQUFwQixFQUF1QyxxQkFBdkM7SUFEQSxDQWpFdEI7SUFvRUEsVUFBQSxFQUFZLFNBQUE7YUFDVixJQUFDLENBQUEsWUFBWSxDQUFDLE9BQWQsQ0FBQTtJQURVLENBcEVaO0lBdUVBLFNBQUEsRUFBVyxTQUFBO01BQ1QsSUFBZ0QsSUFBQyxDQUFBLFlBQWpEO2VBQUE7VUFBQSxpQkFBQSxFQUFtQixJQUFDLENBQUEsWUFBWSxDQUFDLFNBQWQsQ0FBQSxDQUFuQjtVQUFBOztJQURTLENBdkVYOztBQUhGIiwic291cmNlc0NvbnRlbnQiOlsiUnVieVRlc3RWaWV3ID0gcmVxdWlyZSAnLi9ydWJ5LXRlc3QtdmlldydcblxubW9kdWxlLmV4cG9ydHMgPVxuICBjb25maWc6XG4gICAgbWluaXRlc3RBbGxDb21tYW5kOlxuICAgICAgdGl0bGU6IFwiTWluaXRlc3QgY29tbWFuZDogUnVuIGFsbCB0ZXN0c1wiXG4gICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgZGVmYXVsdDogXCJydWJ5IC1JIHRlc3QgdGVzdFwiXG4gICAgbWluaXRlc3RGaWxlQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIk1pbml0ZXN0IGNvbW1hbmQ6IFJ1biB0ZXN0IGZpbGVcIlxuICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgIGRlZmF1bHQ6IFwicnVieSAtSSB0ZXN0IHtyZWxhdGl2ZV9wYXRofVwiXG4gICAgbWluaXRlc3RTaW5nbGVDb21tYW5kOlxuICAgICAgdGl0bGU6IFwiTWluaXRlc3QgY29tbWFuZDogUnVuIGN1cnJlbnQgdGVzdFwiXG4gICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgZGVmYXVsdDogXCJydWJ5IC1JIHRlc3Qge3JlbGF0aXZlX3BhdGh9IC1uIFxcXCIve3JlZ2V4fS9cXFwiXCJcbiAgICB0ZXN0QWxsQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIlJ1YnkgVGVzdCBjb21tYW5kOiBSdW4gYWxsIHRlc3RzXCJcbiAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICBkZWZhdWx0OiBcInJ1YnkgLUkgdGVzdCB0ZXN0XCJcbiAgICB0ZXN0RmlsZUNvbW1hbmQ6XG4gICAgICB0aXRsZTogXCJSdWJ5IFRlc3QgY29tbWFuZDogUnVuIHRlc3QgaW4gZmlsZVwiXG4gICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgZGVmYXVsdDogXCJydWJ5IC1JIHRlc3Qge3JlbGF0aXZlX3BhdGh9XCJcbiAgICB0ZXN0U2luZ2xlQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIlJ1YnkgVGVzdCBjb21tYW5kOiBSdW4gdGVzdCBhdCBsaW5lIG51bWJlclwiXG4gICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgZGVmYXVsdDogXCJydWJ5IC1JIHRlc3Qge3JlbGF0aXZlX3BhdGh9OntsaW5lX251bWJlcn1cIlxuICAgIHJzcGVjQWxsQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIlJTcGVjIGNvbW1hbmQ6IHJ1biBhbGwgc3BlY3NcIlxuICAgICAgdHlwZTogJ3N0cmluZycsXG4gICAgICBkZWZhdWx0OiBcInJzcGVjIC0tdHR5IHNwZWNcIlxuICAgIHJzcGVjRmlsZUNvbW1hbmQ6XG4gICAgICB0aXRsZTogXCJSU3BlYyBjb21tYW5kOiBydW4gc3BlYyBmaWxlXCJcbiAgICAgIHR5cGU6ICdzdHJpbmcnLFxuICAgICAgZGVmYXVsdDogXCJyc3BlYyAtLXR0eSB7cmVsYXRpdmVfcGF0aH1cIlxuICAgIHJzcGVjU2luZ2xlQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIlJTcGVjIGNvbW1hbmQ6IHJ1biBzcGVjIGF0IGN1cnJlbnQgbGluZVwiXG4gICAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICAgIGRlZmF1bHQ6IFwicnNwZWMgLS10dHkge3JlbGF0aXZlX3BhdGh9OntsaW5lX251bWJlcn1cIlxuICAgIGN1Y3VtYmVyQWxsQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIkN1Y3VtYmVyIGNvbW1hbmQ6IFJ1biBhbGwgZmVhdHVyZXNcIlxuICAgICAgdHlwZTogJ3N0cmluZycsXG4gICAgICBkZWZhdWx0OiBcImN1Y3VtYmVyIC0tY29sb3IgZmVhdHVyZXNcIlxuICAgIGN1Y3VtYmVyRmlsZUNvbW1hbmQ6XG4gICAgICB0aXRsZTogXCJDdWN1bWJlciBjb21tYW5kOiBSdW4gZmVhdHVyZXMgZmlsZVwiXG4gICAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICAgIGRlZmF1bHQ6IFwiY3VjdW1iZXIgLS1jb2xvciB7cmVsYXRpdmVfcGF0aH1cIlxuICAgIGN1Y3VtYmVyU2luZ2xlQ29tbWFuZDpcbiAgICAgIHRpdGxlOiBcIkN1Y3VtYmVyIGNvbW1hbmQ6IFJ1biBmZWF0dXJlcyBhdCBjdXJyZW50IGxpbmVcIlxuICAgICAgdHlwZTogJ3N0cmluZycsXG4gICAgICBkZWZhdWx0OiBcImN1Y3VtYmVyIC0tY29sb3Ige3JlbGF0aXZlX3BhdGh9OntsaW5lX251bWJlcn1cIlxuICAgIHNwZWNGcmFtZXdvcms6XG4gICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgZGVmYXVsdDogJydcbiAgICAgIGVudW06IFsnJywgJ3JzcGVjJywgJ21pbml0ZXN0J11cbiAgICAgIGRlc2NyaXB0aW9uOiAnUlNwZWMgYW5kIE1pbml0ZXN0IHNwZWMgZmlsZXMgbG9vayB2ZXJ5IHNpbWlsYXIgdG8gZWFjaCBvdGhlciwgYW5kIHJ1YnktdGVzdCBvZnRlbiBjYW5cXCd0IHRlbGwgdGhlbSBhcGFydC4gQ2hvb3NlIHlvdXIgcHJlZmVycmVkICpfc3BlYy5yYiBmcmFtZXdvcmsuJ1xuICAgIHRlc3RGcmFtZXdvcms6XG4gICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgZGVmYXVsdDogJydcbiAgICAgIGVudW06IFsnJywgJ21pbml0ZXN0JywgJ3Rlc3QnXVxuICAgICAgZGVzY3JpcHRpb246ICdNaW5pdGVzdCB0ZXN0IGZpbGVzIGFuZCBUZXN0OjpVbml0IGZpbGVzIGxvb2sgdmVyeSBzaW1pbGFyIHRvIGVhY2ggb3RoZXIsIGFuZCBydWJ5LXRlc3Qgb2Z0ZW4gY2FuXFwndCB0ZWxsIHRoZW0gYXBhcnQuIENob29zZSB5b3VyIHByZWZlcnJlZCAqX3Rlc3QucmIgZnJhbWV3b3JrLidcblxuICBydWJ5VGVzdFZpZXc6IG51bGxcblxuICBhY3RpdmF0ZTogKEBzdGF0ZSkgLT5cbiAgICByZXF1aXJlKCdhdG9tLXBhY2thZ2UtZGVwcycpLmluc3RhbGwoJ3J1YnktdGVzdCcpXG5cbiAgY29uc3VtZVJ1bkluVGVybWluYWw6IChydW5JblRlcm1pbmFsUHJvdmlkZXIpIC0+XG4gICAgQHJ1YnlUZXN0VmlldyA9IG5ldyBSdWJ5VGVzdFZpZXcoQHN0YXRlLnJ1YnlUZXN0Vmlld1N0YXRlLCBydW5JblRlcm1pbmFsUHJvdmlkZXIpXG5cbiAgZGVhY3RpdmF0ZTogLT5cbiAgICBAcnVieVRlc3RWaWV3LmRlc3Ryb3koKVxuXG4gIHNlcmlhbGl6ZTogLT5cbiAgICBydWJ5VGVzdFZpZXdTdGF0ZTogQHJ1YnlUZXN0Vmlldy5zZXJpYWxpemUoKSBpZiBAcnVieVRlc3RWaWV3XG4iXX0=
