(function() {
  var AutoIndentView, WorkspaceView;

  AutoIndentView = require('../lib/auto-indent-view');

  WorkspaceView = require('atom').WorkspaceView;

  describe("AutoIndentView", function() {
    return it("has one valid test", function() {
      return expect("life").toBe("easy");
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL2F1dG8taW5kZW50L3NwZWMvYXV0by1pbmRlbnQtdmlldy1zcGVjLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsY0FBQSxHQUFpQixPQUFBLENBQVEseUJBQVI7O0VBQ2hCLGdCQUFpQixPQUFBLENBQVEsTUFBUjs7RUFFbEIsUUFBQSxDQUFTLGdCQUFULEVBQTJCLFNBQUE7V0FDekIsRUFBQSxDQUFHLG9CQUFILEVBQXlCLFNBQUE7YUFDdkIsTUFBQSxDQUFPLE1BQVAsQ0FBYyxDQUFDLElBQWYsQ0FBb0IsTUFBcEI7SUFEdUIsQ0FBekI7RUFEeUIsQ0FBM0I7QUFIQSIsInNvdXJjZXNDb250ZW50IjpbIkF1dG9JbmRlbnRWaWV3ID0gcmVxdWlyZSAnLi4vbGliL2F1dG8taW5kZW50LXZpZXcnXG57V29ya3NwYWNlVmlld30gPSByZXF1aXJlICdhdG9tJ1xuXG5kZXNjcmliZSBcIkF1dG9JbmRlbnRWaWV3XCIsIC0+XG4gIGl0IFwiaGFzIG9uZSB2YWxpZCB0ZXN0XCIsIC0+XG4gICAgZXhwZWN0KFwibGlmZVwiKS50b0JlIFwiZWFzeVwiXG4iXX0=
