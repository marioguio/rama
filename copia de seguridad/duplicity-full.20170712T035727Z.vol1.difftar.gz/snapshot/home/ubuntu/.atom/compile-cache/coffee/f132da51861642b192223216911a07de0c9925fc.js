(function() {
  var RubyBlockView;

  module.exports = RubyBlockView = (function() {
    function RubyBlockView(serializeState) {
      this.element = document.createElement('div');
      this.element.classList.add('ruby-block');
    }

    RubyBlockView.prototype.destroy = function() {
      return this.element.remove();
    };

    RubyBlockView.prototype.getElement = function() {
      return this.element;
    };

    RubyBlockView.prototype.updateMessage = function(rowNumber) {
      var message, row;
      row = atom.workspace.getActiveTextEditor().lineTextForBufferRow(rowNumber);
      if (this.element.hasChildNodes()) {
        this.element.removeChild(this.element.firstChild);
      }
      message = document.createElement('div');
      message.textContent = "Line: " + (rowNumber + 1) + " " + row;
      message.classList.add('message');
      return this.element.appendChild(message);
    };

    return RubyBlockView;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktYmxvY2svbGliL3J1YnktYmxvY2stdmlldy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQ007SUFDUyx1QkFBQyxjQUFEO01BRVgsSUFBQyxDQUFBLE9BQUQsR0FBVyxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QjtNQUNYLElBQUMsQ0FBQSxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQW5CLENBQXVCLFlBQXZCO0lBSFc7OzRCQU1iLE9BQUEsR0FBUyxTQUFBO2FBQ1AsSUFBQyxDQUFBLE9BQU8sQ0FBQyxNQUFULENBQUE7SUFETzs7NEJBR1QsVUFBQSxHQUFZLFNBQUE7YUFDVixJQUFDLENBQUE7SUFEUzs7NEJBR1osYUFBQSxHQUFlLFNBQUMsU0FBRDtBQUNiLFVBQUE7TUFBQSxHQUFBLEdBQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBZixDQUFBLENBQW9DLENBQUMsb0JBQXJDLENBQTBELFNBQTFEO01BRU4sSUFBNkMsSUFBQyxDQUFBLE9BQU8sQ0FBQyxhQUFULENBQUEsQ0FBN0M7UUFBQSxJQUFDLENBQUEsT0FBTyxDQUFDLFdBQVQsQ0FBcUIsSUFBQyxDQUFBLE9BQU8sQ0FBQyxVQUE5QixFQUFBOztNQUVBLE9BQUEsR0FBVSxRQUFRLENBQUMsYUFBVCxDQUF1QixLQUF2QjtNQUNWLE9BQU8sQ0FBQyxXQUFSLEdBQXNCLFFBQUEsR0FBUSxDQUFDLFNBQUEsR0FBVSxDQUFYLENBQVIsR0FBcUIsR0FBckIsR0FBd0I7TUFDOUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFsQixDQUFzQixTQUF0QjthQUNBLElBQUMsQ0FBQSxPQUFPLENBQUMsV0FBVCxDQUFxQixPQUFyQjtJQVJhOzs7OztBQWRqQiIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID1cbmNsYXNzIFJ1YnlCbG9ja1ZpZXdcbiAgY29uc3RydWN0b3I6IChzZXJpYWxpemVTdGF0ZSkgLT5cbiAgICAjIENyZWF0ZSByb290IGVsZW1lbnRcbiAgICBAZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgQGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgncnVieS1ibG9jaycpXG5cbiAgIyBUZWFyIGRvd24gYW55IHN0YXRlIGFuZCBkZXRhY2hcbiAgZGVzdHJveTogLT5cbiAgICBAZWxlbWVudC5yZW1vdmUoKVxuXG4gIGdldEVsZW1lbnQ6IC0+XG4gICAgQGVsZW1lbnRcblxuICB1cGRhdGVNZXNzYWdlOiAocm93TnVtYmVyKS0+XG4gICAgcm93ID0gYXRvbS53b3Jrc3BhY2UuZ2V0QWN0aXZlVGV4dEVkaXRvcigpLmxpbmVUZXh0Rm9yQnVmZmVyUm93KHJvd051bWJlcilcblxuICAgIEBlbGVtZW50LnJlbW92ZUNoaWxkKEBlbGVtZW50LmZpcnN0Q2hpbGQpIGlmIEBlbGVtZW50Lmhhc0NoaWxkTm9kZXMoKVxuICAgICMgQ3JlYXRlIG1lc3NhZ2UgZWxlbWVudFxuICAgIG1lc3NhZ2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgIG1lc3NhZ2UudGV4dENvbnRlbnQgPSBcIkxpbmU6ICN7cm93TnVtYmVyKzF9ICN7cm93fVwiXG4gICAgbWVzc2FnZS5jbGFzc0xpc3QuYWRkKCdtZXNzYWdlJylcbiAgICBAZWxlbWVudC5hcHBlbmRDaGlsZChtZXNzYWdlKVxuIl19
