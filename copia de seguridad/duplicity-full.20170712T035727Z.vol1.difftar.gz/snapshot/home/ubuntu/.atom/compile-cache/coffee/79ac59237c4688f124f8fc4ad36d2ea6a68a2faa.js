(function() {
  var GEM_HOME, RsenseProvider;

  RsenseProvider = require('./autocomplete-ruby-provider.coffee');

  GEM_HOME = require('./gem-home.coffee');

  module.exports = {
    config: {
      rsensePath: {
        description: 'The location of the rsense executable',
        type: 'string',
        "default": GEM_HOME + "/rsense"
      },
      port: {
        description: 'The port the rsense server is running on',
        type: 'integer',
        "default": 47367,
        minimum: 1024,
        maximum: 65535
      },
      suggestionPriority: {
        description: 'Show autocomplete-ruby content before default autocomplete-plus provider',
        "default": false,
        type: 'boolean'
      }
    },
    rsenseProvider: null,
    activate: function(state) {
      return this.rsenseProvider = new RsenseProvider();
    },
    provideAutocompletion: function() {
      return this.rsenseProvider;
    },
    deactivate: function() {
      var ref;
      if ((ref = this.rsenseProvider) != null) {
        ref.dispose();
      }
      return this.rsenseProvider = null;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1ydWJ5L2xpYi9hdXRvY29tcGxldGUtcnVieS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLGNBQUEsR0FBaUIsT0FBQSxDQUFRLHFDQUFSOztFQUNqQixRQUFBLEdBQVcsT0FBQSxDQUFRLG1CQUFSOztFQUVYLE1BQU0sQ0FBQyxPQUFQLEdBQ0U7SUFBQSxNQUFBLEVBQ0U7TUFBQSxVQUFBLEVBQ0U7UUFBQSxXQUFBLEVBQWEsdUNBQWI7UUFDQSxJQUFBLEVBQU0sUUFETjtRQUVBLENBQUEsT0FBQSxDQUFBLEVBQVksUUFBRCxHQUFVLFNBRnJCO09BREY7TUFJQSxJQUFBLEVBQ0U7UUFBQSxXQUFBLEVBQWEsMENBQWI7UUFDQSxJQUFBLEVBQU0sU0FETjtRQUVBLENBQUEsT0FBQSxDQUFBLEVBQVMsS0FGVDtRQUdBLE9BQUEsRUFBUyxJQUhUO1FBSUEsT0FBQSxFQUFTLEtBSlQ7T0FMRjtNQVVBLGtCQUFBLEVBQ0U7UUFBQSxXQUFBLEVBQWEsMEVBQWI7UUFDQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBRFQ7UUFFQSxJQUFBLEVBQU0sU0FGTjtPQVhGO0tBREY7SUFnQkEsY0FBQSxFQUFnQixJQWhCaEI7SUFrQkEsUUFBQSxFQUFVLFNBQUMsS0FBRDthQUNSLElBQUMsQ0FBQSxjQUFELEdBQXNCLElBQUEsY0FBQSxDQUFBO0lBRGQsQ0FsQlY7SUFxQkEscUJBQUEsRUFBdUIsU0FBQTthQUNyQixJQUFDLENBQUE7SUFEb0IsQ0FyQnZCO0lBd0JBLFVBQUEsRUFBWSxTQUFBO0FBQ1YsVUFBQTs7V0FBZSxDQUFFLE9BQWpCLENBQUE7O2FBQ0EsSUFBQyxDQUFBLGNBQUQsR0FBa0I7SUFGUixDQXhCWjs7QUFKRiIsInNvdXJjZXNDb250ZW50IjpbIlJzZW5zZVByb3ZpZGVyID0gcmVxdWlyZSAnLi9hdXRvY29tcGxldGUtcnVieS1wcm92aWRlci5jb2ZmZWUnXG5HRU1fSE9NRSA9IHJlcXVpcmUoJy4vZ2VtLWhvbWUuY29mZmVlJylcblxubW9kdWxlLmV4cG9ydHMgPVxuICBjb25maWc6XG4gICAgcnNlbnNlUGF0aDpcbiAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIGxvY2F0aW9uIG9mIHRoZSByc2Vuc2UgZXhlY3V0YWJsZSdcbiAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICBkZWZhdWx0OiBcIiN7R0VNX0hPTUV9L3JzZW5zZVwiXG4gICAgcG9ydDpcbiAgICAgIGRlc2NyaXB0aW9uOiAnVGhlIHBvcnQgdGhlIHJzZW5zZSBzZXJ2ZXIgaXMgcnVubmluZyBvbidcbiAgICAgIHR5cGU6ICdpbnRlZ2VyJ1xuICAgICAgZGVmYXVsdDogNDczNjdcbiAgICAgIG1pbmltdW06IDEwMjRcbiAgICAgIG1heGltdW06IDY1NTM1XG4gICAgc3VnZ2VzdGlvblByaW9yaXR5OlxuICAgICAgZGVzY3JpcHRpb246ICdTaG93IGF1dG9jb21wbGV0ZS1ydWJ5IGNvbnRlbnQgYmVmb3JlIGRlZmF1bHQgYXV0b2NvbXBsZXRlLXBsdXMgcHJvdmlkZXInXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuICAgICAgdHlwZTogJ2Jvb2xlYW4nXG5cbiAgcnNlbnNlUHJvdmlkZXI6IG51bGxcblxuICBhY3RpdmF0ZTogKHN0YXRlKSAtPlxuICAgIEByc2Vuc2VQcm92aWRlciA9IG5ldyBSc2Vuc2VQcm92aWRlcigpXG5cbiAgcHJvdmlkZUF1dG9jb21wbGV0aW9uOiAtPlxuICAgIEByc2Vuc2VQcm92aWRlclxuXG4gIGRlYWN0aXZhdGU6IC0+XG4gICAgQHJzZW5zZVByb3ZpZGVyPy5kaXNwb3NlKClcbiAgICBAcnNlbnNlUHJvdmlkZXIgPSBudWxsXG4iXX0=
