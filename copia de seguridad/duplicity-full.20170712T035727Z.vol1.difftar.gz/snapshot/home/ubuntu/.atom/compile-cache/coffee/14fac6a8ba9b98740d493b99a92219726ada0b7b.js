(function() {
  var CompositeDisposable, Point, RubyBlock, RubyBlockView, _, ref;

  ref = require('atom'), CompositeDisposable = ref.CompositeDisposable, Point = ref.Point;

  _ = null;

  RubyBlockView = null;

  module.exports = RubyBlock = {
    config: {
      showBottomPanel: {
        type: 'boolean',
        "default": true
      },
      highlightLine: {
        type: 'boolean',
        "default": true
      },
      highlightLineNumber: {
        type: 'boolean',
        "default": false
      }
    },
    rubyBlockView: null,
    modalPanel: null,
    rubyRootScope: 'source.ruby',
    rubyStartBlockNames: ['for', 'if', 'unless', 'until', 'while', 'class', 'module', 'case', 'def', 'begin', 'describe', 'context'],
    rubyStartBlockScopes: ['keyword.control.ruby', 'keyword.control.start-block.ruby', 'keyword.control.class.ruby', 'keyword.control.module.ruby', 'keyword.control.def.ruby', 'meta.rspec.behaviour'],
    rubyWhileBlockName: 'while',
    rubyDoBlockName: 'do',
    rubyEndBlockName: 'end',
    rubyKeywordControlScope: 'keyword.control.ruby',
    rubyKeywordControlNames: ['end', 'elsif', 'else', 'when', 'rescue', 'ensure'],
    rubyDoScope: 'keyword.control.start-block.ruby',
    endBlockStack: [],
    activate: function() {
      return this.activeItemSubscription = atom.workspace.observeActivePaneItem((function(_this) {
        return function() {
          return _this.subscribeToActiveTextEditor();
        };
      })(this));
    },
    deactivate: function() {
      var ref1, ref2, ref3, ref4, ref5;
      if ((ref1 = this.marker) != null) {
        ref1.destroy();
      }
      this.marker = null;
      if ((ref2 = this.modalPanel) != null) {
        ref2.destroy();
      }
      this.modalPanel = null;
      if ((ref3 = this.activeItemSubscription) != null) {
        ref3.dispose();
      }
      this.activeItemSubscription = null;
      if ((ref4 = this.editorSubscriptions) != null) {
        ref4.dispose();
      }
      this.editorSubscriptions = null;
      if ((ref5 = this.rubyBlockView) != null) {
        ref5.destroy();
      }
      return this.rubyBlockView = null;
    },
    init: function() {
      if (!(RubyBlockView && _)) {
        this.loadClasses();
      }
      this.rubyBlockView = new RubyBlockView;
      return this.modalPanel = atom.workspace.addBottomPanel({
        item: this.rubyBlockView.getElement(),
        visible: false,
        priority: 500
      });
    },
    getActiveTextEditor: function() {
      return atom.workspace.getActiveTextEditor();
    },
    goToMatchingLine: function() {
      var editor, firstCharPoint, row;
      if (this.blockStartedRowNumber == null) {
        return atom.beep();
      }
      editor = this.getActiveTextEditor();
      row = editor.lineTextForBufferRow(this.blockStartedRowNumber);
      firstCharPoint = row.search(/\S/);
      return editor.setCursorBufferPosition([this.blockStartedRowNumber, firstCharPoint]);
    },
    subscribeToActiveTextEditor: function() {
      var editor, editorElement, ref1, ref2, ref3;
      if ((ref1 = this.marker) != null) {
        ref1.destroy();
      }
      if ((ref2 = this.modalPanel) != null ? ref2.isVisible() : void 0) {
        this.modalPanel.hide();
      }
      if ((ref3 = this.editorSubscriptions) != null) {
        ref3.dispose();
      }
      editor = this.getActiveTextEditor();
      if (editor == null) {
        return;
      }
      if (editor.getRootScopeDescriptor().scopes[0].indexOf(this.rubyRootScope) === -1) {
        return;
      }
      if (this.rubyBlockView == null) {
        this.init();
      }
      editorElement = atom.views.getView(editor);
      this.editorSubscriptions = new CompositeDisposable;
      this.editorSubscriptions.add(atom.commands.add(editorElement, {
        'ruby-block:go-to-matching-line': (function(_this) {
          return function() {
            return _this.goToMatchingLine();
          };
        })(this)
      }));
      this.editorSubscriptions.add(editor.onDidChangeCursorPosition(_.debounce((function(_this) {
        return function() {
          var ref4;
          if (_this.getActiveTextEditor() !== editor) {
            return;
          }
          _this.blockStartedRowNumber = null;
          if (_this.modalPanel.isVisible()) {
            _this.modalPanel.hide();
          }
          if ((ref4 = _this.marker) != null) {
            ref4.destroy();
          }
          return _this.searchForBlock();
        };
      })(this), 100)));
      return this.searchForBlock();
    },
    searchForBlock: function() {
      var currentRowNumber, cursor, editor, filteredTokens, firstTokenScope, grammar, i, j, k, l, len, len1, m, prevWordBoundaryPos, ref1, ref2, ref3, row, rowNumber, scope, startBlock, token, tokens;
      editor = this.getActiveTextEditor();
      grammar = editor.getGrammar();
      cursor = editor.getLastCursor();
      currentRowNumber = cursor.getBufferRow();
      if (cursor.getScopeDescriptor().scopes.indexOf(this.rubyKeywordControlScope) === -1 || this.rubyKeywordControlNames.indexOf(editor.getWordUnderCursor()) === -1) {
        return;
      }
      this.endBlockStack.push(editor.getWordUnderCursor);
      for (rowNumber = j = ref1 = cursor.getBufferRow(); ref1 <= 0 ? j <= 0 : j >= 0; rowNumber = ref1 <= 0 ? ++j : --j) {
        if (editor.isBufferRowCommented(rowNumber)) {
          continue;
        }
        if (rowNumber === currentRowNumber) {
          prevWordBoundaryPos = cursor.getPreviousWordBoundaryBufferPosition();
          row = editor.getTextInBufferRange([[rowNumber, 0], prevWordBoundaryPos]);
        } else {
          row = editor.lineTextForBufferRow(rowNumber);
        }
        tokens = grammar.tokenizeLine(row).tokens;
        filteredTokens = (function() {
          var k, len, results;
          results = [];
          for (i = k = 0, len = tokens.length; k < len; i = ++k) {
            token = tokens[i];
            if (!token.value.match(/^\s*$/)) {
              results.push(token);
            }
          }
          return results;
        })();
        startBlock = (function() {
          var k, len, results;
          results = [];
          for (k = 0, len = filteredTokens.length; k < len; k++) {
            token = filteredTokens[k];
            if (token.scopes.indexOf(this.rubyDoScope) >= 0) {
              results.push(token);
            }
          }
          return results;
        }).call(this);
        if (startBlock.length > 0) {
          if (token.value !== this.rubyDoBlockName || filteredTokens[0].value !== this.rubyWhileBlockName) {
            this.endBlockStack.pop();
          }
          if (this.endBlockStack.length === 0) {
            return this.highlightBlock(rowNumber);
          }
        }
        for (k = filteredTokens.length - 1; k >= 0; k += -1) {
          token = filteredTokens[k];
          ref2 = token.scopes;
          for (l = 0, len = ref2.length; l < len; l++) {
            scope = ref2[l];
            if (scope === this.rubyKeywordControlScope && token.value === this.rubyEndBlockName) {
              this.endBlockStack.push(scope.value);
            } else if (this.rubyStartBlockScopes.indexOf(scope) >= 0 && this.rubyStartBlockNames.indexOf(token.value) >= 0) {
              if (token.value === 'case') {
                this.endBlockStack.pop();
              } else {
                ref3 = filteredTokens[0].scopes;
                for (m = 0, len1 = ref3.length; m < len1; m++) {
                  firstTokenScope = ref3[m];
                  if (this.rubyStartBlockScopes.indexOf(firstTokenScope) >= 0 && this.rubyStartBlockNames.indexOf(filteredTokens[0].value) >= 0) {
                    this.endBlockStack.pop();
                    break;
                  }
                }
              }
              if (this.endBlockStack.length === 0) {
                return this.highlightBlock(rowNumber);
              }
            }
          }
        }
      }
    },
    highlightBlock: function(rowNumber) {
      var editor, firstCharPoint, row;
      editor = this.getActiveTextEditor();
      row = editor.lineTextForBufferRow(rowNumber);
      firstCharPoint = row.search(/\S/);
      this.marker = editor.markBufferRange([[rowNumber, firstCharPoint], [rowNumber, row.length]]);
      this.blockStartedRowNumber = rowNumber;
      if (atom.config.get('ruby-block.highlightLine')) {
        editor.decorateMarker(this.marker, {
          type: 'highlight',
          "class": 'ruby-block-highlight'
        });
      }
      if (atom.config.get('ruby-block.highlightLineNumber')) {
        editor.decorateMarker(this.marker, {
          type: 'line-number',
          "class": 'ruby-block-highlight'
        });
      }
      if (atom.config.get('ruby-block.showBottomPanel')) {
        this.rubyBlockView.updateMessage(rowNumber);
        return this.modalPanel.show();
      }
    },
    loadClasses: function() {
      _ = require('underscore-plus');
      return RubyBlockView = require('./ruby-block-view');
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktYmxvY2svbGliL3J1YnktYmxvY2suY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxNQUErQixPQUFBLENBQVEsTUFBUixDQUEvQixFQUFDLDZDQUFELEVBQXNCOztFQUN0QixDQUFBLEdBQUk7O0VBQ0osYUFBQSxHQUFnQjs7RUFFaEIsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQSxHQUNmO0lBQUEsTUFBQSxFQUNFO01BQUEsZUFBQSxFQUNFO1FBQUEsSUFBQSxFQUFNLFNBQU47UUFDQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLElBRFQ7T0FERjtNQUdBLGFBQUEsRUFDRTtRQUFBLElBQUEsRUFBTSxTQUFOO1FBQ0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxJQURUO09BSkY7TUFNQSxtQkFBQSxFQUNFO1FBQUEsSUFBQSxFQUFNLFNBQU47UUFDQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBRFQ7T0FQRjtLQURGO0lBWUEsYUFBQSxFQUFlLElBWmY7SUFhQSxVQUFBLEVBQVksSUFiWjtJQWNBLGFBQUEsRUFBZSxhQWRmO0lBZ0JBLG1CQUFBLEVBQXFCLENBQ25CLEtBRG1CLEVBRW5CLElBRm1CLEVBR25CLFFBSG1CLEVBSW5CLE9BSm1CLEVBS25CLE9BTG1CLEVBTW5CLE9BTm1CLEVBT25CLFFBUG1CLEVBUW5CLE1BUm1CLEVBU25CLEtBVG1CLEVBVW5CLE9BVm1CLEVBV25CLFVBWG1CLEVBWW5CLFNBWm1CLENBaEJyQjtJQThCQSxvQkFBQSxFQUFzQixDQUNuQixzQkFEbUIsRUFFbkIsa0NBRm1CLEVBR25CLDRCQUhtQixFQUluQiw2QkFKbUIsRUFLbkIsMEJBTG1CLEVBTW5CLHNCQU5tQixDQTlCdEI7SUF1Q0Esa0JBQUEsRUFBb0IsT0F2Q3BCO0lBd0NBLGVBQUEsRUFBaUIsSUF4Q2pCO0lBeUNBLGdCQUFBLEVBQWtCLEtBekNsQjtJQTJDQSx1QkFBQSxFQUF5QixzQkEzQ3pCO0lBNENBLHVCQUFBLEVBQXlCLENBQ3ZCLEtBRHVCLEVBRXZCLE9BRnVCLEVBR3ZCLE1BSHVCLEVBSXZCLE1BSnVCLEVBS3ZCLFFBTHVCLEVBTXZCLFFBTnVCLENBNUN6QjtJQXFEQSxXQUFBLEVBQWEsa0NBckRiO0lBdURBLGFBQUEsRUFBZSxFQXZEZjtJQXlEQSxRQUFBLEVBQVUsU0FBQTthQUVSLElBQUMsQ0FBQSxzQkFBRCxHQUEwQixJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFmLENBQXNDLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQTtpQkFBRyxLQUFDLENBQUEsMkJBQUQsQ0FBQTtRQUFIO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF0QztJQUZsQixDQXpEVjtJQTZEQSxVQUFBLEVBQVksU0FBQTtBQUNWLFVBQUE7O1lBQU8sQ0FBRSxPQUFULENBQUE7O01BQ0EsSUFBQyxDQUFBLE1BQUQsR0FBVTs7WUFDQyxDQUFFLE9BQWIsQ0FBQTs7TUFDQSxJQUFDLENBQUEsVUFBRCxHQUFjOztZQUNTLENBQUUsT0FBekIsQ0FBQTs7TUFDQSxJQUFDLENBQUEsc0JBQUQsR0FBMEI7O1lBQ04sQ0FBRSxPQUF0QixDQUFBOztNQUNBLElBQUMsQ0FBQSxtQkFBRCxHQUF1Qjs7WUFDVCxDQUFFLE9BQWhCLENBQUE7O2FBQ0EsSUFBQyxDQUFBLGFBQUQsR0FBaUI7SUFWUCxDQTdEWjtJQXlFQSxJQUFBLEVBQU0sU0FBQTtNQUNKLElBQUEsQ0FBQSxDQUFzQixhQUFBLElBQWtCLENBQXhDLENBQUE7UUFBQSxJQUFDLENBQUEsV0FBRCxDQUFBLEVBQUE7O01BQ0EsSUFBQyxDQUFBLGFBQUQsR0FBaUIsSUFBSTthQUNyQixJQUFDLENBQUEsVUFBRCxHQUFjLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBZixDQUE4QjtRQUFBLElBQUEsRUFBTSxJQUFDLENBQUEsYUFBYSxDQUFDLFVBQWYsQ0FBQSxDQUFOO1FBQW1DLE9BQUEsRUFBUyxLQUE1QztRQUFtRCxRQUFBLEVBQVUsR0FBN0Q7T0FBOUI7SUFIVixDQXpFTjtJQThFQSxtQkFBQSxFQUFxQixTQUFBO2FBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQWYsQ0FBQTtJQURtQixDQTlFckI7SUFpRkEsZ0JBQUEsRUFBa0IsU0FBQTtBQUNoQixVQUFBO01BQUEsSUFBMEIsa0NBQTFCO0FBQUEsZUFBTyxJQUFJLENBQUMsSUFBTCxDQUFBLEVBQVA7O01BQ0EsTUFBQSxHQUFTLElBQUMsQ0FBQSxtQkFBRCxDQUFBO01BQ1QsR0FBQSxHQUFNLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixJQUFDLENBQUEscUJBQTdCO01BQ04sY0FBQSxHQUFpQixHQUFHLENBQUMsTUFBSixDQUFXLElBQVg7YUFDakIsTUFBTSxDQUFDLHVCQUFQLENBQStCLENBQUMsSUFBQyxDQUFBLHFCQUFGLEVBQXlCLGNBQXpCLENBQS9CO0lBTGdCLENBakZsQjtJQXdGQSwyQkFBQSxFQUE2QixTQUFBO0FBQzNCLFVBQUE7O1lBQU8sQ0FBRSxPQUFULENBQUE7O01BQ0EsMkNBQWlDLENBQUUsU0FBYixDQUFBLFVBQXRCO1FBQUEsSUFBQyxDQUFBLFVBQVUsQ0FBQyxJQUFaLENBQUEsRUFBQTs7O1lBRW9CLENBQUUsT0FBdEIsQ0FBQTs7TUFDQSxNQUFBLEdBQVMsSUFBQyxDQUFBLG1CQUFELENBQUE7TUFFVCxJQUFjLGNBQWQ7QUFBQSxlQUFBOztNQUNBLElBQVUsTUFBTSxDQUFDLHNCQUFQLENBQUEsQ0FBK0IsQ0FBQyxNQUFPLENBQUEsQ0FBQSxDQUFFLENBQUMsT0FBMUMsQ0FBa0QsSUFBQyxDQUFBLGFBQW5ELENBQUEsS0FBcUUsQ0FBQyxDQUFoRjtBQUFBLGVBQUE7O01BRUEsSUFBZSwwQkFBZjtRQUFBLElBQUMsQ0FBQSxJQUFELENBQUEsRUFBQTs7TUFFQSxhQUFBLEdBQWdCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBWCxDQUFtQixNQUFuQjtNQUNoQixJQUFDLENBQUEsbUJBQUQsR0FBdUIsSUFBSTtNQUUzQixJQUFDLENBQUEsbUJBQW1CLENBQUMsR0FBckIsQ0FBeUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGFBQWxCLEVBQ3ZCO1FBQUEsZ0NBQUEsRUFBa0MsQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQTttQkFDaEMsS0FBQyxDQUFBLGdCQUFELENBQUE7VUFEZ0M7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDO09BRHVCLENBQXpCO01BTUEsSUFBQyxDQUFBLG1CQUFtQixDQUFDLEdBQXJCLENBQXlCLE1BQU0sQ0FBQyx5QkFBUCxDQUFpQyxDQUFDLENBQUMsUUFBRixDQUFZLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQTtBQUNwRSxjQUFBO1VBQUEsSUFBYyxLQUFDLENBQUEsbUJBQUQsQ0FBQSxDQUFBLEtBQTBCLE1BQXhDO0FBQUEsbUJBQUE7O1VBQ0EsS0FBQyxDQUFBLHFCQUFELEdBQXlCO1VBQ3pCLElBQXNCLEtBQUMsQ0FBQSxVQUFVLENBQUMsU0FBWixDQUFBLENBQXRCO1lBQUEsS0FBQyxDQUFBLFVBQVUsQ0FBQyxJQUFaLENBQUEsRUFBQTs7O2dCQUNPLENBQUUsT0FBVCxDQUFBOztpQkFDQSxLQUFDLENBQUEsY0FBRCxDQUFBO1FBTG9FO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFaLEVBTXhELEdBTndELENBQWpDLENBQXpCO2FBUUEsSUFBQyxDQUFBLGNBQUQsQ0FBQTtJQTdCMkIsQ0F4RjdCO0lBdUhBLGNBQUEsRUFBZ0IsU0FBQTtBQUNkLFVBQUE7TUFBQSxNQUFBLEdBQVMsSUFBQyxDQUFBLG1CQUFELENBQUE7TUFDVCxPQUFBLEdBQVUsTUFBTSxDQUFDLFVBQVAsQ0FBQTtNQUNWLE1BQUEsR0FBUyxNQUFNLENBQUMsYUFBUCxDQUFBO01BQ1QsZ0JBQUEsR0FBbUIsTUFBTSxDQUFDLFlBQVAsQ0FBQTtNQUduQixJQUFVLE1BQU0sQ0FBQyxrQkFBUCxDQUFBLENBQTJCLENBQUMsTUFBTSxDQUFDLE9BQW5DLENBQTJDLElBQUMsQ0FBQSx1QkFBNUMsQ0FBQSxLQUF3RSxDQUFDLENBQXpFLElBQ0EsSUFBQyxDQUFBLHVCQUF1QixDQUFDLE9BQXpCLENBQWlDLE1BQU0sQ0FBQyxrQkFBUCxDQUFBLENBQWpDLENBQUEsS0FBaUUsQ0FBQyxDQUQ1RTtBQUFBLGVBQUE7O01BR0EsSUFBQyxDQUFBLGFBQWEsQ0FBQyxJQUFmLENBQW9CLE1BQU0sQ0FBQyxrQkFBM0I7QUFHQSxXQUFpQiw0R0FBakI7UUFDRSxJQUFZLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixTQUE1QixDQUFaO0FBQUEsbUJBQUE7O1FBRUEsSUFBRyxTQUFBLEtBQWEsZ0JBQWhCO1VBQ0UsbUJBQUEsR0FBc0IsTUFBTSxDQUFDLHFDQUFQLENBQUE7VUFDdEIsR0FBQSxHQUFNLE1BQU0sQ0FBQyxvQkFBUCxDQUE0QixDQUFDLENBQUMsU0FBRCxFQUFZLENBQVosQ0FBRCxFQUFpQixtQkFBakIsQ0FBNUIsRUFGUjtTQUFBLE1BQUE7VUFJRSxHQUFBLEdBQU0sTUFBTSxDQUFDLG9CQUFQLENBQTRCLFNBQTVCLEVBSlI7O1FBTUEsTUFBQSxHQUFTLE9BQU8sQ0FBQyxZQUFSLENBQXFCLEdBQXJCLENBQXlCLENBQUM7UUFDbkMsY0FBQTs7QUFBa0I7ZUFBQSxnREFBQTs7Z0JBQWlDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFaLENBQWtCLE9BQWxCOzJCQUFsQzs7QUFBQTs7O1FBRWxCLFVBQUE7O0FBQWM7ZUFBQSxnREFBQTs7Z0JBQXVDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBYixDQUFxQixJQUFDLENBQUEsV0FBdEIsQ0FBQSxJQUFzQzsyQkFBN0U7O0FBQUE7OztRQUNkLElBQUcsVUFBVSxDQUFDLE1BQVgsR0FBb0IsQ0FBdkI7VUFDRSxJQUFHLEtBQUssQ0FBQyxLQUFOLEtBQWlCLElBQUMsQ0FBQSxlQUFsQixJQUNBLGNBQWUsQ0FBQSxDQUFBLENBQUUsQ0FBQyxLQUFsQixLQUE2QixJQUFDLENBQUEsa0JBRGpDO1lBRUUsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFmLENBQUEsRUFGRjs7VUFHQSxJQUFHLElBQUMsQ0FBQSxhQUFhLENBQUMsTUFBZixLQUF5QixDQUE1QjtBQUNFLG1CQUFPLElBQUMsQ0FBQSxjQUFELENBQWdCLFNBQWhCLEVBRFQ7V0FKRjs7QUFPQSxhQUFBLDhDQUFBOztBQUNFO0FBQUEsZUFBQSxzQ0FBQTs7WUFDRSxJQUFHLEtBQUEsS0FBUyxJQUFDLENBQUEsdUJBQVYsSUFBc0MsS0FBSyxDQUFDLEtBQU4sS0FBZSxJQUFDLENBQUEsZ0JBQXpEO2NBQ0UsSUFBQyxDQUFBLGFBQWEsQ0FBQyxJQUFmLENBQW9CLEtBQUssQ0FBQyxLQUExQixFQURGO2FBQUEsTUFFSyxJQUFHLElBQUMsQ0FBQSxvQkFBb0IsQ0FBQyxPQUF0QixDQUE4QixLQUE5QixDQUFBLElBQXdDLENBQXhDLElBQ0EsSUFBQyxDQUFBLG1CQUFtQixDQUFDLE9BQXJCLENBQTZCLEtBQUssQ0FBQyxLQUFuQyxDQUFBLElBQTZDLENBRGhEO2NBT0gsSUFBRyxLQUFLLENBQUMsS0FBTixLQUFlLE1BQWxCO2dCQUNFLElBQUMsQ0FBQSxhQUFhLENBQUMsR0FBZixDQUFBLEVBREY7ZUFBQSxNQUFBO0FBR0U7QUFBQSxxQkFBQSx3Q0FBQTs7a0JBQ0UsSUFBRyxJQUFDLENBQUEsb0JBQW9CLENBQUMsT0FBdEIsQ0FBOEIsZUFBOUIsQ0FBQSxJQUFrRCxDQUFsRCxJQUNBLElBQUMsQ0FBQSxtQkFBbUIsQ0FBQyxPQUFyQixDQUE2QixjQUFlLENBQUEsQ0FBQSxDQUFFLENBQUMsS0FBL0MsQ0FBQSxJQUF5RCxDQUQ1RDtvQkFFRSxJQUFDLENBQUEsYUFBYSxDQUFDLEdBQWYsQ0FBQTtBQUNBLDBCQUhGOztBQURGLGlCQUhGOztjQVNBLElBQUcsSUFBQyxDQUFBLGFBQWEsQ0FBQyxNQUFmLEtBQXlCLENBQTVCO0FBQ0UsdUJBQU8sSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsU0FBaEIsRUFEVDtlQWhCRzs7QUFIUDtBQURGO0FBcEJGO0lBYmMsQ0F2SGhCO0lBK0tBLGNBQUEsRUFBZ0IsU0FBQyxTQUFEO0FBQ2QsVUFBQTtNQUFBLE1BQUEsR0FBUyxJQUFDLENBQUEsbUJBQUQsQ0FBQTtNQUNULEdBQUEsR0FBTSxNQUFNLENBQUMsb0JBQVAsQ0FBNEIsU0FBNUI7TUFDTixjQUFBLEdBQWlCLEdBQUcsQ0FBQyxNQUFKLENBQVcsSUFBWDtNQUNqQixJQUFDLENBQUEsTUFBRCxHQUFVLE1BQU0sQ0FBQyxlQUFQLENBQXVCLENBQUMsQ0FBQyxTQUFELEVBQVksY0FBWixDQUFELEVBQThCLENBQUMsU0FBRCxFQUFZLEdBQUcsQ0FBQyxNQUFoQixDQUE5QixDQUF2QjtNQUVWLElBQUMsQ0FBQSxxQkFBRCxHQUF5QjtNQUN6QixJQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwwQkFBaEIsQ0FBSDtRQUNFLE1BQU0sQ0FBQyxjQUFQLENBQXNCLElBQUMsQ0FBQSxNQUF2QixFQUErQjtVQUFDLElBQUEsRUFBTSxXQUFQO1VBQW9CLENBQUEsS0FBQSxDQUFBLEVBQU8sc0JBQTNCO1NBQS9CLEVBREY7O01BRUEsSUFBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsZ0NBQWhCLENBQUg7UUFDRSxNQUFNLENBQUMsY0FBUCxDQUFzQixJQUFDLENBQUEsTUFBdkIsRUFBK0I7VUFBQyxJQUFBLEVBQU0sYUFBUDtVQUFzQixDQUFBLEtBQUEsQ0FBQSxFQUFPLHNCQUE3QjtTQUEvQixFQURGOztNQUVBLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDRCQUFoQixDQUFIO1FBQ0UsSUFBQyxDQUFBLGFBQWEsQ0FBQyxhQUFmLENBQTZCLFNBQTdCO2VBQ0EsSUFBQyxDQUFBLFVBQVUsQ0FBQyxJQUFaLENBQUEsRUFGRjs7SUFYYyxDQS9LaEI7SUE4TEEsV0FBQSxFQUFhLFNBQUE7TUFDWCxDQUFBLEdBQUksT0FBQSxDQUFRLGlCQUFSO2FBQ0osYUFBQSxHQUFnQixPQUFBLENBQVEsbUJBQVI7SUFGTCxDQTlMYjs7QUFMRiIsInNvdXJjZXNDb250ZW50IjpbIntDb21wb3NpdGVEaXNwb3NhYmxlLCBQb2ludH0gPSByZXF1aXJlICdhdG9tJ1xuXyA9IG51bGxcblJ1YnlCbG9ja1ZpZXcgPSBudWxsXG5cbm1vZHVsZS5leHBvcnRzID0gUnVieUJsb2NrID1cbiAgY29uZmlnOlxuICAgIHNob3dCb3R0b21QYW5lbDpcbiAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgZGVmYXVsdDogdHJ1ZVxuICAgIGhpZ2hsaWdodExpbmU6XG4gICAgICB0eXBlOiAnYm9vbGVhbidcbiAgICAgIGRlZmF1bHQ6IHRydWVcbiAgICBoaWdobGlnaHRMaW5lTnVtYmVyOlxuICAgICAgdHlwZTogJ2Jvb2xlYW4nXG4gICAgICBkZWZhdWx0OiBmYWxzZVxuXG5cbiAgcnVieUJsb2NrVmlldzogbnVsbFxuICBtb2RhbFBhbmVsOiBudWxsXG4gIHJ1YnlSb290U2NvcGU6ICdzb3VyY2UucnVieSdcblxuICBydWJ5U3RhcnRCbG9ja05hbWVzOiBbXG4gICAgJ2ZvcidcbiAgICAnaWYnXG4gICAgJ3VubGVzcydcbiAgICAndW50aWwnXG4gICAgJ3doaWxlJ1xuICAgICdjbGFzcydcbiAgICAnbW9kdWxlJ1xuICAgICdjYXNlJ1xuICAgICdkZWYnXG4gICAgJ2JlZ2luJ1xuICAgICdkZXNjcmliZSdcbiAgICAnY29udGV4dCdcbiAgXVxuICBydWJ5U3RhcnRCbG9ja1Njb3BlczogW1xuICAgICAna2V5d29yZC5jb250cm9sLnJ1YnknXG4gICAgICdrZXl3b3JkLmNvbnRyb2wuc3RhcnQtYmxvY2sucnVieSdcbiAgICAgJ2tleXdvcmQuY29udHJvbC5jbGFzcy5ydWJ5J1xuICAgICAna2V5d29yZC5jb250cm9sLm1vZHVsZS5ydWJ5J1xuICAgICAna2V5d29yZC5jb250cm9sLmRlZi5ydWJ5J1xuICAgICAnbWV0YS5yc3BlYy5iZWhhdmlvdXInXG4gIF1cblxuICBydWJ5V2hpbGVCbG9ja05hbWU6ICd3aGlsZSdcbiAgcnVieURvQmxvY2tOYW1lOiAnZG8nXG4gIHJ1YnlFbmRCbG9ja05hbWU6ICdlbmQnXG5cbiAgcnVieUtleXdvcmRDb250cm9sU2NvcGU6ICdrZXl3b3JkLmNvbnRyb2wucnVieSdcbiAgcnVieUtleXdvcmRDb250cm9sTmFtZXM6IFtcbiAgICAnZW5kJ1xuICAgICdlbHNpZidcbiAgICAnZWxzZSdcbiAgICAnd2hlbidcbiAgICAncmVzY3VlJ1xuICAgICdlbnN1cmUnXG4gIF1cblxuICBydWJ5RG9TY29wZTogJ2tleXdvcmQuY29udHJvbC5zdGFydC1ibG9jay5ydWJ5J1xuXG4gIGVuZEJsb2NrU3RhY2s6IFtdXG5cbiAgYWN0aXZhdGU6IC0+XG4gICAgIyBFdmVudHMgc3Vic2NyaWJlZCB0byBpbiBhdG9tJ3Mgc3lzdGVtIGNhbiBiZSBlYXNpbHkgY2xlYW5lZCB1cCB3aXRoIGEgQ29tcG9zaXRlRGlzcG9zYWJsZVxuICAgIEBhY3RpdmVJdGVtU3Vic2NyaXB0aW9uID0gYXRvbS53b3Jrc3BhY2Uub2JzZXJ2ZUFjdGl2ZVBhbmVJdGVtKCA9PiBAc3Vic2NyaWJlVG9BY3RpdmVUZXh0RWRpdG9yKCkpXG5cbiAgZGVhY3RpdmF0ZTogLT5cbiAgICBAbWFya2VyPy5kZXN0cm95KClcbiAgICBAbWFya2VyID0gbnVsbFxuICAgIEBtb2RhbFBhbmVsPy5kZXN0cm95KClcbiAgICBAbW9kYWxQYW5lbCA9IG51bGxcbiAgICBAYWN0aXZlSXRlbVN1YnNjcmlwdGlvbj8uZGlzcG9zZSgpXG4gICAgQGFjdGl2ZUl0ZW1TdWJzY3JpcHRpb24gPSBudWxsXG4gICAgQGVkaXRvclN1YnNjcmlwdGlvbnM/LmRpc3Bvc2UoKVxuICAgIEBlZGl0b3JTdWJzY3JpcHRpb25zID0gbnVsbFxuICAgIEBydWJ5QmxvY2tWaWV3Py5kZXN0cm95KClcbiAgICBAcnVieUJsb2NrVmlldyA9IG51bGxcblxuICBpbml0OiAtPlxuICAgIEBsb2FkQ2xhc3NlcygpIHVubGVzcyBSdWJ5QmxvY2tWaWV3IGFuZCBfXG4gICAgQHJ1YnlCbG9ja1ZpZXcgPSBuZXcgUnVieUJsb2NrVmlld1xuICAgIEBtb2RhbFBhbmVsID0gYXRvbS53b3Jrc3BhY2UuYWRkQm90dG9tUGFuZWwoaXRlbTogQHJ1YnlCbG9ja1ZpZXcuZ2V0RWxlbWVudCgpLCB2aXNpYmxlOiBmYWxzZSwgcHJpb3JpdHk6IDUwMClcblxuICBnZXRBY3RpdmVUZXh0RWRpdG9yOiAtPlxuICAgIGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVRleHRFZGl0b3IoKVxuXG4gIGdvVG9NYXRjaGluZ0xpbmU6IC0+XG4gICAgcmV0dXJuIGF0b20uYmVlcCgpIHVubGVzcyBAYmxvY2tTdGFydGVkUm93TnVtYmVyP1xuICAgIGVkaXRvciA9IEBnZXRBY3RpdmVUZXh0RWRpdG9yKClcbiAgICByb3cgPSBlZGl0b3IubGluZVRleHRGb3JCdWZmZXJSb3coQGJsb2NrU3RhcnRlZFJvd051bWJlcilcbiAgICBmaXJzdENoYXJQb2ludCA9IHJvdy5zZWFyY2goL1xcUy8pXG4gICAgZWRpdG9yLnNldEN1cnNvckJ1ZmZlclBvc2l0aW9uKFtAYmxvY2tTdGFydGVkUm93TnVtYmVyLCBmaXJzdENoYXJQb2ludF0pXG5cbiAgc3Vic2NyaWJlVG9BY3RpdmVUZXh0RWRpdG9yOiAtPlxuICAgIEBtYXJrZXI/LmRlc3Ryb3koKVxuICAgIEBtb2RhbFBhbmVsLmhpZGUoKSBpZiBAbW9kYWxQYW5lbD8uaXNWaXNpYmxlKClcblxuICAgIEBlZGl0b3JTdWJzY3JpcHRpb25zPy5kaXNwb3NlKClcbiAgICBlZGl0b3IgPSBAZ2V0QWN0aXZlVGV4dEVkaXRvcigpXG5cbiAgICByZXR1cm4gdW5sZXNzIGVkaXRvcj9cbiAgICByZXR1cm4gaWYgZWRpdG9yLmdldFJvb3RTY29wZURlc2NyaXB0b3IoKS5zY29wZXNbMF0uaW5kZXhPZihAcnVieVJvb3RTY29wZSkgaXMgLTFcblxuICAgIEBpbml0KCkgdW5sZXNzIEBydWJ5QmxvY2tWaWV3P1xuXG4gICAgZWRpdG9yRWxlbWVudCA9IGF0b20udmlld3MuZ2V0VmlldyhlZGl0b3IpXG4gICAgQGVkaXRvclN1YnNjcmlwdGlvbnMgPSBuZXcgQ29tcG9zaXRlRGlzcG9zYWJsZVxuXG4gICAgQGVkaXRvclN1YnNjcmlwdGlvbnMuYWRkIGF0b20uY29tbWFuZHMuYWRkKGVkaXRvckVsZW1lbnQsXG4gICAgICAncnVieS1ibG9jazpnby10by1tYXRjaGluZy1saW5lJzogPT5cbiAgICAgICAgQGdvVG9NYXRjaGluZ0xpbmUoKVxuICAgIClcblxuICAgICMgQGVkaXRvclN1YnNjcmlwdGlvbnMuYWRkKGVkaXRvci5vbkRpZENoYW5nZUN1cnNvclBvc2l0aW9uKEBkZWJvdW5jZWRDdXJzb3JDaGFuZ2VkQ2FsbGJhY2spKVxuICAgIEBlZGl0b3JTdWJzY3JpcHRpb25zLmFkZChlZGl0b3Iub25EaWRDaGFuZ2VDdXJzb3JQb3NpdGlvbihfLmRlYm91bmNlKCA9PlxuICAgICAgcmV0dXJuIHVubGVzcyBAZ2V0QWN0aXZlVGV4dEVkaXRvcigpIGlzIGVkaXRvclxuICAgICAgQGJsb2NrU3RhcnRlZFJvd051bWJlciA9IG51bGxcbiAgICAgIEBtb2RhbFBhbmVsLmhpZGUoKSBpZiBAbW9kYWxQYW5lbC5pc1Zpc2libGUoKVxuICAgICAgQG1hcmtlcj8uZGVzdHJveSgpXG4gICAgICBAc2VhcmNoRm9yQmxvY2soKVxuICAgICwgMTAwKSkpXG5cbiAgICBAc2VhcmNoRm9yQmxvY2soKVxuXG4gIHNlYXJjaEZvckJsb2NrOiAtPlxuICAgIGVkaXRvciA9IEBnZXRBY3RpdmVUZXh0RWRpdG9yKClcbiAgICBncmFtbWFyID0gZWRpdG9yLmdldEdyYW1tYXIoKVxuICAgIGN1cnNvciA9IGVkaXRvci5nZXRMYXN0Q3Vyc29yKClcbiAgICBjdXJyZW50Um93TnVtYmVyID0gY3Vyc29yLmdldEJ1ZmZlclJvdygpXG5cbiAgICAjIHNjb3BlIGFuZCB3b3JkIG1hdGNoZXMgJ2VuZCdcbiAgICByZXR1cm4gaWYgY3Vyc29yLmdldFNjb3BlRGVzY3JpcHRvcigpLnNjb3Blcy5pbmRleE9mKEBydWJ5S2V5d29yZENvbnRyb2xTY29wZSkgaXMgLTEgb3JcbiAgICAgICAgICAgICAgQHJ1YnlLZXl3b3JkQ29udHJvbE5hbWVzLmluZGV4T2YoZWRpdG9yLmdldFdvcmRVbmRlckN1cnNvcigpKSBpcyAtMVxuXG4gICAgQGVuZEJsb2NrU3RhY2sucHVzaChlZGl0b3IuZ2V0V29yZFVuZGVyQ3Vyc29yKVxuXG4gICAgIyBpdGVyYXRlIGxpbmVzIGFib3ZlIHRoZSBjdXJzb3JcbiAgICBmb3Igcm93TnVtYmVyIGluIFtjdXJzb3IuZ2V0QnVmZmVyUm93KCkuLjBdXG4gICAgICBjb250aW51ZSBpZiBlZGl0b3IuaXNCdWZmZXJSb3dDb21tZW50ZWQocm93TnVtYmVyKVxuXG4gICAgICBpZiByb3dOdW1iZXIgaXMgY3VycmVudFJvd051bWJlclxuICAgICAgICBwcmV2V29yZEJvdW5kYXJ5UG9zID0gY3Vyc29yLmdldFByZXZpb3VzV29yZEJvdW5kYXJ5QnVmZmVyUG9zaXRpb24oKVxuICAgICAgICByb3cgPSBlZGl0b3IuZ2V0VGV4dEluQnVmZmVyUmFuZ2UoW1tyb3dOdW1iZXIsIDBdLCBwcmV2V29yZEJvdW5kYXJ5UG9zXSlcbiAgICAgIGVsc2VcbiAgICAgICAgcm93ID0gZWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KHJvd051bWJlcilcblxuICAgICAgdG9rZW5zID0gZ3JhbW1hci50b2tlbml6ZUxpbmUocm93KS50b2tlbnNcbiAgICAgIGZpbHRlcmVkVG9rZW5zID0gKHRva2VuIGZvciB0b2tlbixpIGluIHRva2VucyB3aGVuICF0b2tlbi52YWx1ZS5tYXRjaCAvXlxccyokLylcblxuICAgICAgc3RhcnRCbG9jayA9ICh0b2tlbiBmb3IgdG9rZW4gaW4gZmlsdGVyZWRUb2tlbnMgd2hlbiB0b2tlbi5zY29wZXMuaW5kZXhPZihAcnVieURvU2NvcGUpID49IDApXG4gICAgICBpZiBzdGFydEJsb2NrLmxlbmd0aCA+IDBcbiAgICAgICAgaWYgdG9rZW4udmFsdWUgaXNudCBAcnVieURvQmxvY2tOYW1lIG9yXG4gICAgICAgICAgIGZpbHRlcmVkVG9rZW5zWzBdLnZhbHVlIGlzbnQgQHJ1YnlXaGlsZUJsb2NrTmFtZVxuICAgICAgICAgIEBlbmRCbG9ja1N0YWNrLnBvcCgpXG4gICAgICAgIGlmIEBlbmRCbG9ja1N0YWNrLmxlbmd0aCBpcyAwXG4gICAgICAgICAgcmV0dXJuIEBoaWdobGlnaHRCbG9jayhyb3dOdW1iZXIpXG5cbiAgICAgIGZvciB0b2tlbiBpbiBmaWx0ZXJlZFRva2VucyBieSAtMVxuICAgICAgICBmb3Igc2NvcGUgaW4gdG9rZW4uc2NvcGVzXG4gICAgICAgICAgaWYgc2NvcGUgaXMgQHJ1YnlLZXl3b3JkQ29udHJvbFNjb3BlIGFuZCB0b2tlbi52YWx1ZSBpcyBAcnVieUVuZEJsb2NrTmFtZVxuICAgICAgICAgICAgQGVuZEJsb2NrU3RhY2sucHVzaChzY29wZS52YWx1ZSlcbiAgICAgICAgICBlbHNlIGlmIEBydWJ5U3RhcnRCbG9ja1Njb3Blcy5pbmRleE9mKHNjb3BlKSA+PSAwIGFuZFxuICAgICAgICAgICAgICAgICAgQHJ1YnlTdGFydEJsb2NrTmFtZXMuaW5kZXhPZih0b2tlbi52YWx1ZSkgPj0gMFxuICAgICAgICAgICAgIyBTdXBwb3J0IGFzc2lnbmluZyB2YXJpYWJsZSB3aXRoIGEgY2FzZSBzdGF0ZW1lbnRcbiAgICAgICAgICAgICMgZS5nLlxuICAgICAgICAgICAgIyB2YXIgPSBjYXNlIGNvbmRcbiAgICAgICAgICAgICMgICAgICAgd2hlbiAxIHRoZW4gMTBcbiAgICAgICAgICAgICMgICAgICAgZW5kXG4gICAgICAgICAgICBpZiB0b2tlbi52YWx1ZSBpcyAnY2FzZSdcbiAgICAgICAgICAgICAgQGVuZEJsb2NrU3RhY2sucG9wKClcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgZm9yIGZpcnN0VG9rZW5TY29wZSBpbiBmaWx0ZXJlZFRva2Vuc1swXS5zY29wZXNcbiAgICAgICAgICAgICAgICBpZiBAcnVieVN0YXJ0QmxvY2tTY29wZXMuaW5kZXhPZihmaXJzdFRva2VuU2NvcGUpID49IDAgYW5kXG4gICAgICAgICAgICAgICAgICAgQHJ1YnlTdGFydEJsb2NrTmFtZXMuaW5kZXhPZihmaWx0ZXJlZFRva2Vuc1swXS52YWx1ZSkgPj0gMFxuICAgICAgICAgICAgICAgICAgQGVuZEJsb2NrU3RhY2sucG9wKClcbiAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgIGlmIEBlbmRCbG9ja1N0YWNrLmxlbmd0aCBpcyAwXG4gICAgICAgICAgICAgIHJldHVybiBAaGlnaGxpZ2h0QmxvY2socm93TnVtYmVyKVxuXG4gIGhpZ2hsaWdodEJsb2NrOiAocm93TnVtYmVyKS0+XG4gICAgZWRpdG9yID0gQGdldEFjdGl2ZVRleHRFZGl0b3IoKVxuICAgIHJvdyA9IGVkaXRvci5saW5lVGV4dEZvckJ1ZmZlclJvdyhyb3dOdW1iZXIpXG4gICAgZmlyc3RDaGFyUG9pbnQgPSByb3cuc2VhcmNoKC9cXFMvKVxuICAgIEBtYXJrZXIgPSBlZGl0b3IubWFya0J1ZmZlclJhbmdlKFtbcm93TnVtYmVyLCBmaXJzdENoYXJQb2ludF0sIFtyb3dOdW1iZXIsIHJvdy5sZW5ndGhdXSlcblxuICAgIEBibG9ja1N0YXJ0ZWRSb3dOdW1iZXIgPSByb3dOdW1iZXJcbiAgICBpZiBhdG9tLmNvbmZpZy5nZXQoJ3J1YnktYmxvY2suaGlnaGxpZ2h0TGluZScpXG4gICAgICBlZGl0b3IuZGVjb3JhdGVNYXJrZXIoQG1hcmtlciwge3R5cGU6ICdoaWdobGlnaHQnLCBjbGFzczogJ3J1YnktYmxvY2staGlnaGxpZ2h0J30pXG4gICAgaWYgYXRvbS5jb25maWcuZ2V0KCdydWJ5LWJsb2NrLmhpZ2hsaWdodExpbmVOdW1iZXInKVxuICAgICAgZWRpdG9yLmRlY29yYXRlTWFya2VyKEBtYXJrZXIsIHt0eXBlOiAnbGluZS1udW1iZXInLCBjbGFzczogJ3J1YnktYmxvY2staGlnaGxpZ2h0J30pXG4gICAgaWYgYXRvbS5jb25maWcuZ2V0KCdydWJ5LWJsb2NrLnNob3dCb3R0b21QYW5lbCcpXG4gICAgICBAcnVieUJsb2NrVmlldy51cGRhdGVNZXNzYWdlKHJvd051bWJlcilcbiAgICAgIEBtb2RhbFBhbmVsLnNob3coKVxuXG4gIGxvYWRDbGFzc2VzOiAtPlxuICAgIF8gPSByZXF1aXJlICd1bmRlcnNjb3JlLXBsdXMnXG4gICAgUnVieUJsb2NrVmlldyA9IHJlcXVpcmUgJy4vcnVieS1ibG9jay12aWV3J1xuIl19
