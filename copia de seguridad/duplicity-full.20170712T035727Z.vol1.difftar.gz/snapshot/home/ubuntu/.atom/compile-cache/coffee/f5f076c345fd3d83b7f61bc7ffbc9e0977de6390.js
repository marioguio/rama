(function() {
  var Command;

  Command = require('../lib/command');

  describe("Command", function() {
    describe("testSingleCommand", function() {
      it("returns the ruby-test.rspecSingleCommand config value for the rspec framework", function() {
        var actualValue;
        atom.config.set("ruby-test.rspecSingleCommand", "rspec command");
        actualValue = Command.testSingleCommand("rspec");
        return expect(actualValue).toBe("rspec command");
      });
      return it("returns undefined when given an unrecognized framework", function() {
        var actualValue;
        actualValue = Command.testSingleCommand("unknown");
        return expect(actualValue).toBe(void 0);
      });
    });
    describe("testFileCommand", function() {
      it("returns the ruby-test.rspecFileCommand config value for the rspec framework", function() {
        var actualValue;
        atom.config.set("ruby-test.rspecFileCommand", "rspec command");
        actualValue = Command.testFileCommand("rspec");
        return expect(actualValue).toBe("rspec command");
      });
      it("returns the ruby-test.minitestFileCommand config value for the minitest framework", function() {
        var actualValue;
        atom.config.set("ruby-test.minitestFileCommand", "minitest command");
        actualValue = Command.testFileCommand("minitest");
        return expect(actualValue).toBe("minitest command");
      });
      it("returns the ruby-test.cucumberFileCommand config value for the cucumber framework", function() {
        var actualValue;
        atom.config.set("ruby-test.cucumberFileCommand", "cucumber command");
        actualValue = Command.testFileCommand("cucumber");
        return expect(actualValue).toBe("cucumber command");
      });
      return it("returns undefined when given an unrecognized framework", function() {
        var actualValue;
        actualValue = Command.testFileCommand("unknown");
        return expect(actualValue).toBe(void 0);
      });
    });
    return describe("testAllCommand", function() {
      it("returns the ruby-test.rspecAllCommand config value for the rspec framework", function() {
        var actualValue;
        atom.config.set("ruby-test.rspecAllCommand", "rspec command");
        actualValue = Command.testAllCommand("rspec");
        return expect(actualValue).toBe("rspec command");
      });
      return it("returns undefined when given an unrecognized framework", function() {
        var actualValue;
        actualValue = Command.testAllCommand("unknown");
        return expect(actualValue).toBe(void 0);
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9zcGVjL2NvbW1hbmQtc3BlYy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLE9BQUEsR0FBVSxPQUFBLENBQVEsZ0JBQVI7O0VBT1YsUUFBQSxDQUFTLFNBQVQsRUFBb0IsU0FBQTtJQUNsQixRQUFBLENBQVMsbUJBQVQsRUFBOEIsU0FBQTtNQUM1QixFQUFBLENBQUcsK0VBQUgsRUFBb0YsU0FBQTtBQUNsRixZQUFBO1FBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDhCQUFoQixFQUFnRCxlQUFoRDtRQUNBLFdBQUEsR0FBYyxPQUFPLENBQUMsaUJBQVIsQ0FBMEIsT0FBMUI7ZUFDZCxNQUFBLENBQU8sV0FBUCxDQUFtQixDQUFDLElBQXBCLENBQXlCLGVBQXpCO01BSGtGLENBQXBGO2FBS0EsRUFBQSxDQUFHLHdEQUFILEVBQTZELFNBQUE7QUFDM0QsWUFBQTtRQUFBLFdBQUEsR0FBYyxPQUFPLENBQUMsaUJBQVIsQ0FBMEIsU0FBMUI7ZUFDZCxNQUFBLENBQU8sV0FBUCxDQUFtQixDQUFDLElBQXBCLENBQXlCLE1BQXpCO01BRjJELENBQTdEO0lBTjRCLENBQTlCO0lBVUEsUUFBQSxDQUFTLGlCQUFULEVBQTRCLFNBQUE7TUFDMUIsRUFBQSxDQUFHLDZFQUFILEVBQWtGLFNBQUE7QUFDaEYsWUFBQTtRQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiw0QkFBaEIsRUFBOEMsZUFBOUM7UUFDQSxXQUFBLEdBQWMsT0FBTyxDQUFDLGVBQVIsQ0FBd0IsT0FBeEI7ZUFDZCxNQUFBLENBQU8sV0FBUCxDQUFtQixDQUFDLElBQXBCLENBQXlCLGVBQXpCO01BSGdGLENBQWxGO01BS0EsRUFBQSxDQUFHLG1GQUFILEVBQXdGLFNBQUE7QUFDdEYsWUFBQTtRQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwrQkFBaEIsRUFBaUQsa0JBQWpEO1FBQ0EsV0FBQSxHQUFjLE9BQU8sQ0FBQyxlQUFSLENBQXdCLFVBQXhCO2VBQ2QsTUFBQSxDQUFPLFdBQVAsQ0FBbUIsQ0FBQyxJQUFwQixDQUF5QixrQkFBekI7TUFIc0YsQ0FBeEY7TUFLQSxFQUFBLENBQUcsbUZBQUgsRUFBd0YsU0FBQTtBQUN0RixZQUFBO1FBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLCtCQUFoQixFQUFpRCxrQkFBakQ7UUFDQSxXQUFBLEdBQWMsT0FBTyxDQUFDLGVBQVIsQ0FBd0IsVUFBeEI7ZUFDZCxNQUFBLENBQU8sV0FBUCxDQUFtQixDQUFDLElBQXBCLENBQXlCLGtCQUF6QjtNQUhzRixDQUF4RjthQUtBLEVBQUEsQ0FBRyx3REFBSCxFQUE2RCxTQUFBO0FBQzNELFlBQUE7UUFBQSxXQUFBLEdBQWMsT0FBTyxDQUFDLGVBQVIsQ0FBd0IsU0FBeEI7ZUFDZCxNQUFBLENBQU8sV0FBUCxDQUFtQixDQUFDLElBQXBCLENBQXlCLE1BQXpCO01BRjJELENBQTdEO0lBaEIwQixDQUE1QjtXQW9CQSxRQUFBLENBQVMsZ0JBQVQsRUFBMkIsU0FBQTtNQUN6QixFQUFBLENBQUcsNEVBQUgsRUFBaUYsU0FBQTtBQUMvRSxZQUFBO1FBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDJCQUFoQixFQUE2QyxlQUE3QztRQUNBLFdBQUEsR0FBYyxPQUFPLENBQUMsY0FBUixDQUF1QixPQUF2QjtlQUNkLE1BQUEsQ0FBTyxXQUFQLENBQW1CLENBQUMsSUFBcEIsQ0FBeUIsZUFBekI7TUFIK0UsQ0FBakY7YUFLQSxFQUFBLENBQUcsd0RBQUgsRUFBNkQsU0FBQTtBQUMzRCxZQUFBO1FBQUEsV0FBQSxHQUFjLE9BQU8sQ0FBQyxjQUFSLENBQXVCLFNBQXZCO2VBQ2QsTUFBQSxDQUFPLFdBQVAsQ0FBbUIsQ0FBQyxJQUFwQixDQUF5QixNQUF6QjtNQUYyRCxDQUE3RDtJQU55QixDQUEzQjtFQS9Ca0IsQ0FBcEI7QUFQQSIsInNvdXJjZXNDb250ZW50IjpbIkNvbW1hbmQgPSByZXF1aXJlICcuLi9saWIvY29tbWFuZCdcblxuIyBVc2UgdGhlIGNvbW1hbmQgYHdpbmRvdzpydW4tcGFja2FnZS1zcGVjc2AgKGNtZC1hbHQtY3RybC1wKSB0byBydW4gc3BlY3MuXG4jXG4jIFRvIHJ1biBhIHNwZWNpZmljIGBpdGAgb3IgYGRlc2NyaWJlYCBibG9jayBhZGQgYW4gYGZgIHRvIHRoZSBmcm9udCAoZS5nLiBgZml0YFxuIyBvciBgZmRlc2NyaWJlYCkuIFJlbW92ZSB0aGUgYGZgIHRvIHVuZm9jdXMgdGhlIGJsb2NrLlxuXG5kZXNjcmliZSBcIkNvbW1hbmRcIiwgLT5cbiAgZGVzY3JpYmUgXCJ0ZXN0U2luZ2xlQ29tbWFuZFwiLCAtPlxuICAgIGl0IFwicmV0dXJucyB0aGUgcnVieS10ZXN0LnJzcGVjU2luZ2xlQ29tbWFuZCBjb25maWcgdmFsdWUgZm9yIHRoZSByc3BlYyBmcmFtZXdvcmtcIiwgLT5cbiAgICAgIGF0b20uY29uZmlnLnNldChcInJ1YnktdGVzdC5yc3BlY1NpbmdsZUNvbW1hbmRcIiwgXCJyc3BlYyBjb21tYW5kXCIpXG4gICAgICBhY3R1YWxWYWx1ZSA9IENvbW1hbmQudGVzdFNpbmdsZUNvbW1hbmQoXCJyc3BlY1wiKVxuICAgICAgZXhwZWN0KGFjdHVhbFZhbHVlKS50b0JlKFwicnNwZWMgY29tbWFuZFwiKVxuXG4gICAgaXQgXCJyZXR1cm5zIHVuZGVmaW5lZCB3aGVuIGdpdmVuIGFuIHVucmVjb2duaXplZCBmcmFtZXdvcmtcIiwgLT5cbiAgICAgIGFjdHVhbFZhbHVlID0gQ29tbWFuZC50ZXN0U2luZ2xlQ29tbWFuZChcInVua25vd25cIilcbiAgICAgIGV4cGVjdChhY3R1YWxWYWx1ZSkudG9CZSh1bmRlZmluZWQpXG5cbiAgZGVzY3JpYmUgXCJ0ZXN0RmlsZUNvbW1hbmRcIiwgLT5cbiAgICBpdCBcInJldHVybnMgdGhlIHJ1YnktdGVzdC5yc3BlY0ZpbGVDb21tYW5kIGNvbmZpZyB2YWx1ZSBmb3IgdGhlIHJzcGVjIGZyYW1ld29ya1wiLCAtPlxuICAgICAgYXRvbS5jb25maWcuc2V0KFwicnVieS10ZXN0LnJzcGVjRmlsZUNvbW1hbmRcIiwgXCJyc3BlYyBjb21tYW5kXCIpXG4gICAgICBhY3R1YWxWYWx1ZSA9IENvbW1hbmQudGVzdEZpbGVDb21tYW5kKFwicnNwZWNcIilcbiAgICAgIGV4cGVjdChhY3R1YWxWYWx1ZSkudG9CZShcInJzcGVjIGNvbW1hbmRcIilcblxuICAgIGl0IFwicmV0dXJucyB0aGUgcnVieS10ZXN0Lm1pbml0ZXN0RmlsZUNvbW1hbmQgY29uZmlnIHZhbHVlIGZvciB0aGUgbWluaXRlc3QgZnJhbWV3b3JrXCIsIC0+XG4gICAgICBhdG9tLmNvbmZpZy5zZXQoXCJydWJ5LXRlc3QubWluaXRlc3RGaWxlQ29tbWFuZFwiLCBcIm1pbml0ZXN0IGNvbW1hbmRcIilcbiAgICAgIGFjdHVhbFZhbHVlID0gQ29tbWFuZC50ZXN0RmlsZUNvbW1hbmQoXCJtaW5pdGVzdFwiKVxuICAgICAgZXhwZWN0KGFjdHVhbFZhbHVlKS50b0JlKFwibWluaXRlc3QgY29tbWFuZFwiKVxuXG4gICAgaXQgXCJyZXR1cm5zIHRoZSBydWJ5LXRlc3QuY3VjdW1iZXJGaWxlQ29tbWFuZCBjb25maWcgdmFsdWUgZm9yIHRoZSBjdWN1bWJlciBmcmFtZXdvcmtcIiwgLT5cbiAgICAgIGF0b20uY29uZmlnLnNldChcInJ1YnktdGVzdC5jdWN1bWJlckZpbGVDb21tYW5kXCIsIFwiY3VjdW1iZXIgY29tbWFuZFwiKVxuICAgICAgYWN0dWFsVmFsdWUgPSBDb21tYW5kLnRlc3RGaWxlQ29tbWFuZChcImN1Y3VtYmVyXCIpXG4gICAgICBleHBlY3QoYWN0dWFsVmFsdWUpLnRvQmUoXCJjdWN1bWJlciBjb21tYW5kXCIpXG5cbiAgICBpdCBcInJldHVybnMgdW5kZWZpbmVkIHdoZW4gZ2l2ZW4gYW4gdW5yZWNvZ25pemVkIGZyYW1ld29ya1wiLCAtPlxuICAgICAgYWN0dWFsVmFsdWUgPSBDb21tYW5kLnRlc3RGaWxlQ29tbWFuZChcInVua25vd25cIilcbiAgICAgIGV4cGVjdChhY3R1YWxWYWx1ZSkudG9CZSh1bmRlZmluZWQpXG5cbiAgZGVzY3JpYmUgXCJ0ZXN0QWxsQ29tbWFuZFwiLCAtPlxuICAgIGl0IFwicmV0dXJucyB0aGUgcnVieS10ZXN0LnJzcGVjQWxsQ29tbWFuZCBjb25maWcgdmFsdWUgZm9yIHRoZSByc3BlYyBmcmFtZXdvcmtcIiwgLT5cbiAgICAgIGF0b20uY29uZmlnLnNldChcInJ1YnktdGVzdC5yc3BlY0FsbENvbW1hbmRcIiwgXCJyc3BlYyBjb21tYW5kXCIpXG4gICAgICBhY3R1YWxWYWx1ZSA9IENvbW1hbmQudGVzdEFsbENvbW1hbmQoXCJyc3BlY1wiKVxuICAgICAgZXhwZWN0KGFjdHVhbFZhbHVlKS50b0JlKFwicnNwZWMgY29tbWFuZFwiKVxuXG4gICAgaXQgXCJyZXR1cm5zIHVuZGVmaW5lZCB3aGVuIGdpdmVuIGFuIHVucmVjb2duaXplZCBmcmFtZXdvcmtcIiwgLT5cbiAgICAgIGFjdHVhbFZhbHVlID0gQ29tbWFuZC50ZXN0QWxsQ29tbWFuZChcInVua25vd25cIilcbiAgICAgIGV4cGVjdChhY3R1YWxWYWx1ZSkudG9CZSh1bmRlZmluZWQpXG4iXX0=
