(function() {
  var SourceInfo, fs,
    indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  SourceInfo = require('../lib/source-info');

  fs = require('fs');

  describe("SourceInfo", function() {
    var editor, sourceInfo, withSetup;
    editor = null;
    sourceInfo = null;
    withSetup = function(opts) {
      var cursor, key, lines, ref, value;
      atom.project.getPaths = function() {
        return ["/projects/project_1", "/projects/project_2"];
      };
      atom.project.relativize = function(filePath) {
        var folderPath, i, index, len, newPath, ref;
        ref = this.getPaths();
        for (i = 0, len = ref.length; i < len; i++) {
          folderPath = ref[i];
          index = filePath.indexOf(folderPath);
          if (index >= 0) {
            newPath = filePath.slice(index + folderPath.length, filePath.length);
            if (newPath[0] === '/') {
              newPath = newPath.slice(1, newPath.length);
            }
            return newPath;
          }
        }
      };
      editor = {
        buffer: {
          file: {
            path: "/projects/project_2/test/foo_test.rb"
          }
        }
      };
      cursor = {
        getBufferRow: function() {
          return 99;
        }
      };
      editor.getLastCursor = function() {
        return cursor;
      };
      editor.lineTextForBufferRow = function(line) {
        return "";
      };
      spyOn(atom.workspace, 'getActiveTextEditor').andReturn(editor);
      sourceInfo = new SourceInfo();
      if ('testFile' in opts) {
        editor.buffer.file.path = opts.testFile;
      }
      if ('projectPaths' in opts) {
        atom.project.getPaths = function() {
          return opts.projectPaths;
        };
      }
      if ('currentLine' in opts) {
        cursor.getBufferRow = function() {
          return opts.currentLine - 1;
        };
      }
      if ('fileContent' in opts) {
        lines = opts.fileContent.split("\n");
        editor.lineTextForBufferRow = function(row) {
          return lines[row];
        };
      }
      if ('config' in opts) {
        ref = opts.config;
        for (key in ref) {
          value = ref[key];
          atom.config.set(key, value);
        }
      }
      if ('mockPaths' in opts) {
        return spyOn(fs, 'existsSync').andCallFake(function(path) {
          return indexOf.call(opts.mockPaths, path) >= 0;
        });
      }
    };
    beforeEach(function() {
      editor = null;
      return sourceInfo = null;
    });
    describe("::projectPath", function() {
      describe("with no testFile", function() {
        return it("is atom.project.getPaths()[0]", function() {
          withSetup({
            projectPaths: ['/projects/project_1', '/projects/project_2'],
            testFile: null
          });
          return expect(sourceInfo.projectPath()).toBe("/projects/project_1");
        });
      });
      return describe("with a testFile", function() {
        return it("is the path within atom.project.getPaths() that is an ancestor of the testFile path", function() {
          withSetup({
            projectPaths: ['/projects/project_1', '/projects/project_2'],
            testFile: '/projects/project_2/foo/bar_test.rb'
          });
          return expect(sourceInfo.projectPath()).toBe("/projects/project_2");
        });
      });
    });
    describe("::testFramework", function() {
      describe("RSpec detection", function() {
        it("detects RSpec based on configuration value set to 'rspec'", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": "rspec"
            },
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_spec.rb',
            currentLine: 1,
            fileContent: ''
          });
          return expect(sourceInfo.testFramework()).toBe("rspec");
        });
        it("selects RSpec for spec file if spec_helper is required", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": ""
            },
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_spec.rb',
            currentLine: 5,
            fileContent: "require 'spec_helper'\n\ndescribe \"something\" do\n  it \"test something\" do\n    expect('foo').to eq 'foo'\n  end\nend"
          });
          return expect(sourceInfo.testFramework()).toBe("rspec");
        });
        it("selects RSpec for spec file if spec_helper is required with require_relative", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": ""
            },
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_spec.rb',
            currentLine: 2,
            fileContent: "require_relative '../spec_helper'\n"
          });
          return expect(sourceInfo.testFramework()).toBe("rspec");
        });
        return it("selects RSpec for spec file if expect() is called", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": ""
            },
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_spec.rb',
            currentLine: 5,
            fileContent: "describe \"something\" do\n  it \"test something\" do\n    expect('foo').to eq 'foo'\n  end\nend"
          });
          return expect(sourceInfo.testFramework()).toBe("rspec");
        });
      });
      describe("Minitest detection", function() {
        it("is Minitest if filename matches _test.rb, and file contains specs", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": ""
            },
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_test.rb',
            currentLine: 3,
            fileContent: "describe \"something\" do\n  it \"test something\" do\n    1.must_equal 1\n  end\nend"
          });
          return expect(sourceInfo.testFramework()).toBe("minitest");
        });
        it("detects Minitest based on configuration value set to 'minitest'", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": "minitest"
            },
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_spec.rb',
            currentLine: 1,
            fileContent: ''
          });
          return expect(sourceInfo.testFramework()).toBe("minitest");
        });
        it("is Minitest for a _test.rb file that contains Minitest::Test", function() {
          withSetup({
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_test.rb',
            currentLine: 3,
            fileContent: "class sometest < Minitest::Test\n  def something\n    assert_equal 1, 1\n  end\nend"
          });
          return expect(sourceInfo.testFramework()).toBe("minitest");
        });
        return it("when no test file is open, detects Minitest based on configuration value set to 'minitest'", function() {
          withSetup({
            config: {
              "ruby-test.specFramework": "minitest"
            },
            projectPaths: ['/home/user/project_1'],
            testFile: null,
            currentLine: null,
            mockPaths: ['/home/user/project_1/spec'],
            fileContent: ''
          });
          return expect(sourceInfo.testFramework()).toBe("minitest");
        });
      });
      describe("Test::Unit detection", function() {
        return it("assumes Test::Unit when the filename ends with _test.rb, has a method definition, and doesn't have a reference to Minitest", function() {
          withSetup({
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/bar/foo_test.rb',
            currentLine: 3,
            fileContent: "class sometest < Whatever::Unit\n  def something\n    assert_equal 1, 1\n  end\nend"
          });
          return expect(sourceInfo.testFramework()).toBe("test");
        });
      });
      return describe("Cucumber detection", function() {
        return it("correctly detects Cucumber file", function() {
          withSetup({
            projectPaths: ['/home/user/project_1'],
            testFile: '/home/user/project_1/foo/foo.feature',
            currentLine: 1,
            mockPaths: ['/home/user/project_1/spec', '/home/user/project_1/.rspec'],
            fileContent: "            "
          });
          return expect(sourceInfo.testFramework()).toBe("cucumber");
        });
      });
    });
    describe("::projectType", function() {
      it("correctly detects a test directory", function() {
        withSetup({
          projectPaths: ['/home/user/project_1'],
          testFile: null,
          mockPaths: ['/home/user/project_1/test']
        });
        return expect(sourceInfo.projectType()).toBe("test");
      });
      it("correctly detecs a spec directory", function() {
        withSetup({
          projectPaths: ['/home/user/project_1'],
          testFile: null,
          mockPaths: ['/home/user/project_1/spec']
        });
        return expect(sourceInfo.projectType()).toBe("rspec");
      });
      return it("correctly detects a cucumber directory", function() {
        withSetup({
          projectPaths: ['/home/user/project_1'],
          testFile: null,
          mockPaths: ['/home/user/project_1/features']
        });
        return expect(sourceInfo.projectType()).toBe("cucumber");
      });
    });
    describe("::activeFile", function() {
      return it("is the project-relative path for the current file path", function() {
        withSetup({
          projectPaths: ['/projects/project_1', '/projects/project_2'],
          testFile: '/projects/project_2/bar/foo_test.rb'
        });
        return expect(sourceInfo.activeFile()).toBe("bar/foo_test.rb");
      });
    });
    describe("::currentLine", function() {
      return it("is the cursor getBufferRow() plus 1", function() {
        withSetup({
          currentLine: 100
        });
        return expect(sourceInfo.currentLine()).toBe(100);
      });
    });
    describe("::minitestRegExp", function() {
      return it("correctly returns the matching regex for spec", function() {
        withSetup({
          projectPaths: ['/projects/project_1'],
          testFile: '/projects/project_1/bar/foo_test.rb',
          currentLine: 6,
          fileContent: "require 'minitest/spec'\nrequire 'minitest/autorun'\n\ndescribe \"Addition\" do\n  it \"adds\" do\n    (1 + 1).must_equal 2\n  end\nend"
        });
        return expect(sourceInfo.minitestRegExp()).toBe("adds");
      });
    });
    return describe("::minitestRegExp", function() {
      it("correctly returns the matching regex for spec", function() {
        sourceInfo = new SourceInfo();
        return expect(sourceInfo.extractMinitestRegExp(" it \"test something\" do", "spec")).toBe("test something");
      });
      it("correctly returns the matching regex for minitest unit", function() {
        sourceInfo = new SourceInfo();
        return expect(sourceInfo.extractMinitestRegExp(" def test_something", "unit")).toBe("test_something");
      });
      return it("should return empty string if no match", function() {
        sourceInfo = new SourceInfo();
        return expect(sourceInfo.extractMinitestRegExp("test something", "spec")).toBe("");
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9zcGVjL3NvdXJjZS1pbmZvLXNwZWMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQSxjQUFBO0lBQUE7O0VBQUEsVUFBQSxHQUFhLE9BQUEsQ0FBUSxvQkFBUjs7RUFDYixFQUFBLEdBQUssT0FBQSxDQUFRLElBQVI7O0VBRUwsUUFBQSxDQUFTLFlBQVQsRUFBdUIsU0FBQTtBQUNyQixRQUFBO0lBQUEsTUFBQSxHQUFTO0lBQ1QsVUFBQSxHQUFhO0lBRWIsU0FBQSxHQUFZLFNBQUMsSUFBRDtBQUNWLFVBQUE7TUFBQSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQWIsR0FBd0IsU0FBQTtlQUN0QixDQUFDLHFCQUFELEVBQXdCLHFCQUF4QjtNQURzQjtNQUV4QixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQWIsR0FBMEIsU0FBQyxRQUFEO0FBQ3hCLFlBQUE7QUFBQTtBQUFBLGFBQUEscUNBQUE7O1VBQ0UsS0FBQSxHQUFRLFFBQVEsQ0FBQyxPQUFULENBQWlCLFVBQWpCO1VBQ1IsSUFBRyxLQUFBLElBQVMsQ0FBWjtZQUNFLE9BQUEsR0FBVSxRQUFRLENBQUMsS0FBVCxDQUFlLEtBQUEsR0FBUSxVQUFVLENBQUMsTUFBbEMsRUFBMEMsUUFBUSxDQUFDLE1BQW5EO1lBQ1YsSUFBOEMsT0FBUSxDQUFBLENBQUEsQ0FBUixLQUFjLEdBQTVEO2NBQUEsT0FBQSxHQUFVLE9BQU8sQ0FBQyxLQUFSLENBQWMsQ0FBZCxFQUFpQixPQUFPLENBQUMsTUFBekIsRUFBVjs7QUFDQSxtQkFBTyxRQUhUOztBQUZGO01BRHdCO01BUTFCLE1BQUEsR0FBUztRQUFDLE1BQUEsRUFBUTtVQUFDLElBQUEsRUFBTTtZQUFDLElBQUEsRUFBTSxzQ0FBUDtXQUFQO1NBQVQ7O01BQ1QsTUFBQSxHQUFTO1FBQUEsWUFBQSxFQUFjLFNBQUE7aUJBQUc7UUFBSCxDQUFkOztNQUNULE1BQU0sQ0FBQyxhQUFQLEdBQXVCLFNBQUE7ZUFBRztNQUFIO01BQ3ZCLE1BQU0sQ0FBQyxvQkFBUCxHQUE4QixTQUFDLElBQUQ7ZUFBVTtNQUFWO01BQzlCLEtBQUEsQ0FBTSxJQUFJLENBQUMsU0FBWCxFQUFzQixxQkFBdEIsQ0FBNEMsQ0FBQyxTQUE3QyxDQUF1RCxNQUF2RDtNQUNBLFVBQUEsR0FBaUIsSUFBQSxVQUFBLENBQUE7TUFFakIsSUFBRyxVQUFBLElBQWMsSUFBakI7UUFDRSxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFuQixHQUEwQixJQUFJLENBQUMsU0FEakM7O01BR0EsSUFBRyxjQUFBLElBQWtCLElBQXJCO1FBQ0UsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFiLEdBQXdCLFNBQUE7aUJBQUcsSUFBSSxDQUFDO1FBQVIsRUFEMUI7O01BR0EsSUFBRyxhQUFBLElBQWlCLElBQXBCO1FBQ0UsTUFBTSxDQUFDLFlBQVAsR0FBc0IsU0FBQTtpQkFBRyxJQUFJLENBQUMsV0FBTCxHQUFtQjtRQUF0QixFQUR4Qjs7TUFHQSxJQUFHLGFBQUEsSUFBaUIsSUFBcEI7UUFDRSxLQUFBLEdBQVEsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFqQixDQUF1QixJQUF2QjtRQUNSLE1BQU0sQ0FBQyxvQkFBUCxHQUE4QixTQUFDLEdBQUQ7aUJBQzVCLEtBQU0sQ0FBQSxHQUFBO1FBRHNCLEVBRmhDOztNQUtBLElBQUcsUUFBQSxJQUFZLElBQWY7QUFDRTtBQUFBLGFBQUEsVUFBQTs7VUFDRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsR0FBaEIsRUFBcUIsS0FBckI7QUFERixTQURGOztNQUlBLElBQUcsV0FBQSxJQUFlLElBQWxCO2VBQ0UsS0FBQSxDQUFNLEVBQU4sRUFBVSxZQUFWLENBQXVCLENBQUMsV0FBeEIsQ0FBb0MsU0FBQyxJQUFEO2lCQUNsQyxhQUFRLElBQUksQ0FBQyxTQUFiLEVBQUEsSUFBQTtRQURrQyxDQUFwQyxFQURGOztJQXBDVTtJQXdDWixVQUFBLENBQVcsU0FBQTtNQUNULE1BQUEsR0FBUzthQUNULFVBQUEsR0FBYTtJQUZKLENBQVg7SUFJQSxRQUFBLENBQVMsZUFBVCxFQUEwQixTQUFBO01BQ3hCLFFBQUEsQ0FBUyxrQkFBVCxFQUE2QixTQUFBO2VBQzNCLEVBQUEsQ0FBRywrQkFBSCxFQUFvQyxTQUFBO1VBQ2xDLFNBQUEsQ0FDRTtZQUFBLFlBQUEsRUFBYyxDQUFDLHFCQUFELEVBQXdCLHFCQUF4QixDQUFkO1lBQ0EsUUFBQSxFQUFVLElBRFY7V0FERjtpQkFHQSxNQUFBLENBQU8sVUFBVSxDQUFDLFdBQVgsQ0FBQSxDQUFQLENBQWdDLENBQUMsSUFBakMsQ0FBc0MscUJBQXRDO1FBSmtDLENBQXBDO01BRDJCLENBQTdCO2FBTUEsUUFBQSxDQUFTLGlCQUFULEVBQTRCLFNBQUE7ZUFDMUIsRUFBQSxDQUFHLHFGQUFILEVBQTBGLFNBQUE7VUFDeEYsU0FBQSxDQUNFO1lBQUEsWUFBQSxFQUFjLENBQUMscUJBQUQsRUFBd0IscUJBQXhCLENBQWQ7WUFDQSxRQUFBLEVBQVUscUNBRFY7V0FERjtpQkFHQSxNQUFBLENBQU8sVUFBVSxDQUFDLFdBQVgsQ0FBQSxDQUFQLENBQWdDLENBQUMsSUFBakMsQ0FBc0MscUJBQXRDO1FBSndGLENBQTFGO01BRDBCLENBQTVCO0lBUHdCLENBQTFCO0lBZ0JBLFFBQUEsQ0FBUyxpQkFBVCxFQUE0QixTQUFBO01BQzFCLFFBQUEsQ0FBUyxpQkFBVCxFQUE0QixTQUFBO1FBQzFCLEVBQUEsQ0FBRywyREFBSCxFQUFnRSxTQUFBO1VBQzlELFNBQUEsQ0FDRTtZQUFBLE1BQUEsRUFBUTtjQUFBLHlCQUFBLEVBQTJCLE9BQTNCO2FBQVI7WUFDQSxZQUFBLEVBQWMsQ0FBQyxzQkFBRCxDQURkO1lBRUEsUUFBQSxFQUFVLHNDQUZWO1lBR0EsV0FBQSxFQUFhLENBSGI7WUFJQSxXQUFBLEVBQWEsRUFKYjtXQURGO2lCQU9BLE1BQUEsQ0FBTyxVQUFVLENBQUMsYUFBWCxDQUFBLENBQVAsQ0FBa0MsQ0FBQyxJQUFuQyxDQUF3QyxPQUF4QztRQVI4RCxDQUFoRTtRQVVBLEVBQUEsQ0FBRyx3REFBSCxFQUE2RCxTQUFBO1VBQzNELFNBQUEsQ0FDRTtZQUFBLE1BQUEsRUFBUTtjQUFBLHlCQUFBLEVBQTJCLEVBQTNCO2FBQVI7WUFDQSxZQUFBLEVBQWMsQ0FBQyxzQkFBRCxDQURkO1lBRUEsUUFBQSxFQUFVLHNDQUZWO1lBR0EsV0FBQSxFQUFhLENBSGI7WUFJQSxXQUFBLEVBQ0UsMkhBTEY7V0FERjtpQkFlQSxNQUFBLENBQU8sVUFBVSxDQUFDLGFBQVgsQ0FBQSxDQUFQLENBQWtDLENBQUMsSUFBbkMsQ0FBd0MsT0FBeEM7UUFoQjJELENBQTdEO1FBa0JBLEVBQUEsQ0FBRyw4RUFBSCxFQUFtRixTQUFBO1VBQ2pGLFNBQUEsQ0FDRTtZQUFBLE1BQUEsRUFBUTtjQUFBLHlCQUFBLEVBQTJCLEVBQTNCO2FBQVI7WUFDQSxZQUFBLEVBQWMsQ0FBQyxzQkFBRCxDQURkO1lBRUEsUUFBQSxFQUFVLHNDQUZWO1lBR0EsV0FBQSxFQUFhLENBSGI7WUFJQSxXQUFBLEVBQ0UscUNBTEY7V0FERjtpQkFVQSxNQUFBLENBQU8sVUFBVSxDQUFDLGFBQVgsQ0FBQSxDQUFQLENBQWtDLENBQUMsSUFBbkMsQ0FBd0MsT0FBeEM7UUFYaUYsQ0FBbkY7ZUFhQSxFQUFBLENBQUcsbURBQUgsRUFBd0QsU0FBQTtVQUN0RCxTQUFBLENBQ0U7WUFBQSxNQUFBLEVBQVE7Y0FBQSx5QkFBQSxFQUEyQixFQUEzQjthQUFSO1lBQ0EsWUFBQSxFQUFjLENBQUMsc0JBQUQsQ0FEZDtZQUVBLFFBQUEsRUFBVSxzQ0FGVjtZQUdBLFdBQUEsRUFBYSxDQUhiO1lBSUEsV0FBQSxFQUNFLGtHQUxGO1dBREY7aUJBYUEsTUFBQSxDQUFPLFVBQVUsQ0FBQyxhQUFYLENBQUEsQ0FBUCxDQUFrQyxDQUFDLElBQW5DLENBQXdDLE9BQXhDO1FBZHNELENBQXhEO01BMUMwQixDQUE1QjtNQTBEQSxRQUFBLENBQVMsb0JBQVQsRUFBK0IsU0FBQTtRQUM3QixFQUFBLENBQUcsbUVBQUgsRUFBd0UsU0FBQTtVQUN0RSxTQUFBLENBQ0U7WUFBQSxNQUFBLEVBQVE7Y0FBQSx5QkFBQSxFQUEyQixFQUEzQjthQUFSO1lBQ0EsWUFBQSxFQUFjLENBQUMsc0JBQUQsQ0FEZDtZQUVBLFFBQUEsRUFBVSxzQ0FGVjtZQUdBLFdBQUEsRUFBYSxDQUhiO1lBSUEsV0FBQSxFQUNFLHVGQUxGO1dBREY7aUJBYUEsTUFBQSxDQUFPLFVBQVUsQ0FBQyxhQUFYLENBQUEsQ0FBUCxDQUFrQyxDQUFDLElBQW5DLENBQXdDLFVBQXhDO1FBZHNFLENBQXhFO1FBZ0JBLEVBQUEsQ0FBRyxpRUFBSCxFQUFzRSxTQUFBO1VBQ3BFLFNBQUEsQ0FDRTtZQUFBLE1BQUEsRUFBUTtjQUFBLHlCQUFBLEVBQTJCLFVBQTNCO2FBQVI7WUFDQSxZQUFBLEVBQWMsQ0FBQyxzQkFBRCxDQURkO1lBRUEsUUFBQSxFQUFVLHNDQUZWO1lBR0EsV0FBQSxFQUFhLENBSGI7WUFJQSxXQUFBLEVBQWEsRUFKYjtXQURGO2lCQU9BLE1BQUEsQ0FBTyxVQUFVLENBQUMsYUFBWCxDQUFBLENBQVAsQ0FBa0MsQ0FBQyxJQUFuQyxDQUF3QyxVQUF4QztRQVJvRSxDQUF0RTtRQVVBLEVBQUEsQ0FBRyw4REFBSCxFQUFtRSxTQUFBO1VBQ2pFLFNBQUEsQ0FDRTtZQUFBLFlBQUEsRUFBYyxDQUFDLHNCQUFELENBQWQ7WUFDQSxRQUFBLEVBQVUsc0NBRFY7WUFFQSxXQUFBLEVBQWEsQ0FGYjtZQUdBLFdBQUEsRUFDRSxxRkFKRjtXQURGO2lCQVlBLE1BQUEsQ0FBTyxVQUFVLENBQUMsYUFBWCxDQUFBLENBQVAsQ0FBa0MsQ0FBQyxJQUFuQyxDQUF3QyxVQUF4QztRQWJpRSxDQUFuRTtlQWVBLEVBQUEsQ0FBRyw0RkFBSCxFQUFpRyxTQUFBO1VBQy9GLFNBQUEsQ0FDRTtZQUFBLE1BQUEsRUFBUTtjQUFBLHlCQUFBLEVBQTJCLFVBQTNCO2FBQVI7WUFDQSxZQUFBLEVBQWMsQ0FBQyxzQkFBRCxDQURkO1lBRUEsUUFBQSxFQUFVLElBRlY7WUFHQSxXQUFBLEVBQWEsSUFIYjtZQUlBLFNBQUEsRUFBVyxDQUFDLDJCQUFELENBSlg7WUFLQSxXQUFBLEVBQWEsRUFMYjtXQURGO2lCQVFBLE1BQUEsQ0FBTyxVQUFVLENBQUMsYUFBWCxDQUFBLENBQVAsQ0FBa0MsQ0FBQyxJQUFuQyxDQUF3QyxVQUF4QztRQVQrRixDQUFqRztNQTFDNkIsQ0FBL0I7TUFxREEsUUFBQSxDQUFTLHNCQUFULEVBQWlDLFNBQUE7ZUFDL0IsRUFBQSxDQUFHLDRIQUFILEVBQWlJLFNBQUE7VUFDL0gsU0FBQSxDQUNFO1lBQUEsWUFBQSxFQUFjLENBQUMsc0JBQUQsQ0FBZDtZQUNBLFFBQUEsRUFBVSxzQ0FEVjtZQUVBLFdBQUEsRUFBYSxDQUZiO1lBR0EsV0FBQSxFQUNFLHFGQUpGO1dBREY7aUJBWUEsTUFBQSxDQUFPLFVBQVUsQ0FBQyxhQUFYLENBQUEsQ0FBUCxDQUFrQyxDQUFDLElBQW5DLENBQXdDLE1BQXhDO1FBYitILENBQWpJO01BRCtCLENBQWpDO2FBZ0JBLFFBQUEsQ0FBUyxvQkFBVCxFQUErQixTQUFBO2VBQzdCLEVBQUEsQ0FBRyxpQ0FBSCxFQUFzQyxTQUFBO1VBQ3BDLFNBQUEsQ0FDRTtZQUFBLFlBQUEsRUFBYyxDQUFDLHNCQUFELENBQWQ7WUFDQSxRQUFBLEVBQVUsc0NBRFY7WUFFQSxXQUFBLEVBQWEsQ0FGYjtZQUdBLFNBQUEsRUFBVyxDQUNULDJCQURTLEVBRVQsNkJBRlMsQ0FIWDtZQU9BLFdBQUEsRUFDRSxjQVJGO1dBREY7aUJBV0EsTUFBQSxDQUFPLFVBQVUsQ0FBQyxhQUFYLENBQUEsQ0FBUCxDQUFrQyxDQUFDLElBQW5DLENBQXdDLFVBQXhDO1FBWm9DLENBQXRDO01BRDZCLENBQS9CO0lBaEkwQixDQUE1QjtJQWlKQSxRQUFBLENBQVMsZUFBVCxFQUEwQixTQUFBO01BQ3hCLEVBQUEsQ0FBRyxvQ0FBSCxFQUF5QyxTQUFBO1FBQ3ZDLFNBQUEsQ0FDRTtVQUFBLFlBQUEsRUFBYyxDQUFDLHNCQUFELENBQWQ7VUFDQSxRQUFBLEVBQVUsSUFEVjtVQUVBLFNBQUEsRUFBVyxDQUFDLDJCQUFELENBRlg7U0FERjtlQUtBLE1BQUEsQ0FBTyxVQUFVLENBQUMsV0FBWCxDQUFBLENBQVAsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxNQUF0QztNQU51QyxDQUF6QztNQVFBLEVBQUEsQ0FBRyxtQ0FBSCxFQUF3QyxTQUFBO1FBQ3RDLFNBQUEsQ0FDRTtVQUFBLFlBQUEsRUFBYyxDQUFDLHNCQUFELENBQWQ7VUFDQSxRQUFBLEVBQVUsSUFEVjtVQUVBLFNBQUEsRUFBVyxDQUFDLDJCQUFELENBRlg7U0FERjtlQUtBLE1BQUEsQ0FBTyxVQUFVLENBQUMsV0FBWCxDQUFBLENBQVAsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxPQUF0QztNQU5zQyxDQUF4QzthQVFBLEVBQUEsQ0FBRyx3Q0FBSCxFQUE2QyxTQUFBO1FBQzNDLFNBQUEsQ0FDRTtVQUFBLFlBQUEsRUFBYyxDQUFDLHNCQUFELENBQWQ7VUFDQSxRQUFBLEVBQVUsSUFEVjtVQUVBLFNBQUEsRUFBVyxDQUFDLCtCQUFELENBRlg7U0FERjtlQUtBLE1BQUEsQ0FBTyxVQUFVLENBQUMsV0FBWCxDQUFBLENBQVAsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxVQUF0QztNQU4yQyxDQUE3QztJQWpCd0IsQ0FBMUI7SUF5QkEsUUFBQSxDQUFTLGNBQVQsRUFBeUIsU0FBQTthQUN2QixFQUFBLENBQUcsd0RBQUgsRUFBNkQsU0FBQTtRQUMzRCxTQUFBLENBQ0U7VUFBQSxZQUFBLEVBQWMsQ0FBQyxxQkFBRCxFQUF3QixxQkFBeEIsQ0FBZDtVQUNBLFFBQUEsRUFBVSxxQ0FEVjtTQURGO2VBR0EsTUFBQSxDQUFPLFVBQVUsQ0FBQyxVQUFYLENBQUEsQ0FBUCxDQUErQixDQUFDLElBQWhDLENBQXFDLGlCQUFyQztNQUoyRCxDQUE3RDtJQUR1QixDQUF6QjtJQU9BLFFBQUEsQ0FBUyxlQUFULEVBQTBCLFNBQUE7YUFDeEIsRUFBQSxDQUFHLHFDQUFILEVBQTBDLFNBQUE7UUFDeEMsU0FBQSxDQUNFO1VBQUEsV0FBQSxFQUFhLEdBQWI7U0FERjtlQUVBLE1BQUEsQ0FBTyxVQUFVLENBQUMsV0FBWCxDQUFBLENBQVAsQ0FBZ0MsQ0FBQyxJQUFqQyxDQUFzQyxHQUF0QztNQUh3QyxDQUExQztJQUR3QixDQUExQjtJQU1BLFFBQUEsQ0FBUyxrQkFBVCxFQUE2QixTQUFBO2FBQzNCLEVBQUEsQ0FBRywrQ0FBSCxFQUFvRCxTQUFBO1FBQ2xELFNBQUEsQ0FDRTtVQUFBLFlBQUEsRUFBYyxDQUFDLHFCQUFELENBQWQ7VUFDQSxRQUFBLEVBQVUscUNBRFY7VUFFQSxXQUFBLEVBQWEsQ0FGYjtVQUdBLFdBQUEsRUFDRSx5SUFKRjtTQURGO2VBZUEsTUFBQSxDQUFPLFVBQVUsQ0FBQyxjQUFYLENBQUEsQ0FBUCxDQUFtQyxDQUFDLElBQXBDLENBQXlDLE1BQXpDO01BaEJrRCxDQUFwRDtJQUQyQixDQUE3QjtXQW1CQSxRQUFBLENBQVMsa0JBQVQsRUFBNkIsU0FBQTtNQUMzQixFQUFBLENBQUcsK0NBQUgsRUFBb0QsU0FBQTtRQUNsRCxVQUFBLEdBQWlCLElBQUEsVUFBQSxDQUFBO2VBQ2pCLE1BQUEsQ0FBTyxVQUFVLENBQUMscUJBQVgsQ0FBaUMsMkJBQWpDLEVBQThELE1BQTlELENBQVAsQ0FBNkUsQ0FBQyxJQUE5RSxDQUFtRixnQkFBbkY7TUFGa0QsQ0FBcEQ7TUFJQSxFQUFBLENBQUcsd0RBQUgsRUFBNkQsU0FBQTtRQUMzRCxVQUFBLEdBQWlCLElBQUEsVUFBQSxDQUFBO2VBQ2pCLE1BQUEsQ0FBTyxVQUFVLENBQUMscUJBQVgsQ0FBaUMscUJBQWpDLEVBQXdELE1BQXhELENBQVAsQ0FBdUUsQ0FBQyxJQUF4RSxDQUE2RSxnQkFBN0U7TUFGMkQsQ0FBN0Q7YUFJQSxFQUFBLENBQUcsd0NBQUgsRUFBNkMsU0FBQTtRQUMzQyxVQUFBLEdBQWlCLElBQUEsVUFBQSxDQUFBO2VBQ2pCLE1BQUEsQ0FBTyxVQUFVLENBQUMscUJBQVgsQ0FBaUMsZ0JBQWpDLEVBQW1ELE1BQW5ELENBQVAsQ0FBa0UsQ0FBQyxJQUFuRSxDQUF3RSxFQUF4RTtNQUYyQyxDQUE3QztJQVQyQixDQUE3QjtFQTFRcUIsQ0FBdkI7QUFIQSIsInNvdXJjZXNDb250ZW50IjpbIlNvdXJjZUluZm8gPSByZXF1aXJlICcuLi9saWIvc291cmNlLWluZm8nXG5mcyA9IHJlcXVpcmUoJ2ZzJylcblxuZGVzY3JpYmUgXCJTb3VyY2VJbmZvXCIsIC0+XG4gIGVkaXRvciA9IG51bGxcbiAgc291cmNlSW5mbyA9IG51bGxcblxuICB3aXRoU2V0dXAgPSAob3B0cykgLT5cbiAgICBhdG9tLnByb2plY3QuZ2V0UGF0aHMgPSAtPlxuICAgICAgW1wiL3Byb2plY3RzL3Byb2plY3RfMVwiLCBcIi9wcm9qZWN0cy9wcm9qZWN0XzJcIl1cbiAgICBhdG9tLnByb2plY3QucmVsYXRpdml6ZSA9IChmaWxlUGF0aCkgLT5cbiAgICAgIGZvciBmb2xkZXJQYXRoIGluIEBnZXRQYXRocygpXG4gICAgICAgIGluZGV4ID0gZmlsZVBhdGguaW5kZXhPZihmb2xkZXJQYXRoKVxuICAgICAgICBpZiBpbmRleCA+PSAwXG4gICAgICAgICAgbmV3UGF0aCA9IGZpbGVQYXRoLnNsaWNlIGluZGV4ICsgZm9sZGVyUGF0aC5sZW5ndGgsIGZpbGVQYXRoLmxlbmd0aFxuICAgICAgICAgIG5ld1BhdGggPSBuZXdQYXRoLnNsaWNlKDEsIG5ld1BhdGgubGVuZ3RoKSBpZiBuZXdQYXRoWzBdID09ICcvJ1xuICAgICAgICAgIHJldHVybiBuZXdQYXRoXG5cbiAgICBlZGl0b3IgPSB7YnVmZmVyOiB7ZmlsZToge3BhdGg6IFwiL3Byb2plY3RzL3Byb2plY3RfMi90ZXN0L2Zvb190ZXN0LnJiXCJ9fX1cbiAgICBjdXJzb3IgPSBnZXRCdWZmZXJSb3c6IC0+IDk5XG4gICAgZWRpdG9yLmdldExhc3RDdXJzb3IgPSAtPiBjdXJzb3JcbiAgICBlZGl0b3IubGluZVRleHRGb3JCdWZmZXJSb3cgPSAobGluZSkgLT4gXCJcIlxuICAgIHNweU9uKGF0b20ud29ya3NwYWNlLCAnZ2V0QWN0aXZlVGV4dEVkaXRvcicpLmFuZFJldHVybihlZGl0b3IpXG4gICAgc291cmNlSW5mbyA9IG5ldyBTb3VyY2VJbmZvKClcblxuICAgIGlmICd0ZXN0RmlsZScgb2Ygb3B0c1xuICAgICAgZWRpdG9yLmJ1ZmZlci5maWxlLnBhdGggPSBvcHRzLnRlc3RGaWxlXG5cbiAgICBpZiAncHJvamVjdFBhdGhzJyBvZiBvcHRzXG4gICAgICBhdG9tLnByb2plY3QuZ2V0UGF0aHMgPSAtPiBvcHRzLnByb2plY3RQYXRoc1xuXG4gICAgaWYgJ2N1cnJlbnRMaW5lJyBvZiBvcHRzXG4gICAgICBjdXJzb3IuZ2V0QnVmZmVyUm93ID0gLT4gb3B0cy5jdXJyZW50TGluZSAtIDFcblxuICAgIGlmICdmaWxlQ29udGVudCcgb2Ygb3B0c1xuICAgICAgbGluZXMgPSBvcHRzLmZpbGVDb250ZW50LnNwbGl0KFwiXFxuXCIpXG4gICAgICBlZGl0b3IubGluZVRleHRGb3JCdWZmZXJSb3cgPSAocm93KSAtPlxuICAgICAgICBsaW5lc1tyb3ddXG5cbiAgICBpZiAnY29uZmlnJyBvZiBvcHRzXG4gICAgICBmb3Iga2V5LCB2YWx1ZSBvZiBvcHRzLmNvbmZpZ1xuICAgICAgICBhdG9tLmNvbmZpZy5zZXQoa2V5LCB2YWx1ZSlcblxuICAgIGlmICdtb2NrUGF0aHMnIG9mIG9wdHNcbiAgICAgIHNweU9uKGZzLCAnZXhpc3RzU3luYycpLmFuZENhbGxGYWtlIChwYXRoKSAtPlxuICAgICAgICBwYXRoIGluIG9wdHMubW9ja1BhdGhzXG5cbiAgYmVmb3JlRWFjaCAtPlxuICAgIGVkaXRvciA9IG51bGxcbiAgICBzb3VyY2VJbmZvID0gbnVsbFxuXG4gIGRlc2NyaWJlIFwiOjpwcm9qZWN0UGF0aFwiLCAtPlxuICAgIGRlc2NyaWJlIFwid2l0aCBubyB0ZXN0RmlsZVwiLCAtPlxuICAgICAgaXQgXCJpcyBhdG9tLnByb2plY3QuZ2V0UGF0aHMoKVswXVwiLCAtPlxuICAgICAgICB3aXRoU2V0dXBcbiAgICAgICAgICBwcm9qZWN0UGF0aHM6IFsnL3Byb2plY3RzL3Byb2plY3RfMScsICcvcHJvamVjdHMvcHJvamVjdF8yJ11cbiAgICAgICAgICB0ZXN0RmlsZTogbnVsbFxuICAgICAgICBleHBlY3Qoc291cmNlSW5mby5wcm9qZWN0UGF0aCgpKS50b0JlKFwiL3Byb2plY3RzL3Byb2plY3RfMVwiKVxuICAgIGRlc2NyaWJlIFwid2l0aCBhIHRlc3RGaWxlXCIsIC0+XG4gICAgICBpdCBcImlzIHRoZSBwYXRoIHdpdGhpbiBhdG9tLnByb2plY3QuZ2V0UGF0aHMoKSB0aGF0IGlzIGFuIGFuY2VzdG9yIG9mIHRoZSB0ZXN0RmlsZSBwYXRoXCIsIC0+XG4gICAgICAgIHdpdGhTZXR1cFxuICAgICAgICAgIHByb2plY3RQYXRoczogWycvcHJvamVjdHMvcHJvamVjdF8xJywgJy9wcm9qZWN0cy9wcm9qZWN0XzInXVxuICAgICAgICAgIHRlc3RGaWxlOiAnL3Byb2plY3RzL3Byb2plY3RfMi9mb28vYmFyX3Rlc3QucmInXG4gICAgICAgIGV4cGVjdChzb3VyY2VJbmZvLnByb2plY3RQYXRoKCkpLnRvQmUoXCIvcHJvamVjdHMvcHJvamVjdF8yXCIpXG5cbiAgIyBEZXRlY3QgZnJhbWV3b3JrLCBieSBpbnNwZWN0aW5nIGEgY29tYmluYXRpb24gb2YgY3VycmVudCBmaWxlIG5hbWUsXG4gICMgcHJvamVjdCBzdWJkaXJlY3RvcnkgbmFtZXMsIGN1cnJlbnQgZmlsZSBjb250ZW50LCBhbmQgY29uZmlndXJhdGlvbiB2YWx1ZVxuICBkZXNjcmliZSBcIjo6dGVzdEZyYW1ld29ya1wiLCAtPlxuICAgIGRlc2NyaWJlIFwiUlNwZWMgZGV0ZWN0aW9uXCIsIC0+XG4gICAgICBpdCBcImRldGVjdHMgUlNwZWMgYmFzZWQgb24gY29uZmlndXJhdGlvbiB2YWx1ZSBzZXQgdG8gJ3JzcGVjJ1wiLCAtPlxuICAgICAgICB3aXRoU2V0dXBcbiAgICAgICAgICBjb25maWc6IFwicnVieS10ZXN0LnNwZWNGcmFtZXdvcmtcIjogXCJyc3BlY1wiXG4gICAgICAgICAgcHJvamVjdFBhdGhzOiBbJy9ob21lL3VzZXIvcHJvamVjdF8xJ11cbiAgICAgICAgICB0ZXN0RmlsZTogJy9ob21lL3VzZXIvcHJvamVjdF8xL2Jhci9mb29fc3BlYy5yYidcbiAgICAgICAgICBjdXJyZW50TGluZTogMVxuICAgICAgICAgIGZpbGVDb250ZW50OiAnJ1xuXG4gICAgICAgIGV4cGVjdChzb3VyY2VJbmZvLnRlc3RGcmFtZXdvcmsoKSkudG9CZShcInJzcGVjXCIpXG5cbiAgICAgIGl0IFwic2VsZWN0cyBSU3BlYyBmb3Igc3BlYyBmaWxlIGlmIHNwZWNfaGVscGVyIGlzIHJlcXVpcmVkXCIsIC0+XG4gICAgICAgIHdpdGhTZXR1cFxuICAgICAgICAgIGNvbmZpZzogXCJydWJ5LXRlc3Quc3BlY0ZyYW1ld29ya1wiOiBcIlwiXG4gICAgICAgICAgcHJvamVjdFBhdGhzOiBbJy9ob21lL3VzZXIvcHJvamVjdF8xJ11cbiAgICAgICAgICB0ZXN0RmlsZTogJy9ob21lL3VzZXIvcHJvamVjdF8xL2Jhci9mb29fc3BlYy5yYidcbiAgICAgICAgICBjdXJyZW50TGluZTogNVxuICAgICAgICAgIGZpbGVDb250ZW50OlxuICAgICAgICAgICAgXCJcIlwiXG4gICAgICAgICAgICByZXF1aXJlICdzcGVjX2hlbHBlcidcblxuICAgICAgICAgICAgZGVzY3JpYmUgXCJzb21ldGhpbmdcIiBkb1xuICAgICAgICAgICAgICBpdCBcInRlc3Qgc29tZXRoaW5nXCIgZG9cbiAgICAgICAgICAgICAgICBleHBlY3QoJ2ZvbycpLnRvIGVxICdmb28nXG4gICAgICAgICAgICAgIGVuZFxuICAgICAgICAgICAgZW5kXG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgZXhwZWN0KHNvdXJjZUluZm8udGVzdEZyYW1ld29yaygpKS50b0JlKFwicnNwZWNcIilcblxuICAgICAgaXQgXCJzZWxlY3RzIFJTcGVjIGZvciBzcGVjIGZpbGUgaWYgc3BlY19oZWxwZXIgaXMgcmVxdWlyZWQgd2l0aCByZXF1aXJlX3JlbGF0aXZlXCIsIC0+XG4gICAgICAgIHdpdGhTZXR1cFxuICAgICAgICAgIGNvbmZpZzogXCJydWJ5LXRlc3Quc3BlY0ZyYW1ld29ya1wiOiBcIlwiXG4gICAgICAgICAgcHJvamVjdFBhdGhzOiBbJy9ob21lL3VzZXIvcHJvamVjdF8xJ11cbiAgICAgICAgICB0ZXN0RmlsZTogJy9ob21lL3VzZXIvcHJvamVjdF8xL2Jhci9mb29fc3BlYy5yYidcbiAgICAgICAgICBjdXJyZW50TGluZTogMlxuICAgICAgICAgIGZpbGVDb250ZW50OlxuICAgICAgICAgICAgXCJcIlwiXG4gICAgICAgICAgICByZXF1aXJlX3JlbGF0aXZlICcuLi9zcGVjX2hlbHBlcidcblxuICAgICAgICAgICAgXCJcIlwiXG4gICAgICAgIGV4cGVjdChzb3VyY2VJbmZvLnRlc3RGcmFtZXdvcmsoKSkudG9CZShcInJzcGVjXCIpXG5cbiAgICAgIGl0IFwic2VsZWN0cyBSU3BlYyBmb3Igc3BlYyBmaWxlIGlmIGV4cGVjdCgpIGlzIGNhbGxlZFwiLCAtPlxuICAgICAgICB3aXRoU2V0dXBcbiAgICAgICAgICBjb25maWc6IFwicnVieS10ZXN0LnNwZWNGcmFtZXdvcmtcIjogXCJcIlxuICAgICAgICAgIHByb2plY3RQYXRoczogWycvaG9tZS91c2VyL3Byb2plY3RfMSddXG4gICAgICAgICAgdGVzdEZpbGU6ICcvaG9tZS91c2VyL3Byb2plY3RfMS9iYXIvZm9vX3NwZWMucmInXG4gICAgICAgICAgY3VycmVudExpbmU6IDVcbiAgICAgICAgICBmaWxlQ29udGVudDpcbiAgICAgICAgICAgIFwiXCJcIlxuICAgICAgICAgICAgZGVzY3JpYmUgXCJzb21ldGhpbmdcIiBkb1xuICAgICAgICAgICAgICBpdCBcInRlc3Qgc29tZXRoaW5nXCIgZG9cbiAgICAgICAgICAgICAgICBleHBlY3QoJ2ZvbycpLnRvIGVxICdmb28nXG4gICAgICAgICAgICAgIGVuZFxuICAgICAgICAgICAgZW5kXG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgZXhwZWN0KHNvdXJjZUluZm8udGVzdEZyYW1ld29yaygpKS50b0JlKFwicnNwZWNcIilcblxuICAgIGRlc2NyaWJlIFwiTWluaXRlc3QgZGV0ZWN0aW9uXCIsIC0+XG4gICAgICBpdCBcImlzIE1pbml0ZXN0IGlmIGZpbGVuYW1lIG1hdGNoZXMgX3Rlc3QucmIsIGFuZCBmaWxlIGNvbnRhaW5zIHNwZWNzXCIsIC0+XG4gICAgICAgIHdpdGhTZXR1cFxuICAgICAgICAgIGNvbmZpZzogXCJydWJ5LXRlc3Quc3BlY0ZyYW1ld29ya1wiOiBcIlwiXG4gICAgICAgICAgcHJvamVjdFBhdGhzOiBbJy9ob21lL3VzZXIvcHJvamVjdF8xJ11cbiAgICAgICAgICB0ZXN0RmlsZTogJy9ob21lL3VzZXIvcHJvamVjdF8xL2Jhci9mb29fdGVzdC5yYidcbiAgICAgICAgICBjdXJyZW50TGluZTogM1xuICAgICAgICAgIGZpbGVDb250ZW50OlxuICAgICAgICAgICAgXCJcIlwiXG4gICAgICAgICAgICBkZXNjcmliZSBcInNvbWV0aGluZ1wiIGRvXG4gICAgICAgICAgICAgIGl0IFwidGVzdCBzb21ldGhpbmdcIiBkb1xuICAgICAgICAgICAgICAgIDEubXVzdF9lcXVhbCAxXG4gICAgICAgICAgICAgIGVuZFxuICAgICAgICAgICAgZW5kXG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgZXhwZWN0KHNvdXJjZUluZm8udGVzdEZyYW1ld29yaygpKS50b0JlKFwibWluaXRlc3RcIilcblxuICAgICAgaXQgXCJkZXRlY3RzIE1pbml0ZXN0IGJhc2VkIG9uIGNvbmZpZ3VyYXRpb24gdmFsdWUgc2V0IHRvICdtaW5pdGVzdCdcIiwgLT5cbiAgICAgICAgd2l0aFNldHVwXG4gICAgICAgICAgY29uZmlnOiBcInJ1YnktdGVzdC5zcGVjRnJhbWV3b3JrXCI6IFwibWluaXRlc3RcIlxuICAgICAgICAgIHByb2plY3RQYXRoczogWycvaG9tZS91c2VyL3Byb2plY3RfMSddXG4gICAgICAgICAgdGVzdEZpbGU6ICcvaG9tZS91c2VyL3Byb2plY3RfMS9iYXIvZm9vX3NwZWMucmInXG4gICAgICAgICAgY3VycmVudExpbmU6IDFcbiAgICAgICAgICBmaWxlQ29udGVudDogJydcblxuICAgICAgICBleHBlY3Qoc291cmNlSW5mby50ZXN0RnJhbWV3b3JrKCkpLnRvQmUoXCJtaW5pdGVzdFwiKVxuXG4gICAgICBpdCBcImlzIE1pbml0ZXN0IGZvciBhIF90ZXN0LnJiIGZpbGUgdGhhdCBjb250YWlucyBNaW5pdGVzdDo6VGVzdFwiLCAtPlxuICAgICAgICB3aXRoU2V0dXBcbiAgICAgICAgICBwcm9qZWN0UGF0aHM6IFsnL2hvbWUvdXNlci9wcm9qZWN0XzEnXVxuICAgICAgICAgIHRlc3RGaWxlOiAnL2hvbWUvdXNlci9wcm9qZWN0XzEvYmFyL2Zvb190ZXN0LnJiJ1xuICAgICAgICAgIGN1cnJlbnRMaW5lOiAzXG4gICAgICAgICAgZmlsZUNvbnRlbnQ6XG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgICAgIGNsYXNzIHNvbWV0ZXN0IDwgTWluaXRlc3Q6OlRlc3RcbiAgICAgICAgICAgICAgZGVmIHNvbWV0aGluZ1xuICAgICAgICAgICAgICAgIGFzc2VydF9lcXVhbCAxLCAxXG4gICAgICAgICAgICAgIGVuZFxuICAgICAgICAgICAgZW5kXG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgZXhwZWN0KHNvdXJjZUluZm8udGVzdEZyYW1ld29yaygpKS50b0JlKFwibWluaXRlc3RcIilcblxuICAgICAgaXQgXCJ3aGVuIG5vIHRlc3QgZmlsZSBpcyBvcGVuLCBkZXRlY3RzIE1pbml0ZXN0IGJhc2VkIG9uIGNvbmZpZ3VyYXRpb24gdmFsdWUgc2V0IHRvICdtaW5pdGVzdCdcIiwgLT5cbiAgICAgICAgd2l0aFNldHVwXG4gICAgICAgICAgY29uZmlnOiBcInJ1YnktdGVzdC5zcGVjRnJhbWV3b3JrXCI6IFwibWluaXRlc3RcIlxuICAgICAgICAgIHByb2plY3RQYXRoczogWycvaG9tZS91c2VyL3Byb2plY3RfMSddXG4gICAgICAgICAgdGVzdEZpbGU6IG51bGxcbiAgICAgICAgICBjdXJyZW50TGluZTogbnVsbFxuICAgICAgICAgIG1vY2tQYXRoczogWycvaG9tZS91c2VyL3Byb2plY3RfMS9zcGVjJ11cbiAgICAgICAgICBmaWxlQ29udGVudDogJydcblxuICAgICAgICBleHBlY3Qoc291cmNlSW5mby50ZXN0RnJhbWV3b3JrKCkpLnRvQmUoXCJtaW5pdGVzdFwiKVxuXG4gICAgZGVzY3JpYmUgXCJUZXN0OjpVbml0IGRldGVjdGlvblwiLCAtPlxuICAgICAgaXQgXCJhc3N1bWVzIFRlc3Q6OlVuaXQgd2hlbiB0aGUgZmlsZW5hbWUgZW5kcyB3aXRoIF90ZXN0LnJiLCBoYXMgYSBtZXRob2QgZGVmaW5pdGlvbiwgYW5kIGRvZXNuJ3QgaGF2ZSBhIHJlZmVyZW5jZSB0byBNaW5pdGVzdFwiLCAtPlxuICAgICAgICB3aXRoU2V0dXBcbiAgICAgICAgICBwcm9qZWN0UGF0aHM6IFsnL2hvbWUvdXNlci9wcm9qZWN0XzEnXVxuICAgICAgICAgIHRlc3RGaWxlOiAnL2hvbWUvdXNlci9wcm9qZWN0XzEvYmFyL2Zvb190ZXN0LnJiJ1xuICAgICAgICAgIGN1cnJlbnRMaW5lOiAzXG4gICAgICAgICAgZmlsZUNvbnRlbnQ6XG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgICAgIGNsYXNzIHNvbWV0ZXN0IDwgV2hhdGV2ZXI6OlVuaXRcbiAgICAgICAgICAgICAgZGVmIHNvbWV0aGluZ1xuICAgICAgICAgICAgICAgIGFzc2VydF9lcXVhbCAxLCAxXG4gICAgICAgICAgICAgIGVuZFxuICAgICAgICAgICAgZW5kXG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgZXhwZWN0KHNvdXJjZUluZm8udGVzdEZyYW1ld29yaygpKS50b0JlKFwidGVzdFwiKVxuXG4gICAgZGVzY3JpYmUgXCJDdWN1bWJlciBkZXRlY3Rpb25cIiwgLT5cbiAgICAgIGl0IFwiY29ycmVjdGx5IGRldGVjdHMgQ3VjdW1iZXIgZmlsZVwiLCAtPlxuICAgICAgICB3aXRoU2V0dXBcbiAgICAgICAgICBwcm9qZWN0UGF0aHM6IFsnL2hvbWUvdXNlci9wcm9qZWN0XzEnXVxuICAgICAgICAgIHRlc3RGaWxlOiAnL2hvbWUvdXNlci9wcm9qZWN0XzEvZm9vL2Zvby5mZWF0dXJlJ1xuICAgICAgICAgIGN1cnJlbnRMaW5lOiAxXG4gICAgICAgICAgbW9ja1BhdGhzOiBbXG4gICAgICAgICAgICAnL2hvbWUvdXNlci9wcm9qZWN0XzEvc3BlYycsXG4gICAgICAgICAgICAnL2hvbWUvdXNlci9wcm9qZWN0XzEvLnJzcGVjJ1xuICAgICAgICAgIF0sXG4gICAgICAgICAgZmlsZUNvbnRlbnQ6XG4gICAgICAgICAgICBcIlwiXCJcbiAgICAgICAgICAgIFwiXCJcIlxuICAgICAgICBleHBlY3Qoc291cmNlSW5mby50ZXN0RnJhbWV3b3JrKCkpLnRvQmUoXCJjdWN1bWJlclwiKVxuXG4gICMgRm9yIHdoZW4gbm8gdGVzdCBmaWxlIGlzIGFjdGl2ZVxuICAjIERldGVjdCBwcm9qZWN0IHR5cGUsIGJhc2VkIG9uIHByZXNlbmNlIG9mIGEgZGlyZWN0b3J5IG5hbWUgbWF0Y2hpbmcgYSB0ZXN0IGZyYW1ld29ya1xuICBkZXNjcmliZSBcIjo6cHJvamVjdFR5cGVcIiwgLT5cbiAgICBpdCBcImNvcnJlY3RseSBkZXRlY3RzIGEgdGVzdCBkaXJlY3RvcnlcIiwgLT5cbiAgICAgIHdpdGhTZXR1cFxuICAgICAgICBwcm9qZWN0UGF0aHM6IFsnL2hvbWUvdXNlci9wcm9qZWN0XzEnXVxuICAgICAgICB0ZXN0RmlsZTogbnVsbFxuICAgICAgICBtb2NrUGF0aHM6IFsnL2hvbWUvdXNlci9wcm9qZWN0XzEvdGVzdCddXG5cbiAgICAgIGV4cGVjdChzb3VyY2VJbmZvLnByb2plY3RUeXBlKCkpLnRvQmUoXCJ0ZXN0XCIpXG5cbiAgICBpdCBcImNvcnJlY3RseSBkZXRlY3MgYSBzcGVjIGRpcmVjdG9yeVwiLCAtPlxuICAgICAgd2l0aFNldHVwXG4gICAgICAgIHByb2plY3RQYXRoczogWycvaG9tZS91c2VyL3Byb2plY3RfMSddXG4gICAgICAgIHRlc3RGaWxlOiBudWxsXG4gICAgICAgIG1vY2tQYXRoczogWycvaG9tZS91c2VyL3Byb2plY3RfMS9zcGVjJ11cblxuICAgICAgZXhwZWN0KHNvdXJjZUluZm8ucHJvamVjdFR5cGUoKSkudG9CZShcInJzcGVjXCIpXG5cbiAgICBpdCBcImNvcnJlY3RseSBkZXRlY3RzIGEgY3VjdW1iZXIgZGlyZWN0b3J5XCIsIC0+XG4gICAgICB3aXRoU2V0dXBcbiAgICAgICAgcHJvamVjdFBhdGhzOiBbJy9ob21lL3VzZXIvcHJvamVjdF8xJ11cbiAgICAgICAgdGVzdEZpbGU6IG51bGxcbiAgICAgICAgbW9ja1BhdGhzOiBbJy9ob21lL3VzZXIvcHJvamVjdF8xL2ZlYXR1cmVzJ11cblxuICAgICAgZXhwZWN0KHNvdXJjZUluZm8ucHJvamVjdFR5cGUoKSkudG9CZShcImN1Y3VtYmVyXCIpXG5cbiAgZGVzY3JpYmUgXCI6OmFjdGl2ZUZpbGVcIiwgLT5cbiAgICBpdCBcImlzIHRoZSBwcm9qZWN0LXJlbGF0aXZlIHBhdGggZm9yIHRoZSBjdXJyZW50IGZpbGUgcGF0aFwiLCAtPlxuICAgICAgd2l0aFNldHVwXG4gICAgICAgIHByb2plY3RQYXRoczogWycvcHJvamVjdHMvcHJvamVjdF8xJywgJy9wcm9qZWN0cy9wcm9qZWN0XzInXVxuICAgICAgICB0ZXN0RmlsZTogJy9wcm9qZWN0cy9wcm9qZWN0XzIvYmFyL2Zvb190ZXN0LnJiJ1xuICAgICAgZXhwZWN0KHNvdXJjZUluZm8uYWN0aXZlRmlsZSgpKS50b0JlKFwiYmFyL2Zvb190ZXN0LnJiXCIpXG5cbiAgZGVzY3JpYmUgXCI6OmN1cnJlbnRMaW5lXCIsIC0+XG4gICAgaXQgXCJpcyB0aGUgY3Vyc29yIGdldEJ1ZmZlclJvdygpIHBsdXMgMVwiLCAtPlxuICAgICAgd2l0aFNldHVwXG4gICAgICAgIGN1cnJlbnRMaW5lOiAxMDBcbiAgICAgIGV4cGVjdChzb3VyY2VJbmZvLmN1cnJlbnRMaW5lKCkpLnRvQmUoMTAwKVxuXG4gIGRlc2NyaWJlIFwiOjptaW5pdGVzdFJlZ0V4cFwiLCAtPlxuICAgIGl0IFwiY29ycmVjdGx5IHJldHVybnMgdGhlIG1hdGNoaW5nIHJlZ2V4IGZvciBzcGVjXCIsIC0+XG4gICAgICB3aXRoU2V0dXBcbiAgICAgICAgcHJvamVjdFBhdGhzOiBbJy9wcm9qZWN0cy9wcm9qZWN0XzEnXVxuICAgICAgICB0ZXN0RmlsZTogJy9wcm9qZWN0cy9wcm9qZWN0XzEvYmFyL2Zvb190ZXN0LnJiJ1xuICAgICAgICBjdXJyZW50TGluZTogNlxuICAgICAgICBmaWxlQ29udGVudDpcbiAgICAgICAgICBcIlwiXCJcbiAgICAgICAgICByZXF1aXJlICdtaW5pdGVzdC9zcGVjJ1xuICAgICAgICAgIHJlcXVpcmUgJ21pbml0ZXN0L2F1dG9ydW4nXG5cbiAgICAgICAgICBkZXNjcmliZSBcIkFkZGl0aW9uXCIgZG9cbiAgICAgICAgICAgIGl0IFwiYWRkc1wiIGRvXG4gICAgICAgICAgICAgICgxICsgMSkubXVzdF9lcXVhbCAyXG4gICAgICAgICAgICBlbmRcbiAgICAgICAgICBlbmRcbiAgICAgICAgICBcIlwiXCJcbiAgICAgIGV4cGVjdChzb3VyY2VJbmZvLm1pbml0ZXN0UmVnRXhwKCkpLnRvQmUoXCJhZGRzXCIpXG5cbiAgZGVzY3JpYmUgXCI6Om1pbml0ZXN0UmVnRXhwXCIsIC0+XG4gICAgaXQgXCJjb3JyZWN0bHkgcmV0dXJucyB0aGUgbWF0Y2hpbmcgcmVnZXggZm9yIHNwZWNcIiwgLT5cbiAgICAgIHNvdXJjZUluZm8gPSBuZXcgU291cmNlSW5mbygpXG4gICAgICBleHBlY3Qoc291cmNlSW5mby5leHRyYWN0TWluaXRlc3RSZWdFeHAoXCIgaXQgXFxcInRlc3Qgc29tZXRoaW5nXFxcIiBkb1wiLCBcInNwZWNcIikpLnRvQmUoXCJ0ZXN0IHNvbWV0aGluZ1wiKVxuXG4gICAgaXQgXCJjb3JyZWN0bHkgcmV0dXJucyB0aGUgbWF0Y2hpbmcgcmVnZXggZm9yIG1pbml0ZXN0IHVuaXRcIiwgLT5cbiAgICAgIHNvdXJjZUluZm8gPSBuZXcgU291cmNlSW5mbygpXG4gICAgICBleHBlY3Qoc291cmNlSW5mby5leHRyYWN0TWluaXRlc3RSZWdFeHAoXCIgZGVmIHRlc3Rfc29tZXRoaW5nXCIsIFwidW5pdFwiKSkudG9CZShcInRlc3Rfc29tZXRoaW5nXCIpXG5cbiAgICBpdCBcInNob3VsZCByZXR1cm4gZW1wdHkgc3RyaW5nIGlmIG5vIG1hdGNoXCIsIC0+XG4gICAgICBzb3VyY2VJbmZvID0gbmV3IFNvdXJjZUluZm8oKVxuICAgICAgZXhwZWN0KHNvdXJjZUluZm8uZXh0cmFjdE1pbml0ZXN0UmVnRXhwKFwidGVzdCBzb21ldGhpbmdcIiwgXCJzcGVjXCIpKS50b0JlKFwiXCIpXG4iXX0=
