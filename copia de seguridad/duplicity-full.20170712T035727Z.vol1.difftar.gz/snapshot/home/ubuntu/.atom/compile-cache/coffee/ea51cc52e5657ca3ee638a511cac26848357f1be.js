(function() {
  var AutocompleteRuby;

  AutocompleteRuby = require('../lib/autocomplete-ruby');

  describe("AutocompleteRuby", function() {
    var activationPromise, ref, workspaceElement;
    ref = [], workspaceElement = ref[0], activationPromise = ref[1];
    beforeEach(function() {
      workspaceElement = atom.views.getView(atom.workspace);
      activationPromise = atom.packages.activatePackage('autocomplete-ruby');
      return waitsForPromise(function() {
        return activationPromise;
      });
    });
    return describe("autocomplete-ruby", function() {
      return it('Starts and stops rsense', function() {
        var rsenseClient, rsenseProvider;
        rsenseProvider = AutocompleteRuby.rsenseProvider;
        rsenseClient = rsenseProvider.rsenseClient;
        expect(rsenseClient.rsenseStarted).toBe(false);
        rsenseProvider.requestHandler();
        expect(rsenseClient.rsenseStarted).toBe(true);
        rsenseClient.stopRsense();
        return expect(rsenseClient.rsenseStarted).toBe(true);
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1ydWJ5L3NwZWMvYXV0b2NvbXBsZXRlLXJ1Ynktc3BlYy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLGdCQUFBLEdBQW1CLE9BQUEsQ0FBUSwwQkFBUjs7RUFFbkIsUUFBQSxDQUFTLGtCQUFULEVBQTZCLFNBQUE7QUFDM0IsUUFBQTtJQUFBLE1BQXdDLEVBQXhDLEVBQUMseUJBQUQsRUFBbUI7SUFFbkIsVUFBQSxDQUFXLFNBQUE7TUFDVCxnQkFBQSxHQUFtQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVgsQ0FBbUIsSUFBSSxDQUFDLFNBQXhCO01BQ25CLGlCQUFBLEdBQW9CLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZCxDQUE4QixtQkFBOUI7YUFDcEIsZUFBQSxDQUFnQixTQUFBO2VBQUc7TUFBSCxDQUFoQjtJQUhTLENBQVg7V0FLQSxRQUFBLENBQVMsbUJBQVQsRUFBOEIsU0FBQTthQUM1QixFQUFBLENBQUcseUJBQUgsRUFBOEIsU0FBQTtBQUM1QixZQUFBO1FBQUEsY0FBQSxHQUFpQixnQkFBZ0IsQ0FBQztRQUNsQyxZQUFBLEdBQWUsY0FBYyxDQUFDO1FBRTlCLE1BQUEsQ0FBTyxZQUFZLENBQUMsYUFBcEIsQ0FBa0MsQ0FBQyxJQUFuQyxDQUF3QyxLQUF4QztRQUdBLGNBQWMsQ0FBQyxjQUFmLENBQUE7UUFDQSxNQUFBLENBQU8sWUFBWSxDQUFDLGFBQXBCLENBQWtDLENBQUMsSUFBbkMsQ0FBd0MsSUFBeEM7UUFFQSxZQUFZLENBQUMsVUFBYixDQUFBO2VBQ0EsTUFBQSxDQUFPLFlBQVksQ0FBQyxhQUFwQixDQUFrQyxDQUFDLElBQW5DLENBQXdDLElBQXhDO01BWDRCLENBQTlCO0lBRDRCLENBQTlCO0VBUjJCLENBQTdCO0FBRkEiLCJzb3VyY2VzQ29udGVudCI6WyJBdXRvY29tcGxldGVSdWJ5ID0gcmVxdWlyZSAnLi4vbGliL2F1dG9jb21wbGV0ZS1ydWJ5J1xuXG5kZXNjcmliZSBcIkF1dG9jb21wbGV0ZVJ1YnlcIiwgLT5cbiAgW3dvcmtzcGFjZUVsZW1lbnQsIGFjdGl2YXRpb25Qcm9taXNlXSA9IFtdXG5cbiAgYmVmb3JlRWFjaCAtPlxuICAgIHdvcmtzcGFjZUVsZW1lbnQgPSBhdG9tLnZpZXdzLmdldFZpZXcoYXRvbS53b3Jrc3BhY2UpXG4gICAgYWN0aXZhdGlvblByb21pc2UgPSBhdG9tLnBhY2thZ2VzLmFjdGl2YXRlUGFja2FnZSgnYXV0b2NvbXBsZXRlLXJ1YnknKVxuICAgIHdhaXRzRm9yUHJvbWlzZSAtPiBhY3RpdmF0aW9uUHJvbWlzZVxuXG4gIGRlc2NyaWJlIFwiYXV0b2NvbXBsZXRlLXJ1YnlcIiwgLT5cbiAgICBpdCAnU3RhcnRzIGFuZCBzdG9wcyByc2Vuc2UnLCAtPlxuICAgICAgcnNlbnNlUHJvdmlkZXIgPSBBdXRvY29tcGxldGVSdWJ5LnJzZW5zZVByb3ZpZGVyXG4gICAgICByc2Vuc2VDbGllbnQgPSByc2Vuc2VQcm92aWRlci5yc2Vuc2VDbGllbnRcblxuICAgICAgZXhwZWN0KHJzZW5zZUNsaWVudC5yc2Vuc2VTdGFydGVkKS50b0JlKGZhbHNlKVxuXG4gICAgICAjIFRoZSBmaXJzdCByZXF1ZXN0IGZvciBhdXRvY29tcGxldGlvbiBzdGFydHMgcnNlbnNlXG4gICAgICByc2Vuc2VQcm92aWRlci5yZXF1ZXN0SGFuZGxlcigpXG4gICAgICBleHBlY3QocnNlbnNlQ2xpZW50LnJzZW5zZVN0YXJ0ZWQpLnRvQmUodHJ1ZSlcblxuICAgICAgcnNlbnNlQ2xpZW50LnN0b3BSc2Vuc2UoKVxuICAgICAgZXhwZWN0KHJzZW5zZUNsaWVudC5yc2Vuc2VTdGFydGVkKS50b0JlKHRydWUpXG4iXX0=
