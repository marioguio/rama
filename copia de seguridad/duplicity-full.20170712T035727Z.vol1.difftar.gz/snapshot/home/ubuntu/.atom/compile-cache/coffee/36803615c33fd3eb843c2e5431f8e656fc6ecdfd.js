(function() {
  var $, Convert, RubyTestView, SourceInfo, TestRunner, Utility, View, ref,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
    hasProp = {}.hasOwnProperty;

  ref = require('atom-space-pen-views'), $ = ref.$, View = ref.View;

  TestRunner = require('./test-runner');

  Utility = require('./utility');

  SourceInfo = require('./source-info');

  Convert = require('ansi-to-html');

  module.exports = RubyTestView = (function(superClass) {
    extend(RubyTestView, superClass);

    function RubyTestView() {
      this.onTestRunEnd = bind(this.onTestRunEnd, this);
      return RubyTestView.__super__.constructor.apply(this, arguments);
    }

    RubyTestView.content = function() {
      return this.div({
        "class": "ruby-test inset-panel panel-bottom native-key-bindings",
        tabindex: -1
      }, (function(_this) {
        return function() {};
      })(this));
    };

    RubyTestView.prototype.initialize = function(serializeState, terminal) {
      var sourceInfo;
      this.terminal = terminal;
      sourceInfo = new SourceInfo();
      atom.commands.add("atom-workspace", "ruby-test:toggle", (function(_this) {
        return function() {
          return _this.toggle();
        };
      })(this));
      atom.commands.add("atom-workspace", "ruby-test:test-file", (function(_this) {
        return function() {
          return _this.testFile();
        };
      })(this));
      atom.commands.add("atom-workspace", "ruby-test:test-single", (function(_this) {
        return function() {
          return _this.testSingle();
        };
      })(this));
      atom.commands.add("atom-workspace", "ruby-test:test-previous", (function(_this) {
        return function() {
          return _this.testPrevious();
        };
      })(this));
      atom.commands.add("atom-workspace", "ruby-test:test-all", (function(_this) {
        return function() {
          return _this.testAll();
        };
      })(this));
      return atom.commands.add("atom-workspace", "ruby-test:cancel", (function(_this) {
        return function() {
          return _this.cancelTest();
        };
      })(this));
    };

    RubyTestView.prototype.serialize = function() {};

    RubyTestView.prototype.destroy = function() {
      this.output = '';
      return this.detach();
    };

    RubyTestView.prototype.closePanel = function() {
      if (this.hasParent()) {
        return this.detach();
      }
    };

    RubyTestView.prototype.currentEditor = function() {
      return atom.views.getView(atom.workspace.getActiveTextEditor());
    };

    RubyTestView.prototype.toggle = function() {
      return atom.commands.dispatch(this.currentEditor(), 'platformio-ide-terminal:toggle');
    };

    RubyTestView.prototype.testFile = function() {
      return this.runTest({
        testScope: "file"
      });
    };

    RubyTestView.prototype.testSingle = function() {
      return this.runTest({
        testScope: "single"
      });
    };

    RubyTestView.prototype.testAll = function() {
      return this.runTest({
        testScope: "all"
      });
    };

    RubyTestView.prototype.testPrevious = function() {
      if (!this.runner) {
        return;
      }
      this.saveFile();
      return this.runner.run();
    };

    RubyTestView.prototype.runTest = function(params) {
      this.saveFile();
      this.runner = new TestRunner(params, this.terminal);
      return this.runner.run();
    };

    RubyTestView.prototype.onTestRunEnd = function() {
      return null;
    };

    RubyTestView.prototype.showPanel = function() {
      if (!this.hasParent()) {
        atom.workspace.addBottomPanel({
          item: this
        });
        return this.spinner = this.find('.ruby-test-spinner');
      }
    };

    RubyTestView.prototype.cancelTest = function() {
      return atom.commands.dispatch(this.currentEditor(), 'platformio-ide-terminal:close');
    };

    RubyTestView.prototype.saveFile = function() {
      var util;
      util = new Utility;
      return util.saveFile();
    };

    return RubyTestView;

  })(View);

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9saWIvcnVieS10ZXN0LXZpZXcuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQSxvRUFBQTtJQUFBOzs7O0VBQUEsTUFBVyxPQUFBLENBQVEsc0JBQVIsQ0FBWCxFQUFDLFNBQUQsRUFBRzs7RUFDSCxVQUFBLEdBQWEsT0FBQSxDQUFRLGVBQVI7O0VBQ2IsT0FBQSxHQUFVLE9BQUEsQ0FBUSxXQUFSOztFQUNWLFVBQUEsR0FBYSxPQUFBLENBQVEsZUFBUjs7RUFDYixPQUFBLEdBQVUsT0FBQSxDQUFRLGNBQVI7O0VBRVYsTUFBTSxDQUFDLE9BQVAsR0FDTTs7Ozs7Ozs7SUFDSixZQUFDLENBQUEsT0FBRCxHQUFVLFNBQUE7YUFDUixJQUFDLENBQUEsR0FBRCxDQUFLO1FBQUEsQ0FBQSxLQUFBLENBQUEsRUFBTyx3REFBUDtRQUFpRSxRQUFBLEVBQVUsQ0FBQyxDQUE1RTtPQUFMLEVBQW9GLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQSxHQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFwRjtJQURROzsyQkFHVixVQUFBLEdBQVksU0FBQyxjQUFELEVBQWlCLFFBQWpCO0FBQ1YsVUFBQTtNQUFBLElBQUMsQ0FBQSxRQUFELEdBQVk7TUFDWixVQUFBLEdBQWlCLElBQUEsVUFBQSxDQUFBO01BQ2pCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFBb0Msa0JBQXBDLEVBQXdELENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQTtpQkFBRyxLQUFDLENBQUEsTUFBRCxDQUFBO1FBQUg7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXhEO01BQ0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQyxxQkFBcEMsRUFBMkQsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFBO2lCQUFHLEtBQUMsQ0FBQSxRQUFELENBQUE7UUFBSDtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBM0Q7TUFDQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DLHVCQUFwQyxFQUE2RCxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUE7aUJBQUcsS0FBQyxDQUFBLFVBQUQsQ0FBQTtRQUFIO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE3RDtNQUNBLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFBb0MseUJBQXBDLEVBQStELENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQTtpQkFBRyxLQUFDLENBQUEsWUFBRCxDQUFBO1FBQUg7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQS9EO01BQ0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQyxvQkFBcEMsRUFBMEQsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFBO2lCQUFHLEtBQUMsQ0FBQSxPQUFELENBQUE7UUFBSDtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUQ7YUFDQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DLGtCQUFwQyxFQUF3RCxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUE7aUJBQUcsS0FBQyxDQUFBLFVBQUQsQ0FBQTtRQUFIO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF4RDtJQVJVOzsyQkFXWixTQUFBLEdBQVcsU0FBQSxHQUFBOzsyQkFHWCxPQUFBLEdBQVMsU0FBQTtNQUNQLElBQUMsQ0FBQSxNQUFELEdBQVU7YUFDVixJQUFDLENBQUEsTUFBRCxDQUFBO0lBRk87OzJCQUlULFVBQUEsR0FBWSxTQUFBO01BQ1YsSUFBRyxJQUFDLENBQUEsU0FBRCxDQUFBLENBQUg7ZUFDRSxJQUFDLENBQUEsTUFBRCxDQUFBLEVBREY7O0lBRFU7OzJCQUlaLGFBQUEsR0FBZSxTQUFBO2FBQ2IsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFYLENBQW1CLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQWYsQ0FBQSxDQUFuQjtJQURhOzsyQkFHZixNQUFBLEdBQVEsU0FBQTthQUNOLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBZCxDQUF1QixJQUFDLENBQUEsYUFBRCxDQUFBLENBQXZCLEVBQXlDLGdDQUF6QztJQURNOzsyQkFHUixRQUFBLEdBQVUsU0FBQTthQUNSLElBQUMsQ0FBQSxPQUFELENBQVM7UUFBQSxTQUFBLEVBQVcsTUFBWDtPQUFUO0lBRFE7OzJCQUdWLFVBQUEsR0FBWSxTQUFBO2FBQ1YsSUFBQyxDQUFBLE9BQUQsQ0FBUztRQUFBLFNBQUEsRUFBVyxRQUFYO09BQVQ7SUFEVTs7MkJBR1osT0FBQSxHQUFTLFNBQUE7YUFDUCxJQUFDLENBQUEsT0FBRCxDQUFTO1FBQUEsU0FBQSxFQUFXLEtBQVg7T0FBVDtJQURPOzsyQkFHVCxZQUFBLEdBQWMsU0FBQTtNQUNaLElBQUEsQ0FBYyxJQUFDLENBQUEsTUFBZjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLFFBQUQsQ0FBQTthQUNBLElBQUMsQ0FBQSxNQUFNLENBQUMsR0FBUixDQUFBO0lBSFk7OzJCQUtkLE9BQUEsR0FBUyxTQUFDLE1BQUQ7TUFDUCxJQUFDLENBQUEsUUFBRCxDQUFBO01BQ0EsSUFBQyxDQUFBLE1BQUQsR0FBYyxJQUFBLFVBQUEsQ0FBVyxNQUFYLEVBQW1CLElBQUMsQ0FBQSxRQUFwQjthQUNkLElBQUMsQ0FBQSxNQUFNLENBQUMsR0FBUixDQUFBO0lBSE87OzJCQUtULFlBQUEsR0FBYyxTQUFBO2FBQ1o7SUFEWTs7MkJBR2QsU0FBQSxHQUFXLFNBQUE7TUFDVCxJQUFBLENBQU8sSUFBQyxDQUFBLFNBQUQsQ0FBQSxDQUFQO1FBQ0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFmLENBQThCO1VBQUEsSUFBQSxFQUFNLElBQU47U0FBOUI7ZUFDQSxJQUFDLENBQUEsT0FBRCxHQUFXLElBQUMsQ0FBQSxJQUFELENBQU0sb0JBQU4sRUFGYjs7SUFEUzs7MkJBS1gsVUFBQSxHQUFZLFNBQUE7YUFDVixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQWQsQ0FBdUIsSUFBQyxDQUFBLGFBQUQsQ0FBQSxDQUF2QixFQUF5QywrQkFBekM7SUFEVTs7MkJBR1osUUFBQSxHQUFVLFNBQUE7QUFDUixVQUFBO01BQUEsSUFBQSxHQUFPLElBQUk7YUFDWCxJQUFJLENBQUMsUUFBTCxDQUFBO0lBRlE7Ozs7S0E5RGU7QUFQM0IiLCJzb3VyY2VzQ29udGVudCI6WyJ7JCxWaWV3fSA9IHJlcXVpcmUgJ2F0b20tc3BhY2UtcGVuLXZpZXdzJ1xuVGVzdFJ1bm5lciA9IHJlcXVpcmUgJy4vdGVzdC1ydW5uZXInXG5VdGlsaXR5ID0gcmVxdWlyZSAnLi91dGlsaXR5J1xuU291cmNlSW5mbyA9IHJlcXVpcmUgJy4vc291cmNlLWluZm8nXG5Db252ZXJ0ID0gcmVxdWlyZSAnYW5zaS10by1odG1sJ1xuXG5tb2R1bGUuZXhwb3J0cyA9XG5jbGFzcyBSdWJ5VGVzdFZpZXcgZXh0ZW5kcyBWaWV3XG4gIEBjb250ZW50OiAtPlxuICAgIEBkaXYgY2xhc3M6IFwicnVieS10ZXN0IGluc2V0LXBhbmVsIHBhbmVsLWJvdHRvbSBuYXRpdmUta2V5LWJpbmRpbmdzXCIsIHRhYmluZGV4OiAtMSwgPT5cblxuICBpbml0aWFsaXplOiAoc2VyaWFsaXplU3RhdGUsIHRlcm1pbmFsKSAtPlxuICAgIEB0ZXJtaW5hbCA9IHRlcm1pbmFsO1xuICAgIHNvdXJjZUluZm8gPSBuZXcgU291cmNlSW5mbygpXG4gICAgYXRvbS5jb21tYW5kcy5hZGQgXCJhdG9tLXdvcmtzcGFjZVwiLCBcInJ1YnktdGVzdDp0b2dnbGVcIiwgPT4gQHRvZ2dsZSgpXG4gICAgYXRvbS5jb21tYW5kcy5hZGQgXCJhdG9tLXdvcmtzcGFjZVwiLCBcInJ1YnktdGVzdDp0ZXN0LWZpbGVcIiwgPT4gQHRlc3RGaWxlKClcbiAgICBhdG9tLmNvbW1hbmRzLmFkZCBcImF0b20td29ya3NwYWNlXCIsIFwicnVieS10ZXN0OnRlc3Qtc2luZ2xlXCIsID0+IEB0ZXN0U2luZ2xlKClcbiAgICBhdG9tLmNvbW1hbmRzLmFkZCBcImF0b20td29ya3NwYWNlXCIsIFwicnVieS10ZXN0OnRlc3QtcHJldmlvdXNcIiwgPT4gQHRlc3RQcmV2aW91cygpXG4gICAgYXRvbS5jb21tYW5kcy5hZGQgXCJhdG9tLXdvcmtzcGFjZVwiLCBcInJ1YnktdGVzdDp0ZXN0LWFsbFwiLCA9PiBAdGVzdEFsbCgpXG4gICAgYXRvbS5jb21tYW5kcy5hZGQgXCJhdG9tLXdvcmtzcGFjZVwiLCBcInJ1YnktdGVzdDpjYW5jZWxcIiwgPT4gQGNhbmNlbFRlc3QoKVxuXG4gICMgUmV0dXJucyBhbiBvYmplY3QgdGhhdCBjYW4gYmUgcmV0cmlldmVkIHdoZW4gcGFja2FnZSBpcyBhY3RpdmF0ZWRcbiAgc2VyaWFsaXplOiAtPlxuXG4gICMgVGVhciBkb3duIGFueSBzdGF0ZSBhbmQgZGV0YWNoXG4gIGRlc3Ryb3k6IC0+XG4gICAgQG91dHB1dCA9ICcnXG4gICAgQGRldGFjaCgpXG5cbiAgY2xvc2VQYW5lbDogLT5cbiAgICBpZiBAaGFzUGFyZW50KClcbiAgICAgIEBkZXRhY2goKVxuXG4gIGN1cnJlbnRFZGl0b3I6IC0+XG4gICAgYXRvbS52aWV3cy5nZXRWaWV3KGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVRleHRFZGl0b3IoKSlcblxuICB0b2dnbGU6IC0+XG4gICAgYXRvbS5jb21tYW5kcy5kaXNwYXRjaChAY3VycmVudEVkaXRvcigpLCAncGxhdGZvcm1pby1pZGUtdGVybWluYWw6dG9nZ2xlJylcblxuICB0ZXN0RmlsZTogLT5cbiAgICBAcnVuVGVzdCh0ZXN0U2NvcGU6IFwiZmlsZVwiKVxuXG4gIHRlc3RTaW5nbGU6IC0+XG4gICAgQHJ1blRlc3QodGVzdFNjb3BlOiBcInNpbmdsZVwiKVxuXG4gIHRlc3RBbGw6IC0+XG4gICAgQHJ1blRlc3QodGVzdFNjb3BlOiBcImFsbFwiKVxuXG4gIHRlc3RQcmV2aW91czogLT5cbiAgICByZXR1cm4gdW5sZXNzIEBydW5uZXJcbiAgICBAc2F2ZUZpbGUoKVxuICAgIEBydW5uZXIucnVuKClcblxuICBydW5UZXN0OiAocGFyYW1zKSAtPlxuICAgIEBzYXZlRmlsZSgpXG4gICAgQHJ1bm5lciA9IG5ldyBUZXN0UnVubmVyKHBhcmFtcywgQHRlcm1pbmFsKVxuICAgIEBydW5uZXIucnVuKClcblxuICBvblRlc3RSdW5FbmQ6ID0+XG4gICAgbnVsbFxuXG4gIHNob3dQYW5lbDogLT5cbiAgICB1bmxlc3MgQGhhc1BhcmVudCgpXG4gICAgICBhdG9tLndvcmtzcGFjZS5hZGRCb3R0b21QYW5lbChpdGVtOiBAKVxuICAgICAgQHNwaW5uZXIgPSBAZmluZCgnLnJ1YnktdGVzdC1zcGlubmVyJylcblxuICBjYW5jZWxUZXN0OiAtPlxuICAgIGF0b20uY29tbWFuZHMuZGlzcGF0Y2goQGN1cnJlbnRFZGl0b3IoKSwgJ3BsYXRmb3JtaW8taWRlLXRlcm1pbmFsOmNsb3NlJylcblxuICBzYXZlRmlsZTogLT5cbiAgICB1dGlsID0gbmV3IFV0aWxpdHlcbiAgICB1dGlsLnNhdmVGaWxlKClcbiJdfQ==
