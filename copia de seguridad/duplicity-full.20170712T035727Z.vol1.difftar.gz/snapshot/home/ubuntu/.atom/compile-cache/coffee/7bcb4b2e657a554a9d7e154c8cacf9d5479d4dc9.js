(function() {
  var $, RsenseClient, TableParser, exec, os,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  $ = require('jquery');

  TableParser = require('table-parser');

  exec = require('child_process').exec;

  os = require('os');

  String.prototype.replaceAll = function(s, r) {
    return this.split(s).join(r);
  };

  module.exports = RsenseClient = (function() {
    function RsenseClient() {
      this.checkCompletion = bind(this.checkCompletion, this);
      this.stopRsense = bind(this.stopRsense, this);
      this.stopRsenseUnix = bind(this.stopRsenseUnix, this);
      this.startRsenseCommand = bind(this.startRsenseCommand, this);
      this.startRsenseWin32 = bind(this.startRsenseWin32, this);
      this.startRsenseUnix = bind(this.startRsenseUnix, this);
      this.projectPath = atom.project.getPaths()[0];
      if (!this.projectPath) {
        this.projectPath = '.';
      }
      this.rsensePath = atom.config.get('autocomplete-ruby.rsensePath');
      this.port = atom.config.get('autocomplete-ruby.port');
      this.serverUrl = "http://localhost:" + this.port;
      this.rsenseStarted = false;
      this.rsenseProcess = null;
    }

    RsenseClient.prototype.startRsenseUnix = function() {
      var start;
      start = this.startRsenseCommand;
      return exec("ps -ef | head -1; ps -ef | grep java", function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error looking for resense process', {
            detail: "autocomplete-ruby: exec error: " + error,
            dismissable: true
          });
        } else {
          this.rsenseProcess = $.grep(TableParser.parse(stdout), function(process) {
            return process.CMD.join(' ').match(/rsense.*--port.*--path/);
          })[0];
          if (this.rsenseProcess === void 0 || this.rsenseProcess === null) {
            return start();
          } else {
            return this.rsenseStarted = true;
          }
        }
      });
    };

    RsenseClient.prototype.startRsenseWin32 = function() {
      var start;
      if (this.rsenseStarted) {
        return;
      }
      start = this.startRsenseCommand;
      return exec(this.rsensePath + " stop", (function(_this) {
        return function(error, stdout, stderr) {
          if (error === null) {
            return start();
          } else {
            atom.notifications.addError('Error stopping rsense', {
              detail: "autocomplete-ruby: exec error: " + error,
              dismissable: true
            });
            return _this.rsenseStarted = false;
          }
        };
      })(this));
    };

    RsenseClient.prototype.startRsenseCommand = function() {
      if (this.rsenseStarted) {
        return;
      }
      return exec(this.rsensePath + " start --port " + this.port + " --path " + this.projectPath, function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error starting rsense', {
            detail: ("autocomplete-ruby: exec error: " + error + os.EOL) + "(You might need to set the rsense path, see the readme)",
            dismissable: true
          });
        } else {
          return this.rsenseStarted = true;
        }
      });
    };

    RsenseClient.prototype.stopRsenseUnix = function() {
      var stopCommand;
      stopCommand = this.stopRsense;
      return exec("ps -ef | head -1; ps -ef | grep atom", function(error, stdout, stderr) {
        var ex;
        if (error !== null) {
          return atom.notifications.addError('Error looking for atom process', {
            detail: "autocomplete-ruby: exec error: " + error,
            dismissable: true
          });
        } else {
          this.atomProcesses = $.grep(TableParser.parse(stdout), function(process) {
            return process.CMD.join(' ').match(/--type=renderer.*--node-integration=true/);
          });
          if (this.atomProcesses.length < 2) {
            try {
              if (this.rsenseProcess) {
                process.kill(this.rsenseProcess.PID[0], 'SIGKILL');
              }
            } catch (error1) {
              ex = error1;
              console.debug("exception killing process: " + ex);
            }
            return stopCommand();
          }
        }
      });
    };

    RsenseClient.prototype.stopRsense = function() {
      if (!this.rsenseStarted) {
        return;
      }
      return exec(this.rsensePath + " stop", function(error, stdout, stderr) {
        if (error !== null) {
          return atom.notifications.addError('Error stopping rsense', {
            detail: "autocomplete-ruby: exec error: " + error,
            dismissable: true
          });
        } else {
          return this.rsenseStarted = false;
        }
      });
    };

    RsenseClient.prototype.checkCompletion = function(editor, buffer, row, column, callback) {
      var code, request;
      code = buffer.getText().replaceAll('\n', '\n').replaceAll('%', '%25');
      request = {
        command: 'code_completion',
        project: this.projectPath,
        file: editor.getPath(),
        code: code,
        location: {
          row: row,
          column: column
        }
      };
      $.ajax(this.serverUrl, {
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(request),
        error: function(jqXHR, textStatus, errorThrown) {
          callback([]);
          return console.error(textStatus);
        },
        success: function(data, textStatus, jqXHR) {
          return callback(data.completions);
        }
      });
      return [];
    };

    return RsenseClient;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1ydWJ5L2xpYi9hdXRvY29tcGxldGUtcnVieS1jbGllbnQuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQSxzQ0FBQTtJQUFBOztFQUFBLENBQUEsR0FBSSxPQUFBLENBQVEsUUFBUjs7RUFDSixXQUFBLEdBQWMsT0FBQSxDQUFRLGNBQVI7O0VBQ2QsSUFBQSxHQUFPLE9BQUEsQ0FBUSxlQUFSLENBQXdCLENBQUM7O0VBQ2hDLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUjs7RUFDTCxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQWpCLEdBQThCLFNBQUMsQ0FBRCxFQUFJLENBQUo7V0FBVSxJQUFDLENBQUEsS0FBRCxDQUFPLENBQVAsQ0FBUyxDQUFDLElBQVYsQ0FBZSxDQUFmO0VBQVY7O0VBRTlCLE1BQU0sQ0FBQyxPQUFQLEdBQ007SUFDUyxzQkFBQTs7Ozs7OztNQUNYLElBQUMsQ0FBQSxXQUFELEdBQWUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFiLENBQUEsQ0FBd0IsQ0FBQSxDQUFBO01BQ3ZDLElBQUEsQ0FBMEIsSUFBQyxDQUFBLFdBQTNCO1FBQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSxJQUFmOztNQUNBLElBQUMsQ0FBQSxVQUFELEdBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDhCQUFoQjtNQUNkLElBQUMsQ0FBQSxJQUFELEdBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLHdCQUFoQjtNQUNSLElBQUMsQ0FBQSxTQUFELEdBQWEsbUJBQUEsR0FBb0IsSUFBQyxDQUFBO01BQ2xDLElBQUMsQ0FBQSxhQUFELEdBQWlCO01BQ2pCLElBQUMsQ0FBQSxhQUFELEdBQWlCO0lBUE47OzJCQVdiLGVBQUEsR0FBaUIsU0FBQTtBQUNmLFVBQUE7TUFBQSxLQUFBLEdBQVEsSUFBQyxDQUFBO2FBRVQsSUFBQSxDQUFLLHNDQUFMLEVBQ0UsU0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixNQUFoQjtRQUNFLElBQUcsS0FBQSxLQUFTLElBQVo7aUJBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixtQ0FBNUIsRUFDSTtZQUFDLE1BQUEsRUFBUSxpQ0FBQSxHQUFrQyxLQUEzQztZQUFvRCxXQUFBLEVBQWEsSUFBakU7V0FESixFQURGO1NBQUEsTUFBQTtVQUtFLElBQUMsQ0FBQSxhQUFELEdBQWlCLENBQUMsQ0FBQyxJQUFGLENBQU8sV0FBVyxDQUFDLEtBQVosQ0FBa0IsTUFBbEIsQ0FBUCxFQUFrQyxTQUFDLE9BQUQ7bUJBQ2pELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBWixDQUFpQixHQUFqQixDQUFxQixDQUFDLEtBQXRCLENBQTZCLHdCQUE3QjtVQURpRCxDQUFsQyxDQUVmLENBQUEsQ0FBQTtVQUNGLElBQUcsSUFBQyxDQUFBLGFBQUQsS0FBa0IsTUFBbEIsSUFBK0IsSUFBQyxDQUFBLGFBQUQsS0FBa0IsSUFBcEQ7bUJBQ0UsS0FBQSxDQUFBLEVBREY7V0FBQSxNQUFBO21CQUdFLElBQUMsQ0FBQSxhQUFELEdBQWlCLEtBSG5CO1dBUkY7O01BREYsQ0FERjtJQUhlOzsyQkFzQmpCLGdCQUFBLEdBQWtCLFNBQUE7QUFDaEIsVUFBQTtNQUFBLElBQVUsSUFBQyxDQUFBLGFBQVg7QUFBQSxlQUFBOztNQUNBLEtBQUEsR0FBUSxJQUFDLENBQUE7YUFFVCxJQUFBLENBQVEsSUFBQyxDQUFBLFVBQUYsR0FBYSxPQUFwQixFQUNFLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixNQUFoQjtVQUNFLElBQUcsS0FBQSxLQUFTLElBQVo7bUJBQ0UsS0FBQSxDQUFBLEVBREY7V0FBQSxNQUFBO1lBR0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0Qix1QkFBNUIsRUFDSTtjQUFDLE1BQUEsRUFBUSxpQ0FBQSxHQUFrQyxLQUEzQztjQUFvRCxXQUFBLEVBQWEsSUFBakU7YUFESjttQkFHQSxLQUFDLENBQUEsYUFBRCxHQUFpQixNQU5uQjs7UUFERjtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FERjtJQUpnQjs7MkJBZWxCLGtCQUFBLEdBQW9CLFNBQUE7TUFDbEIsSUFBVSxJQUFDLENBQUEsYUFBWDtBQUFBLGVBQUE7O2FBQ0EsSUFBQSxDQUFRLElBQUMsQ0FBQSxVQUFGLEdBQWEsZ0JBQWIsR0FBNkIsSUFBQyxDQUFBLElBQTlCLEdBQW1DLFVBQW5DLEdBQTZDLElBQUMsQ0FBQSxXQUFyRCxFQUNFLFNBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsTUFBaEI7UUFDRSxJQUFHLEtBQUEsS0FBUyxJQUFaO2lCQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsdUJBQTVCLEVBQ0k7WUFBQyxNQUFBLEVBQVEsQ0FBQSxpQ0FBQSxHQUFrQyxLQUFsQyxHQUEwQyxFQUFFLENBQUMsR0FBN0MsQ0FBQSxHQUNULHlEQURBO1lBRUEsV0FBQSxFQUFhLElBRmI7V0FESixFQURGO1NBQUEsTUFBQTtpQkFPRSxJQUFDLENBQUEsYUFBRCxHQUFpQixLQVBuQjs7TUFERixDQURGO0lBRmtCOzsyQkFrQnBCLGNBQUEsR0FBZ0IsU0FBQTtBQUNkLFVBQUE7TUFBQSxXQUFBLEdBQWMsSUFBQyxDQUFBO2FBRWYsSUFBQSxDQUFLLHNDQUFMLEVBQ0UsU0FBQyxLQUFELEVBQVEsTUFBUixFQUFnQixNQUFoQjtBQUNFLFlBQUE7UUFBQSxJQUFHLEtBQUEsS0FBUyxJQUFaO2lCQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsZ0NBQTVCLEVBQ0k7WUFBQyxNQUFBLEVBQVEsaUNBQUEsR0FBa0MsS0FBM0M7WUFBb0QsV0FBQSxFQUFhLElBQWpFO1dBREosRUFERjtTQUFBLE1BQUE7VUFLRSxJQUFDLENBQUEsYUFBRCxHQUFpQixDQUFDLENBQUMsSUFBRixDQUFPLFdBQVcsQ0FBQyxLQUFaLENBQWtCLE1BQWxCLENBQVAsRUFBa0MsU0FBQyxPQUFEO21CQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLElBQVosQ0FBaUIsR0FBakIsQ0FBcUIsQ0FBQyxLQUF0QixDQUE2QiwwQ0FBN0I7VUFEaUQsQ0FBbEM7VUFHakIsSUFBRyxJQUFDLENBQUEsYUFBYSxDQUFDLE1BQWYsR0FBd0IsQ0FBM0I7QUFDRTtjQUNFLElBQWtELElBQUMsQ0FBQSxhQUFuRDtnQkFBQSxPQUFPLENBQUMsSUFBUixDQUFhLElBQUMsQ0FBQSxhQUFhLENBQUMsR0FBSSxDQUFBLENBQUEsQ0FBaEMsRUFBb0MsU0FBcEMsRUFBQTtlQURGO2FBQUEsY0FBQTtjQUVNO2NBRUosT0FBTyxDQUFDLEtBQVIsQ0FBYyw2QkFBQSxHQUE4QixFQUE1QyxFQUpGOzttQkFLQSxXQUFBLENBQUEsRUFORjtXQVJGOztNQURGLENBREY7SUFIYzs7MkJBc0JoQixVQUFBLEdBQVksU0FBQTtNQUNWLElBQVUsQ0FBQyxJQUFDLENBQUEsYUFBWjtBQUFBLGVBQUE7O2FBQ0EsSUFBQSxDQUFRLElBQUMsQ0FBQSxVQUFGLEdBQWEsT0FBcEIsRUFDRSxTQUFDLEtBQUQsRUFBUSxNQUFSLEVBQWdCLE1BQWhCO1FBQ0UsSUFBRyxLQUFBLEtBQVMsSUFBWjtpQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLHVCQUE1QixFQUNJO1lBQUMsTUFBQSxFQUFRLGlDQUFBLEdBQWtDLEtBQTNDO1lBQW9ELFdBQUEsRUFBYSxJQUFqRTtXQURKLEVBREY7U0FBQSxNQUFBO2lCQUtFLElBQUMsQ0FBQSxhQUFELEdBQWlCLE1BTG5COztNQURGLENBREY7SUFGVTs7MkJBWVosZUFBQSxHQUFpQixTQUFDLE1BQUQsRUFBUyxNQUFULEVBQWlCLEdBQWpCLEVBQXNCLE1BQXRCLEVBQThCLFFBQTlCO0FBQ2YsVUFBQTtNQUFBLElBQUEsR0FBTyxNQUFNLENBQUMsT0FBUCxDQUFBLENBQWdCLENBQUMsVUFBakIsQ0FBNEIsSUFBNUIsRUFBa0MsSUFBbEMsQ0FBdUMsQ0FDdEIsVUFEakIsQ0FDNEIsR0FENUIsRUFDaUMsS0FEakM7TUFHUCxPQUFBLEdBQ0U7UUFBQSxPQUFBLEVBQVMsaUJBQVQ7UUFDQSxPQUFBLEVBQVMsSUFBQyxDQUFBLFdBRFY7UUFFQSxJQUFBLEVBQU0sTUFBTSxDQUFDLE9BQVAsQ0FBQSxDQUZOO1FBR0EsSUFBQSxFQUFNLElBSE47UUFJQSxRQUFBLEVBQ0U7VUFBQSxHQUFBLEVBQUssR0FBTDtVQUNBLE1BQUEsRUFBUSxNQURSO1NBTEY7O01BUUYsQ0FBQyxDQUFDLElBQUYsQ0FBTyxJQUFDLENBQUEsU0FBUixFQUNFO1FBQUEsSUFBQSxFQUFNLE1BQU47UUFDQSxRQUFBLEVBQVUsTUFEVjtRQUVBLFdBQUEsRUFBYSxrQkFGYjtRQUdBLElBQUEsRUFBTSxJQUFJLENBQUMsU0FBTCxDQUFlLE9BQWYsQ0FITjtRQUlBLEtBQUEsRUFBTyxTQUFDLEtBQUQsRUFBUSxVQUFSLEVBQW9CLFdBQXBCO1VBR0wsUUFBQSxDQUFTLEVBQVQ7aUJBQ0EsT0FBTyxDQUFDLEtBQVIsQ0FBYyxVQUFkO1FBSkssQ0FKUDtRQVNBLE9BQUEsRUFBUyxTQUFDLElBQUQsRUFBTyxVQUFQLEVBQW1CLEtBQW5CO2lCQUNQLFFBQUEsQ0FBUyxJQUFJLENBQUMsV0FBZDtRQURPLENBVFQ7T0FERjtBQWFBLGFBQU87SUExQlE7Ozs7O0FBNUduQiIsInNvdXJjZXNDb250ZW50IjpbIiQgPSByZXF1aXJlKCdqcXVlcnknKVxuVGFibGVQYXJzZXIgPSByZXF1aXJlKCd0YWJsZS1wYXJzZXInKVxuZXhlYyA9IHJlcXVpcmUoJ2NoaWxkX3Byb2Nlc3MnKS5leGVjXG5vcyA9IHJlcXVpcmUoJ29zJylcblN0cmluZy5wcm90b3R5cGUucmVwbGFjZUFsbCA9IChzLCByKSAtPiBAc3BsaXQocykuam9pbihyKVxuXG5tb2R1bGUuZXhwb3J0cyA9XG5jbGFzcyBSc2Vuc2VDbGllbnRcbiAgY29uc3RydWN0b3I6IC0+XG4gICAgQHByb2plY3RQYXRoID0gYXRvbS5wcm9qZWN0LmdldFBhdGhzKClbMF1cbiAgICBAcHJvamVjdFBhdGggPSAnLicgdW5sZXNzIEBwcm9qZWN0UGF0aFxuICAgIEByc2Vuc2VQYXRoID0gYXRvbS5jb25maWcuZ2V0KCdhdXRvY29tcGxldGUtcnVieS5yc2Vuc2VQYXRoJylcbiAgICBAcG9ydCA9IGF0b20uY29uZmlnLmdldCgnYXV0b2NvbXBsZXRlLXJ1YnkucG9ydCcpXG4gICAgQHNlcnZlclVybCA9IFwiaHR0cDovL2xvY2FsaG9zdDoje0Bwb3J0fVwiXG4gICAgQHJzZW5zZVN0YXJ0ZWQgPSBmYWxzZVxuICAgIEByc2Vuc2VQcm9jZXNzID0gbnVsbFxuXG4gICMgQ2hlY2sgaWYgYW4gcnNlbnNlIHNlcnZlciBpcyBhbHJlYWR5IHJ1bm5pbmcuXG4gICMgVGhpcyBjYW4gZGV0ZWN0IGFsbCByc2Vuc2UgcHJvY2Vzc2VzIGV2ZW4gdGhvc2Ugd2l0aG91dCBwaWQgZmlsZXMuXG4gIHN0YXJ0UnNlbnNlVW5peDogPT5cbiAgICBzdGFydCA9IEBzdGFydFJzZW5zZUNvbW1hbmRcblxuICAgIGV4ZWMoXCJwcyAtZWYgfCBoZWFkIC0xOyBwcyAtZWYgfCBncmVwIGphdmFcIixcbiAgICAgIChlcnJvciwgc3Rkb3V0LCBzdGRlcnIpIC0+XG4gICAgICAgIGlmIGVycm9yICE9IG51bGxcbiAgICAgICAgICBhdG9tLm5vdGlmaWNhdGlvbnMuYWRkRXJyb3IoJ0Vycm9yIGxvb2tpbmcgZm9yIHJlc2Vuc2UgcHJvY2VzcycsXG4gICAgICAgICAgICAgIHtkZXRhaWw6IFwiYXV0b2NvbXBsZXRlLXJ1Ynk6IGV4ZWMgZXJyb3I6ICN7ZXJyb3J9XCIsIGRpc21pc3NhYmxlOiB0cnVlfVxuICAgICAgICAgICAgKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgQHJzZW5zZVByb2Nlc3MgPSAkLmdyZXAoVGFibGVQYXJzZXIucGFyc2Uoc3Rkb3V0KSwgKHByb2Nlc3MpIC0+XG4gICAgICAgICAgICBwcm9jZXNzLkNNRC5qb2luKCcgJykubWF0Y2goIC9yc2Vuc2UuKi0tcG9ydC4qLS1wYXRoLyApXG4gICAgICAgICAgKVswXVxuICAgICAgICAgIGlmIEByc2Vuc2VQcm9jZXNzID09IHVuZGVmaW5lZCB8fCBAcnNlbnNlUHJvY2VzcyA9PSBudWxsXG4gICAgICAgICAgICBzdGFydCgpXG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgQHJzZW5zZVN0YXJ0ZWQgPSB0cnVlXG4gICAgKVxuXG4gICMgQmVmb3JlIHRyeWluZyB0byBzdGFydCBpbiBXaW5kb3dzIHdlIG5lZWQgdG8ga2lsbCBhbnkgZXhpc3RpbmcgcnNlbnNlIHNlcnZlcnMsIHNvXG4gICMgYXMgdG8gbm90IGVuZCB1cCB3aXRoIG11bHRpcGxlIHJzZW5zZSBzZXJ2c2VycyB1bmtpbGxhYmxlIGJ5ICdyc2Vuc2Ugc3RvcCdcbiAgIyBUaGlzIG1lYW5zIHRoYXQgcnVubmluZyB0d28gYXRvbXMgYW5kIGNsb3Npbmcgb25lLCBraWxscyByc2Vuc2UgZm9yIHRoZSBvdGhlclxuICBzdGFydFJzZW5zZVdpbjMyOiA9PlxuICAgIHJldHVybiBpZiBAcnNlbnNlU3RhcnRlZFxuICAgIHN0YXJ0ID0gQHN0YXJ0UnNlbnNlQ29tbWFuZFxuXG4gICAgZXhlYyhcIiN7QHJzZW5zZVBhdGh9IHN0b3BcIixcbiAgICAgIChlcnJvciwgc3Rkb3V0LCBzdGRlcnIpID0+XG4gICAgICAgIGlmIGVycm9yID09IG51bGxcbiAgICAgICAgICBzdGFydCgpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBhdG9tLm5vdGlmaWNhdGlvbnMuYWRkRXJyb3IoJ0Vycm9yIHN0b3BwaW5nIHJzZW5zZScsXG4gICAgICAgICAgICAgIHtkZXRhaWw6IFwiYXV0b2NvbXBsZXRlLXJ1Ynk6IGV4ZWMgZXJyb3I6ICN7ZXJyb3J9XCIsIGRpc21pc3NhYmxlOiB0cnVlfVxuICAgICAgICAgICAgKVxuICAgICAgICAgIEByc2Vuc2VTdGFydGVkID0gZmFsc2VcbiAgICApXG5cbiAgc3RhcnRSc2Vuc2VDb21tYW5kOiA9PlxuICAgIHJldHVybiBpZiBAcnNlbnNlU3RhcnRlZFxuICAgIGV4ZWMoXCIje0Byc2Vuc2VQYXRofSBzdGFydCAtLXBvcnQgI3tAcG9ydH0gLS1wYXRoICN7QHByb2plY3RQYXRofVwiLFxuICAgICAgKGVycm9yLCBzdGRvdXQsIHN0ZGVycikgLT5cbiAgICAgICAgaWYgZXJyb3IgIT0gbnVsbFxuICAgICAgICAgIGF0b20ubm90aWZpY2F0aW9ucy5hZGRFcnJvcignRXJyb3Igc3RhcnRpbmcgcnNlbnNlJyxcbiAgICAgICAgICAgICAge2RldGFpbDogXCJhdXRvY29tcGxldGUtcnVieTogZXhlYyBlcnJvcjogI3tlcnJvcn0je29zLkVPTH1cIiArXG4gICAgICAgICAgICAgIFwiKFlvdSBtaWdodCBuZWVkIHRvIHNldCB0aGUgcnNlbnNlIHBhdGgsIHNlZSB0aGUgcmVhZG1lKVwiLFxuICAgICAgICAgICAgICBkaXNtaXNzYWJsZTogdHJ1ZX1cbiAgICAgICAgICAgIClcbiAgICAgICAgZWxzZVxuICAgICAgICAgIEByc2Vuc2VTdGFydGVkID0gdHJ1ZVxuICAgIClcblxuICAjIEZpcnN0IGNvdW50IGhvdyBtYW55IGF0b20gd2luZG93cyBhcmUgb3Blbi5cbiAgIyBJZiB0aGVyZSBpcyBvbmx5IG9uZSBvcGVuLCB0aGVuIGtpbGwgdGhlIHJzZW5zZSBwcm9jZXNzLlxuICAjIFRoaXMgaXMgYWxzbyBhYmxlIHRvIGtpbGwgYW4gcnNlbnNlIHByb2Nlc3Mgd2l0aG91dCBhIHBpZCBmaWxlLlxuICAjIE90aGVyd2lzZSBkbyBub3RoaW5nIHNvIHlvdSB3aWxsIHN0aWxsIGJlIGFibGUgdG8gdXNlIHJzZW5zZSBpbiBvdGhlciB3aW5kb3dzLlxuICBzdG9wUnNlbnNlVW5peDogPT5cbiAgICBzdG9wQ29tbWFuZCA9IEBzdG9wUnNlbnNlXG5cbiAgICBleGVjKFwicHMgLWVmIHwgaGVhZCAtMTsgcHMgLWVmIHwgZ3JlcCBhdG9tXCIsXG4gICAgICAoZXJyb3IsIHN0ZG91dCwgc3RkZXJyKSAtPlxuICAgICAgICBpZiBlcnJvciAhPSBudWxsXG4gICAgICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZEVycm9yKCdFcnJvciBsb29raW5nIGZvciBhdG9tIHByb2Nlc3MnLFxuICAgICAgICAgICAgICB7ZGV0YWlsOiBcImF1dG9jb21wbGV0ZS1ydWJ5OiBleGVjIGVycm9yOiAje2Vycm9yfVwiLCBkaXNtaXNzYWJsZTogdHJ1ZX1cbiAgICAgICAgICAgIClcbiAgICAgICAgZWxzZVxuICAgICAgICAgIEBhdG9tUHJvY2Vzc2VzID0gJC5ncmVwKFRhYmxlUGFyc2VyLnBhcnNlKHN0ZG91dCksIChwcm9jZXNzKSAtPlxuICAgICAgICAgICAgcHJvY2Vzcy5DTUQuam9pbignICcpLm1hdGNoKCAvLS10eXBlPXJlbmRlcmVyLiotLW5vZGUtaW50ZWdyYXRpb249dHJ1ZS8gKVxuICAgICAgICAgIClcbiAgICAgICAgICBpZiBAYXRvbVByb2Nlc3Nlcy5sZW5ndGggPCAyXG4gICAgICAgICAgICB0cnlcbiAgICAgICAgICAgICAgcHJvY2Vzcy5raWxsKEByc2Vuc2VQcm9jZXNzLlBJRFswXSwgJ1NJR0tJTEwnKSBpZiBAcnNlbnNlUHJvY2Vzc1xuICAgICAgICAgICAgY2F0Y2ggZXhcbiAgICAgICAgICAgICAgIyBpZ25vcmUgZXJyb3IgaWYga2lsbCBmYWlsc1xuICAgICAgICAgICAgICBjb25zb2xlLmRlYnVnIFwiZXhjZXB0aW9uIGtpbGxpbmcgcHJvY2VzczogI3tleH1cIlxuICAgICAgICAgICAgc3RvcENvbW1hbmQoKVxuICAgIClcblxuICBzdG9wUnNlbnNlOiA9PlxuICAgIHJldHVybiBpZiAhQHJzZW5zZVN0YXJ0ZWRcbiAgICBleGVjKFwiI3tAcnNlbnNlUGF0aH0gc3RvcFwiLFxuICAgICAgKGVycm9yLCBzdGRvdXQsIHN0ZGVycikgLT5cbiAgICAgICAgaWYgZXJyb3IgIT0gbnVsbFxuICAgICAgICAgIGF0b20ubm90aWZpY2F0aW9ucy5hZGRFcnJvcignRXJyb3Igc3RvcHBpbmcgcnNlbnNlJyxcbiAgICAgICAgICAgICAge2RldGFpbDogXCJhdXRvY29tcGxldGUtcnVieTogZXhlYyBlcnJvcjogI3tlcnJvcn1cIiwgZGlzbWlzc2FibGU6IHRydWV9XG4gICAgICAgICAgICApXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBAcnNlbnNlU3RhcnRlZCA9IGZhbHNlXG4gICAgKVxuXG4gIGNoZWNrQ29tcGxldGlvbjogKGVkaXRvciwgYnVmZmVyLCByb3csIGNvbHVtbiwgY2FsbGJhY2spID0+XG4gICAgY29kZSA9IGJ1ZmZlci5nZXRUZXh0KCkucmVwbGFjZUFsbCgnXFxuJywgJ1xcbicpLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcGxhY2VBbGwoJyUnLCAnJTI1JylcblxuICAgIHJlcXVlc3QgPVxuICAgICAgY29tbWFuZDogJ2NvZGVfY29tcGxldGlvbidcbiAgICAgIHByb2plY3Q6IEBwcm9qZWN0UGF0aFxuICAgICAgZmlsZTogZWRpdG9yLmdldFBhdGgoKVxuICAgICAgY29kZTogY29kZVxuICAgICAgbG9jYXRpb246XG4gICAgICAgIHJvdzogcm93XG4gICAgICAgIGNvbHVtbjogY29sdW1uXG5cbiAgICAkLmFqYXggQHNlcnZlclVybCxcbiAgICAgIHR5cGU6ICdQT1NUJ1xuICAgICAgZGF0YVR5cGU6ICdqc29uJ1xuICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIGRhdGE6IEpTT04uc3RyaW5naWZ5IHJlcXVlc3RcbiAgICAgIGVycm9yOiAoanFYSFIsIHRleHRTdGF0dXMsIGVycm9yVGhyb3duKSAtPlxuICAgICAgICAjIHNlbmQgZW1wdHkgYXJyYXkgdG8gY2FsbGJhY2tcbiAgICAgICAgIyB0byBhdm9pZCBhdXRvY29tcGxldGUtcGx1cyBicmlja1xuICAgICAgICBjYWxsYmFjayBbXVxuICAgICAgICBjb25zb2xlLmVycm9yIHRleHRTdGF0dXNcbiAgICAgIHN1Y2Nlc3M6IChkYXRhLCB0ZXh0U3RhdHVzLCBqcVhIUikgLT5cbiAgICAgICAgY2FsbGJhY2sgZGF0YS5jb21wbGV0aW9uc1xuXG4gICAgcmV0dXJuIFtdXG4iXX0=
