(function() {
  var RubyTest, RubyTestView;

  RubyTest = require('../lib/ruby-test');

  RubyTestView = require('../lib/ruby-test-view');

  describe("RubyTest", function() {
    var activationPromise, workspaceElement;
    activationPromise = null;
    workspaceElement = null;
    beforeEach(function() {
      workspaceElement = atom.views.getView(atom.workspace);
      return activationPromise = atom.packages.activatePackage('ruby-test');
    });
    return describe("when the ruby-test:test-file event is triggered", function() {
      return it("displays the platformio-ide-terminal", function() {
        spyOn(RubyTestView.prototype, 'initialize').andReturn({
          destroy: function() {}
        });
        atom.commands.dispatch(workspaceElement, 'ruby-test:test-file');
        waitsForPromise(function() {
          return require('atom-package-deps').install('ruby-test');
        });
        waitsForPromise(function() {
          return activationPromise;
        });
        return runs(function() {
          return atom.packages.activatePackage('platformio-ide-terminal').then(function() {
            return expect(RubyTestView.prototype.initialize).toHaveBeenCalled();
          });
        });
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9zcGVjL3J1YnktdGVzdC1zcGVjLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsUUFBQSxHQUFXLE9BQUEsQ0FBUSxrQkFBUjs7RUFDWCxZQUFBLEdBQWUsT0FBQSxDQUFRLHVCQUFSOztFQU9mLFFBQUEsQ0FBUyxVQUFULEVBQXFCLFNBQUE7QUFDbkIsUUFBQTtJQUFBLGlCQUFBLEdBQW9CO0lBQ3BCLGdCQUFBLEdBQW1CO0lBRW5CLFVBQUEsQ0FBVyxTQUFBO01BQ1QsZ0JBQUEsR0FBbUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFYLENBQW1CLElBQUksQ0FBQyxTQUF4QjthQUNuQixpQkFBQSxHQUFvQixJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWQsQ0FBOEIsV0FBOUI7SUFGWCxDQUFYO1dBSUEsUUFBQSxDQUFTLGlEQUFULEVBQTRELFNBQUE7YUFDMUQsRUFBQSxDQUFHLHNDQUFILEVBQTJDLFNBQUE7UUFDekMsS0FBQSxDQUFNLFlBQVksQ0FBQyxTQUFuQixFQUE4QixZQUE5QixDQUEyQyxDQUFDLFNBQTVDLENBQXNEO1VBQUUsT0FBQSxFQUFTLFNBQUEsR0FBQSxDQUFYO1NBQXREO1FBSUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFkLENBQXVCLGdCQUF2QixFQUF5QyxxQkFBekM7UUFFQSxlQUFBLENBQWdCLFNBQUE7aUJBQ2QsT0FBQSxDQUFRLG1CQUFSLENBQTRCLENBQUMsT0FBN0IsQ0FBcUMsV0FBckM7UUFEYyxDQUFoQjtRQUdBLGVBQUEsQ0FBZ0IsU0FBQTtpQkFFZDtRQUZjLENBQWhCO2VBSUEsSUFBQSxDQUFLLFNBQUE7aUJBQ0gsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFkLENBQThCLHlCQUE5QixDQUF3RCxDQUFDLElBQXpELENBQThELFNBQUE7bUJBQzVELE1BQUEsQ0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDLFVBQTlCLENBQXlDLENBQUMsZ0JBQTFDLENBQUE7VUFENEQsQ0FBOUQ7UUFERyxDQUFMO01BZHlDLENBQTNDO0lBRDBELENBQTVEO0VBUm1CLENBQXJCO0FBUkEiLCJzb3VyY2VzQ29udGVudCI6WyJSdWJ5VGVzdCA9IHJlcXVpcmUgJy4uL2xpYi9ydWJ5LXRlc3QnXG5SdWJ5VGVzdFZpZXcgPSByZXF1aXJlICcuLi9saWIvcnVieS10ZXN0LXZpZXcnXG5cbiMgVXNlIHRoZSBjb21tYW5kIGB3aW5kb3c6cnVuLXBhY2thZ2Utc3BlY3NgIChjbWQtYWx0LWN0cmwtcCkgdG8gcnVuIHNwZWNzLlxuI1xuIyBUbyBydW4gYSBzcGVjaWZpYyBgaXRgIG9yIGBkZXNjcmliZWAgYmxvY2sgYWRkIGFuIGBmYCB0byB0aGUgZnJvbnQgKGUuZy4gYGZpdGBcbiMgb3IgYGZkZXNjcmliZWApLiBSZW1vdmUgdGhlIGBmYCB0byB1bmZvY3VzIHRoZSBibG9jay5cblxuZGVzY3JpYmUgXCJSdWJ5VGVzdFwiLCAtPlxuICBhY3RpdmF0aW9uUHJvbWlzZSA9IG51bGxcbiAgd29ya3NwYWNlRWxlbWVudCA9IG51bGxcblxuICBiZWZvcmVFYWNoIC0+XG4gICAgd29ya3NwYWNlRWxlbWVudCA9IGF0b20udmlld3MuZ2V0VmlldyhhdG9tLndvcmtzcGFjZSlcbiAgICBhY3RpdmF0aW9uUHJvbWlzZSA9IGF0b20ucGFja2FnZXMuYWN0aXZhdGVQYWNrYWdlKCdydWJ5LXRlc3QnKVxuXG4gIGRlc2NyaWJlIFwid2hlbiB0aGUgcnVieS10ZXN0OnRlc3QtZmlsZSBldmVudCBpcyB0cmlnZ2VyZWRcIiwgLT5cbiAgICBpdCBcImRpc3BsYXlzIHRoZSBwbGF0Zm9ybWlvLWlkZS10ZXJtaW5hbFwiLCAtPlxuICAgICAgc3B5T24oUnVieVRlc3RWaWV3LnByb3RvdHlwZSwgJ2luaXRpYWxpemUnKS5hbmRSZXR1cm4oeyBkZXN0cm95OiAtPiB9KVxuXG4gICAgICAjIFRoaXMgaXMgYW4gYWN0aXZhdGlvbiBldmVudCwgdHJpZ2dlcmluZyBpdCB3aWxsIGNhdXNlIHRoZSBwYWNrYWdlIHRvIGJlXG4gICAgICAjIGFjdGl2YXRlZC5cbiAgICAgIGF0b20uY29tbWFuZHMuZGlzcGF0Y2ggd29ya3NwYWNlRWxlbWVudCwgJ3J1YnktdGVzdDp0ZXN0LWZpbGUnXG5cbiAgICAgIHdhaXRzRm9yUHJvbWlzZSAtPlxuICAgICAgICByZXF1aXJlKCdhdG9tLXBhY2thZ2UtZGVwcycpLmluc3RhbGwoJ3J1YnktdGVzdCcpXG5cbiAgICAgIHdhaXRzRm9yUHJvbWlzZSAtPlxuICAgICAgICAjIGF0b20ucGFja2FnZXMuYWN0aXZhdGVQYWNrYWdlKCdydWJ5LXRlc3QnKVxuICAgICAgICBhY3RpdmF0aW9uUHJvbWlzZVxuXG4gICAgICBydW5zIC0+XG4gICAgICAgIGF0b20ucGFja2FnZXMuYWN0aXZhdGVQYWNrYWdlKCdwbGF0Zm9ybWlvLWlkZS10ZXJtaW5hbCcpLnRoZW4gLT5cbiAgICAgICAgICBleHBlY3QoUnVieVRlc3RWaWV3LnByb3RvdHlwZS5pbml0aWFsaXplKS50b0hhdmVCZWVuQ2FsbGVkKClcbiJdfQ==
