(function() {
  var AutoIndent;

  AutoIndent = require('../lib/auto-indent');

  describe("AutoIndent", function() {
    var activationPromise;
    activationPromise = null;
    beforeEach(function() {
      atom.workspaceView = new WorkspaceView;
      return activationPromise = atom.packages.activatePackage('autoIndent');
    });
    return describe("when the auto-indent:toggle event is triggered", function() {
      return it("attaches and then detaches the view", function() {
        expect(atom.workspaceView.find('.auto-indent')).not.toExist();
        atom.workspaceView.trigger('auto-indent:toggle');
        waitsForPromise(function() {
          return activationPromise;
        });
        return runs(function() {
          expect(atom.workspaceView.find('.auto-indent')).toExist();
          atom.workspaceView.trigger('auto-indent:toggle');
          return expect(atom.workspaceView.find('.auto-indent')).not.toExist();
        });
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL2F1dG8taW5kZW50L3NwZWMvYXV0by1pbmRlbnQtc3BlYy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLFVBQUEsR0FBYSxPQUFBLENBQVEsb0JBQVI7O0VBT2IsUUFBQSxDQUFTLFlBQVQsRUFBdUIsU0FBQTtBQUNyQixRQUFBO0lBQUEsaUJBQUEsR0FBb0I7SUFFcEIsVUFBQSxDQUFXLFNBQUE7TUFDVCxJQUFJLENBQUMsYUFBTCxHQUFxQixJQUFJO2FBQ3pCLGlCQUFBLEdBQW9CLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZCxDQUE4QixZQUE5QjtJQUZYLENBQVg7V0FJQSxRQUFBLENBQVMsZ0RBQVQsRUFBMkQsU0FBQTthQUN6RCxFQUFBLENBQUcscUNBQUgsRUFBMEMsU0FBQTtRQUN4QyxNQUFBLENBQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFuQixDQUF3QixjQUF4QixDQUFQLENBQStDLENBQUMsR0FBRyxDQUFDLE9BQXBELENBQUE7UUFJQSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQW5CLENBQTJCLG9CQUEzQjtRQUVBLGVBQUEsQ0FBZ0IsU0FBQTtpQkFDZDtRQURjLENBQWhCO2VBR0EsSUFBQSxDQUFLLFNBQUE7VUFDSCxNQUFBLENBQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFuQixDQUF3QixjQUF4QixDQUFQLENBQStDLENBQUMsT0FBaEQsQ0FBQTtVQUNBLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBbkIsQ0FBMkIsb0JBQTNCO2lCQUNBLE1BQUEsQ0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQW5CLENBQXdCLGNBQXhCLENBQVAsQ0FBK0MsQ0FBQyxHQUFHLENBQUMsT0FBcEQsQ0FBQTtRQUhHLENBQUw7TUFWd0MsQ0FBMUM7SUFEeUQsQ0FBM0Q7RUFQcUIsQ0FBdkI7QUFQQSIsInNvdXJjZXNDb250ZW50IjpbIkF1dG9JbmRlbnQgPSByZXF1aXJlICcuLi9saWIvYXV0by1pbmRlbnQnXG5cbiMgVXNlIHRoZSBjb21tYW5kIGB3aW5kb3c6cnVuLXBhY2thZ2Utc3BlY3NgIChjbWQtYWx0LWN0cmwtcCkgdG8gcnVuIHNwZWNzLlxuI1xuIyBUbyBydW4gYSBzcGVjaWZpYyBgaXRgIG9yIGBkZXNjcmliZWAgYmxvY2sgYWRkIGFuIGBmYCB0byB0aGUgZnJvbnQgKGUuZy4gYGZpdGBcbiMgb3IgYGZkZXNjcmliZWApLiBSZW1vdmUgdGhlIGBmYCB0byB1bmZvY3VzIHRoZSBibG9jay5cblxuZGVzY3JpYmUgXCJBdXRvSW5kZW50XCIsIC0+XG4gIGFjdGl2YXRpb25Qcm9taXNlID0gbnVsbFxuXG4gIGJlZm9yZUVhY2ggLT5cbiAgICBhdG9tLndvcmtzcGFjZVZpZXcgPSBuZXcgV29ya3NwYWNlVmlld1xuICAgIGFjdGl2YXRpb25Qcm9taXNlID0gYXRvbS5wYWNrYWdlcy5hY3RpdmF0ZVBhY2thZ2UoJ2F1dG9JbmRlbnQnKVxuXG4gIGRlc2NyaWJlIFwid2hlbiB0aGUgYXV0by1pbmRlbnQ6dG9nZ2xlIGV2ZW50IGlzIHRyaWdnZXJlZFwiLCAtPlxuICAgIGl0IFwiYXR0YWNoZXMgYW5kIHRoZW4gZGV0YWNoZXMgdGhlIHZpZXdcIiwgLT5cbiAgICAgIGV4cGVjdChhdG9tLndvcmtzcGFjZVZpZXcuZmluZCgnLmF1dG8taW5kZW50JykpLm5vdC50b0V4aXN0KClcblxuICAgICAgIyBUaGlzIGlzIGFuIGFjdGl2YXRpb24gZXZlbnQsIHRyaWdnZXJpbmcgaXQgd2lsbCBjYXVzZSB0aGUgcGFja2FnZSB0byBiZVxuICAgICAgIyBhY3RpdmF0ZWQuXG4gICAgICBhdG9tLndvcmtzcGFjZVZpZXcudHJpZ2dlciAnYXV0by1pbmRlbnQ6dG9nZ2xlJ1xuXG4gICAgICB3YWl0c0ZvclByb21pc2UgLT5cbiAgICAgICAgYWN0aXZhdGlvblByb21pc2VcblxuICAgICAgcnVucyAtPlxuICAgICAgICBleHBlY3QoYXRvbS53b3Jrc3BhY2VWaWV3LmZpbmQoJy5hdXRvLWluZGVudCcpKS50b0V4aXN0KClcbiAgICAgICAgYXRvbS53b3Jrc3BhY2VWaWV3LnRyaWdnZXIgJ2F1dG8taW5kZW50OnRvZ2dsZSdcbiAgICAgICAgZXhwZWN0KGF0b20ud29ya3NwYWNlVmlldy5maW5kKCcuYXV0by1pbmRlbnQnKSkubm90LnRvRXhpc3QoKVxuIl19
