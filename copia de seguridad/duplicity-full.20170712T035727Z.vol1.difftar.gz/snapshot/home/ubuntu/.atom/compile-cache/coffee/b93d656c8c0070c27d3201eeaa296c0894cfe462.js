(function() {
  var Command, SourceInfo, TestRunner, Utility,
    bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  SourceInfo = require('./source-info');

  Command = require('./command');

  Utility = require('./utility');

  module.exports = TestRunner = (function() {
    function TestRunner(params, terminal) {
      this.command = bind(this.command, this);
      this.returnFocusToEditorAfterTerminalRun = bind(this.returnFocusToEditorAfterTerminalRun, this);
      this.initialize(params, terminal);
    }

    TestRunner.prototype.initialize = function(params, terminal) {
      this.terminal = terminal;
      this.params = params;
      this.sourceInfo = new SourceInfo();
      return this.utility = new Utility;
    };

    TestRunner.prototype.run = function() {
      var terminals;
      if (atom.packages.isPackageDisabled('platformio-ide-terminal')) {
        alert("Platformio IDE Terminal package is disabled. It must be enabled to run tests.");
        return;
      }
      if (this.terminal.lastTerminalForTest) {
        this.terminal.lastTerminalForTest.closeBtn.click();
      }
      this.returnFocusToEditorAfterTerminalRun();
      this.terminal.run([this.command()]);
      terminals = this.terminal.getTerminalViews();
      return this.terminal.lastTerminalForTest = terminals[terminals.length - 1];
    };

    TestRunner.prototype.returnFocusToEditorAfterTerminalRun = function() {
      var cursorPos, editor;
      editor = this.utility.editor();
      if (editor == null) {
        return;
      }
      cursorPos = editor.getCursorBufferPosition();
      return setTimeout(function() {
        var base, i, len, panel, panels;
        editor.setCursorBufferPosition(cursorPos, {
          autoscroll: true
        });
        panels = atom.workspace.getBottomPanels();
        for (i = 0, len = panels.length; i < len; i++) {
          panel = panels[i];
          if (typeof (base = panel.getItem()).hasClass === "function" ? base.hasClass('platformio-ide-terminal') : void 0) {
            panel.getItem().blur();
          }
        }
        return editor.getElement().focus();
      }, 700);
    };

    TestRunner.prototype.command = function() {
      var cmd, framework;
      framework = this.sourceInfo.testFramework();
      cmd = Command.testCommand(this.params.testScope, framework);
      return cmd.replace('{relative_path}', this.sourceInfo.activeFile()).replace('{line_number}', this.sourceInfo.currentLine()).replace('{regex}', this.sourceInfo.minitestRegExp());
    };

    return TestRunner;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9saWIvdGVzdC1ydW5uZXIuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQSx3Q0FBQTtJQUFBOztFQUFBLFVBQUEsR0FBYSxPQUFBLENBQVEsZUFBUjs7RUFDYixPQUFBLEdBQVUsT0FBQSxDQUFRLFdBQVI7O0VBQ1YsT0FBQSxHQUFVLE9BQUEsQ0FBUSxXQUFSOztFQUVWLE1BQU0sQ0FBQyxPQUFQLEdBQ1E7SUFDUyxvQkFBQyxNQUFELEVBQVMsUUFBVDs7O01BQ1gsSUFBQyxDQUFBLFVBQUQsQ0FBWSxNQUFaLEVBQW9CLFFBQXBCO0lBRFc7O3lCQUdiLFVBQUEsR0FBWSxTQUFDLE1BQUQsRUFBUyxRQUFUO01BQ1YsSUFBQyxDQUFBLFFBQUQsR0FBWTtNQUNaLElBQUMsQ0FBQSxNQUFELEdBQVU7TUFDVixJQUFDLENBQUEsVUFBRCxHQUFrQixJQUFBLFVBQUEsQ0FBQTthQUNsQixJQUFDLENBQUEsT0FBRCxHQUFXLElBQUk7SUFKTDs7eUJBTVosR0FBQSxHQUFLLFNBQUE7QUFDSCxVQUFBO01BQUEsSUFBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFkLENBQWdDLHlCQUFoQyxDQUFIO1FBQ0UsS0FBQSxDQUFNLCtFQUFOO0FBQ0EsZUFGRjs7TUFJQSxJQUFJLElBQUMsQ0FBQSxRQUFRLENBQUMsbUJBQWQ7UUFFRSxJQUFDLENBQUEsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxLQUF2QyxDQUFBLEVBRkY7O01BSUEsSUFBQyxDQUFBLG1DQUFELENBQUE7TUFFQSxJQUFDLENBQUEsUUFBUSxDQUFDLEdBQVYsQ0FBYyxDQUFDLElBQUMsQ0FBQSxPQUFELENBQUEsQ0FBRCxDQUFkO01BQ0EsU0FBQSxHQUFhLElBQUMsQ0FBQSxRQUFRLENBQUMsZ0JBQVYsQ0FBQTthQUNiLElBQUMsQ0FBQSxRQUFRLENBQUMsbUJBQVYsR0FBZ0MsU0FBVSxDQUFBLFNBQVMsQ0FBQyxNQUFWLEdBQW1CLENBQW5CO0lBYnZDOzt5QkFlTCxtQ0FBQSxHQUFxQyxTQUFBO0FBQ25DLFVBQUE7TUFBQSxNQUFBLEdBQVMsSUFBQyxDQUFBLE9BQU8sQ0FBQyxNQUFULENBQUE7TUFJVCxJQUFjLGNBQWQ7QUFBQSxlQUFBOztNQUVBLFNBQUEsR0FBWSxNQUFNLENBQUMsdUJBQVAsQ0FBQTthQUtaLFVBQUEsQ0FBVyxTQUFBO0FBQ1QsWUFBQTtRQUFBLE1BQU0sQ0FBQyx1QkFBUCxDQUErQixTQUEvQixFQUEwQztVQUFDLFVBQUEsRUFBWSxJQUFiO1NBQTFDO1FBQ0EsTUFBQSxHQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZixDQUFBO0FBQ1QsYUFBQSx3Q0FBQTs7VUFDRSxrRUFBa0IsQ0FBQyxTQUFVLG1DQUE3QjtZQUNFLEtBQUssQ0FBQyxPQUFOLENBQUEsQ0FBZSxDQUFDLElBQWhCLENBQUEsRUFERjs7QUFERjtlQUlBLE1BQU0sQ0FBQyxVQUFQLENBQUEsQ0FBbUIsQ0FBQyxLQUFwQixDQUFBO01BUFMsQ0FBWCxFQVFFLEdBUkY7SUFabUM7O3lCQXVCckMsT0FBQSxHQUFTLFNBQUE7QUFDUCxVQUFBO01BQUEsU0FBQSxHQUFZLElBQUMsQ0FBQSxVQUFVLENBQUMsYUFBWixDQUFBO01BQ1osR0FBQSxHQUFNLE9BQU8sQ0FBQyxXQUFSLENBQW9CLElBQUMsQ0FBQSxNQUFNLENBQUMsU0FBNUIsRUFBdUMsU0FBdkM7YUFDTixHQUFHLENBQUMsT0FBSixDQUFZLGlCQUFaLEVBQStCLElBQUMsQ0FBQSxVQUFVLENBQUMsVUFBWixDQUFBLENBQS9CLENBQXdELENBQ3BELE9BREosQ0FDWSxlQURaLEVBQzZCLElBQUMsQ0FBQSxVQUFVLENBQUMsV0FBWixDQUFBLENBRDdCLENBQ3VELENBQ25ELE9BRkosQ0FFWSxTQUZaLEVBRXVCLElBQUMsQ0FBQSxVQUFVLENBQUMsY0FBWixDQUFBLENBRnZCO0lBSE87Ozs7O0FBckRiIiwic291cmNlc0NvbnRlbnQiOlsiU291cmNlSW5mbyA9IHJlcXVpcmUgJy4vc291cmNlLWluZm8nXG5Db21tYW5kID0gcmVxdWlyZSAnLi9jb21tYW5kJ1xuVXRpbGl0eSA9IHJlcXVpcmUgJy4vdXRpbGl0eSdcblxubW9kdWxlLmV4cG9ydHMgPVxuICBjbGFzcyBUZXN0UnVubmVyXG4gICAgY29uc3RydWN0b3I6IChwYXJhbXMsIHRlcm1pbmFsKSAtPlxuICAgICAgQGluaXRpYWxpemUocGFyYW1zLCB0ZXJtaW5hbClcblxuICAgIGluaXRpYWxpemU6IChwYXJhbXMsIHRlcm1pbmFsKSAtPlxuICAgICAgQHRlcm1pbmFsID0gdGVybWluYWxcbiAgICAgIEBwYXJhbXMgPSBwYXJhbXNcbiAgICAgIEBzb3VyY2VJbmZvID0gbmV3IFNvdXJjZUluZm8oKVxuICAgICAgQHV0aWxpdHkgPSBuZXcgVXRpbGl0eVxuXG4gICAgcnVuOiAtPlxuICAgICAgaWYgYXRvbS5wYWNrYWdlcy5pc1BhY2thZ2VEaXNhYmxlZCgncGxhdGZvcm1pby1pZGUtdGVybWluYWwnKVxuICAgICAgICBhbGVydChcIlBsYXRmb3JtaW8gSURFIFRlcm1pbmFsIHBhY2thZ2UgaXMgZGlzYWJsZWQuIEl0IG11c3QgYmUgZW5hYmxlZCB0byBydW4gdGVzdHMuXCIpXG4gICAgICAgIHJldHVyblxuXG4gICAgICBpZiAoQHRlcm1pbmFsLmxhc3RUZXJtaW5hbEZvclRlc3QpXG4gICAgICAgICMgaWYgd2UgaGF2ZSBhIHByZXZpb3VzIHRlcm1pbmFsIG9wZW5lZCBmcm9tIHRoaXMgdGVzdCBydW5uZXIsIGNsb3NlIGl0XG4gICAgICAgIEB0ZXJtaW5hbC5sYXN0VGVybWluYWxGb3JUZXN0LmNsb3NlQnRuLmNsaWNrKClcblxuICAgICAgQHJldHVybkZvY3VzVG9FZGl0b3JBZnRlclRlcm1pbmFsUnVuKCk7XG5cbiAgICAgIEB0ZXJtaW5hbC5ydW4oW0Bjb21tYW5kKCldKVxuICAgICAgdGVybWluYWxzID0gIEB0ZXJtaW5hbC5nZXRUZXJtaW5hbFZpZXdzKClcbiAgICAgIEB0ZXJtaW5hbC5sYXN0VGVybWluYWxGb3JUZXN0ID0gdGVybWluYWxzW3Rlcm1pbmFscy5sZW5ndGggLSAxXVxuXG4gICAgcmV0dXJuRm9jdXNUb0VkaXRvckFmdGVyVGVybWluYWxSdW46ID0+XG4gICAgICBlZGl0b3IgPSBAdXRpbGl0eS5lZGl0b3IoKVxuXG4gICAgICAjIElmIG5vIGZpbGVzIGFyZSBvcGVuICh3ZSdyZSBydW5uaW5nIHRoZSBlbnRpcmUgc3VpdGUpIHRoZW5cbiAgICAgICMgdGhlcmUgaXMgbm8gY3Vyc29yIHRvIHJldHVybiB0b1xuICAgICAgcmV0dXJuIHVubGVzcyBlZGl0b3I/XG5cbiAgICAgIGN1cnNvclBvcyA9IGVkaXRvci5nZXRDdXJzb3JCdWZmZXJQb3NpdGlvbigpXG5cbiAgICAgICMgSXQgYXBwZWFycyB0aGF0IHRoZSB0ZXJtaW5hbCBkb2VzIG5vdCBoYXZlIGNyZWF0ZSBhIHBhbmVsIHVudGlsIHRoZVxuICAgICAgIyBhbmltYXRpb24gaXMgY29tcGxldGUuIFdlIG5lZWQgdG8gd2FpdCBmb3IgaXQgdG8gZmluaXNoIGJlZm9yZSB3ZSBjYW5cbiAgICAgICMgYmx1ciBpdCB0byByZXR1cm4gZm9jdXNcbiAgICAgIHNldFRpbWVvdXQgLT5cbiAgICAgICAgZWRpdG9yLnNldEN1cnNvckJ1ZmZlclBvc2l0aW9uKGN1cnNvclBvcywge2F1dG9zY3JvbGw6IHRydWV9KVxuICAgICAgICBwYW5lbHMgPSBhdG9tLndvcmtzcGFjZS5nZXRCb3R0b21QYW5lbHMoKTtcbiAgICAgICAgZm9yIHBhbmVsIGluIHBhbmVsc1xuICAgICAgICAgIGlmIHBhbmVsLmdldEl0ZW0oKS5oYXNDbGFzcz8oJ3BsYXRmb3JtaW8taWRlLXRlcm1pbmFsJylcbiAgICAgICAgICAgIHBhbmVsLmdldEl0ZW0oKS5ibHVyKClcblxuICAgICAgICBlZGl0b3IuZ2V0RWxlbWVudCgpLmZvY3VzKClcbiAgICAgICwgNzAwXG5cblxuICAgIGNvbW1hbmQ6ID0+XG4gICAgICBmcmFtZXdvcmsgPSBAc291cmNlSW5mby50ZXN0RnJhbWV3b3JrKClcbiAgICAgIGNtZCA9IENvbW1hbmQudGVzdENvbW1hbmQoQHBhcmFtcy50ZXN0U2NvcGUsIGZyYW1ld29yaylcbiAgICAgIGNtZC5yZXBsYWNlKCd7cmVsYXRpdmVfcGF0aH0nLCBAc291cmNlSW5mby5hY3RpdmVGaWxlKCkpLlxuICAgICAgICAgIHJlcGxhY2UoJ3tsaW5lX251bWJlcn0nLCBAc291cmNlSW5mby5jdXJyZW50TGluZSgpKS5cbiAgICAgICAgICByZXBsYWNlKCd7cmVnZXh9JywgQHNvdXJjZUluZm8ubWluaXRlc3RSZWdFeHAoKSlcbiJdfQ==
