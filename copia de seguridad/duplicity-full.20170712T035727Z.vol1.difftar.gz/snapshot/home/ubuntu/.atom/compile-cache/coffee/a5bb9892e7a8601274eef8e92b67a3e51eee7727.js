(function() {
  var $$, RubyTestView, TestRunner;

  $$ = require('atom-space-pen-views').$$;

  RubyTestView = require('../lib/ruby-test-view');

  TestRunner = require('../lib/test-runner');

  describe("RubyTestView", function() {
    var activeEditor, fileOpened, setUpActiveEditor, spyOnTestRunnerInitialize, spyOnTestRunnerRun, terminalMock, testRunnerInitializeParams, validateTestRunnerInitialize, validateTestRunnerRun, view;
    activeEditor = null;
    testRunnerInitializeParams = null;
    view = null;
    fileOpened = false;
    terminalMock = null;
    beforeEach(function() {
      var mockGetTerminalViews;
      mockGetTerminalViews = [
        {
          terminal: {
            closeBtn: {
              click: function() {}
            }
          }
        }
      ];
      this.terminalMock = {
        run: function(commands) {},
        getTerminalViews: (function(_this) {
          return function() {
            return mockGetTerminalViews;
          };
        })(this)
      };
      return view = new RubyTestView({}, this.terminalMock);
    });
    spyOnTestRunnerInitialize = function() {
      spyOn(activeEditor, 'save');
      spyOn(TestRunner.prototype, 'initialize').andCallFake(function(params) {
        return testRunnerInitializeParams = params;
      });
      return spyOn(TestRunner.prototype, 'run').andReturn(null);
    };
    validateTestRunnerInitialize = function() {
      expect(testRunnerInitializeParams).toBeDefined();
      expect(testRunnerInitializeParams).not.toBe(null);
      return expect(testRunnerInitializeParams.write).toEqual(view.write);
    };
    spyOnTestRunnerRun = function() {
      if (activeEditor != null) {
        spyOn(activeEditor, 'save');
      }
      spyOn(TestRunner.prototype, 'initialize').andCallThrough();
      spyOn(TestRunner.prototype, 'run').andCallThrough();
      return spyOn(TestRunner.prototype, 'command').andReturn('fooTestCommand');
    };
    validateTestRunnerRun = function() {
      expect(TestRunner.prototype.initialize).toHaveBeenCalled();
      expect(TestRunner.prototype.run).toHaveBeenCalledWith();
      return expect(activeEditor.save).toHaveBeenCalled();
    };
    setUpActiveEditor = function() {
      atom.workspace.open('/tmp/text.txt').then(function(editor) {
        activeEditor = editor;
        return fileOpened = true;
      });
      return waitsFor(function() {
        return fileOpened === true;
      });
    };
    describe("with open editor", function() {
      beforeEach(function() {
        fileOpened = false;
        testRunnerInitializeParams = null;
        activeEditor = null;
        return setUpActiveEditor();
      });
      describe("::testAll", function() {
        it("instantiates TestRunner with specific arguments", function() {
          spyOnTestRunnerInitialize();
          view.testAll();
          validateTestRunnerInitialize();
          return expect(testRunnerInitializeParams.testScope).toEqual('all');
        });
        return it("instantiates TestRunner and calls ::run on it", function() {
          spyOnTestRunnerRun();
          view.testAll();
          return validateTestRunnerRun();
        });
      });
      describe("::testFile", function() {
        it("instantiates TestRunner with specific arguments", function() {
          spyOnTestRunnerInitialize();
          view.testFile();
          validateTestRunnerInitialize();
          return expect(testRunnerInitializeParams.testScope).toEqual('file');
        });
        return it("calls ::run on the TestRunner instance", function() {
          spyOnTestRunnerRun();
          view.testFile();
          return validateTestRunnerRun();
        });
      });
      describe("::testSingle", function() {
        it("instantiates TestRunner with specific arguments", function() {
          spyOnTestRunnerInitialize();
          view.testSingle();
          validateTestRunnerInitialize();
          return expect(testRunnerInitializeParams.testScope).toEqual('single');
        });
        return it("instantiates TestRunner and calls ::run on it", function() {
          spyOnTestRunnerRun();
          view.testSingle();
          return validateTestRunnerRun();
        });
      });
      return describe("::testPrevious", function() {
        return it("intantiates TestRunner and calls ::run on it with specific arguments", function() {
          var previousRunner;
          spyOn(activeEditor, 'save');
          previousRunner = new TestRunner({
            scope: 'file'
          }, this.terminalMock);
          previousRunner.command = function() {
            return "foo";
          };
          view.runner = previousRunner;
          view.testPrevious();
          expect(view.runner).toBe(previousRunner);
          return expect(activeEditor.save).toHaveBeenCalled();
        });
      });
    });
    return describe("without open editor", function() {
      beforeEach(function() {
        fileOpened = false;
        return testRunnerInitializeParams = null;
      });
      return describe("::testAll", function() {
        return it("instantiates TestRunner and calls ::run on it", function() {
          spyOnTestRunnerRun();
          view.testAll();
          expect(TestRunner.prototype.initialize).toHaveBeenCalled();
          return expect(TestRunner.prototype.run).toHaveBeenCalledWith();
        });
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9zcGVjL3J1YnktdGVzdC12aWV3LXNwZWMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQyxLQUFNLE9BQUEsQ0FBUSxzQkFBUjs7RUFDUCxZQUFBLEdBQWUsT0FBQSxDQUFRLHVCQUFSOztFQUNmLFVBQUEsR0FBYSxPQUFBLENBQVEsb0JBQVI7O0VBRWIsUUFBQSxDQUFTLGNBQVQsRUFBeUIsU0FBQTtBQUN2QixRQUFBO0lBQUEsWUFBQSxHQUFlO0lBQ2YsMEJBQUEsR0FBNkI7SUFDN0IsSUFBQSxHQUFPO0lBQ1AsVUFBQSxHQUFhO0lBQ2IsWUFBQSxHQUFlO0lBRWYsVUFBQSxDQUFXLFNBQUE7QUFDVCxVQUFBO01BQUEsb0JBQUEsR0FBdUI7UUFBRTtVQUFFLFFBQUEsRUFBVTtZQUFBLFFBQUEsRUFBVTtjQUFFLEtBQUEsRUFBTyxTQUFBLEdBQUEsQ0FBVDthQUFWO1dBQVo7U0FBRjs7TUFDdkIsSUFBQyxDQUFBLFlBQUQsR0FBZ0I7UUFDZCxHQUFBLEVBQUssU0FBQyxRQUFELEdBQUEsQ0FEUztRQUVkLGdCQUFBLEVBQWtCLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUE7bUJBQ2hCO1VBRGdCO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUZKOzthQUtoQixJQUFBLEdBQVcsSUFBQSxZQUFBLENBQWEsRUFBYixFQUFpQixJQUFDLENBQUEsWUFBbEI7SUFQRixDQUFYO0lBU0EseUJBQUEsR0FBNEIsU0FBQTtNQUMxQixLQUFBLENBQU0sWUFBTixFQUFvQixNQUFwQjtNQUNBLEtBQUEsQ0FBTSxVQUFVLENBQUMsU0FBakIsRUFBNEIsWUFBNUIsQ0FBeUMsQ0FBQyxXQUExQyxDQUFzRCxTQUFDLE1BQUQ7ZUFDcEQsMEJBQUEsR0FBNkI7TUFEdUIsQ0FBdEQ7YUFFQSxLQUFBLENBQU0sVUFBVSxDQUFDLFNBQWpCLEVBQTRCLEtBQTVCLENBQWtDLENBQUMsU0FBbkMsQ0FBNkMsSUFBN0M7SUFKMEI7SUFNNUIsNEJBQUEsR0FBK0IsU0FBQTtNQUM3QixNQUFBLENBQU8sMEJBQVAsQ0FBa0MsQ0FBQyxXQUFuQyxDQUFBO01BQ0EsTUFBQSxDQUFPLDBCQUFQLENBQWtDLENBQUMsR0FBRyxDQUFDLElBQXZDLENBQTRDLElBQTVDO2FBQ0EsTUFBQSxDQUFPLDBCQUEwQixDQUFDLEtBQWxDLENBQXdDLENBQUMsT0FBekMsQ0FBaUQsSUFBSSxDQUFDLEtBQXREO0lBSDZCO0lBSy9CLGtCQUFBLEdBQXFCLFNBQUE7TUFDbkIsSUFBRyxvQkFBSDtRQUNFLEtBQUEsQ0FBTSxZQUFOLEVBQW9CLE1BQXBCLEVBREY7O01BRUEsS0FBQSxDQUFNLFVBQVUsQ0FBQyxTQUFqQixFQUE0QixZQUE1QixDQUF5QyxDQUFDLGNBQTFDLENBQUE7TUFDQSxLQUFBLENBQU0sVUFBVSxDQUFDLFNBQWpCLEVBQTRCLEtBQTVCLENBQWtDLENBQUMsY0FBbkMsQ0FBQTthQUNBLEtBQUEsQ0FBTSxVQUFVLENBQUMsU0FBakIsRUFBNEIsU0FBNUIsQ0FBc0MsQ0FBQyxTQUF2QyxDQUFpRCxnQkFBakQ7SUFMbUI7SUFPckIscUJBQUEsR0FBd0IsU0FBQTtNQUN0QixNQUFBLENBQU8sVUFBVSxDQUFDLFNBQVMsQ0FBQyxVQUE1QixDQUF1QyxDQUFDLGdCQUF4QyxDQUFBO01BQ0EsTUFBQSxDQUFPLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBNUIsQ0FBZ0MsQ0FBQyxvQkFBakMsQ0FBQTthQUNBLE1BQUEsQ0FBTyxZQUFZLENBQUMsSUFBcEIsQ0FBeUIsQ0FBQyxnQkFBMUIsQ0FBQTtJQUhzQjtJQUt4QixpQkFBQSxHQUFvQixTQUFBO01BQ2xCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBZixDQUFvQixlQUFwQixDQUFvQyxDQUFDLElBQXJDLENBQTBDLFNBQUMsTUFBRDtRQUN4QyxZQUFBLEdBQWU7ZUFDZixVQUFBLEdBQWE7TUFGMkIsQ0FBMUM7YUFHQSxRQUFBLENBQVMsU0FBQTtlQUFHLFVBQUEsS0FBYztNQUFqQixDQUFUO0lBSmtCO0lBTXBCLFFBQUEsQ0FBUyxrQkFBVCxFQUE2QixTQUFBO01BQzNCLFVBQUEsQ0FBVyxTQUFBO1FBQ1QsVUFBQSxHQUFhO1FBQ2IsMEJBQUEsR0FBNkI7UUFDN0IsWUFBQSxHQUFlO2VBQ2YsaUJBQUEsQ0FBQTtNQUpTLENBQVg7TUFNQSxRQUFBLENBQVMsV0FBVCxFQUFzQixTQUFBO1FBQ3BCLEVBQUEsQ0FBRyxpREFBSCxFQUFzRCxTQUFBO1VBQ3BELHlCQUFBLENBQUE7VUFFQSxJQUFJLENBQUMsT0FBTCxDQUFBO1VBRUEsNEJBQUEsQ0FBQTtpQkFDQSxNQUFBLENBQU8sMEJBQTBCLENBQUMsU0FBbEMsQ0FBNEMsQ0FBQyxPQUE3QyxDQUFxRCxLQUFyRDtRQU5vRCxDQUF0RDtlQVFBLEVBQUEsQ0FBRywrQ0FBSCxFQUFvRCxTQUFBO1VBQ2xELGtCQUFBLENBQUE7VUFFQSxJQUFJLENBQUMsT0FBTCxDQUFBO2lCQUVBLHFCQUFBLENBQUE7UUFMa0QsQ0FBcEQ7TUFUb0IsQ0FBdEI7TUFnQkEsUUFBQSxDQUFTLFlBQVQsRUFBdUIsU0FBQTtRQUNyQixFQUFBLENBQUcsaURBQUgsRUFBc0QsU0FBQTtVQUNwRCx5QkFBQSxDQUFBO1VBRUEsSUFBSSxDQUFDLFFBQUwsQ0FBQTtVQUVBLDRCQUFBLENBQUE7aUJBQ0EsTUFBQSxDQUFPLDBCQUEwQixDQUFDLFNBQWxDLENBQTRDLENBQUMsT0FBN0MsQ0FBcUQsTUFBckQ7UUFOb0QsQ0FBdEQ7ZUFRQSxFQUFBLENBQUcsd0NBQUgsRUFBNkMsU0FBQTtVQUMzQyxrQkFBQSxDQUFBO1VBQ0EsSUFBSSxDQUFDLFFBQUwsQ0FBQTtpQkFFQSxxQkFBQSxDQUFBO1FBSjJDLENBQTdDO01BVHFCLENBQXZCO01BZUEsUUFBQSxDQUFTLGNBQVQsRUFBeUIsU0FBQTtRQUN2QixFQUFBLENBQUcsaURBQUgsRUFBc0QsU0FBQTtVQUNwRCx5QkFBQSxDQUFBO1VBRUEsSUFBSSxDQUFDLFVBQUwsQ0FBQTtVQUVBLDRCQUFBLENBQUE7aUJBQ0EsTUFBQSxDQUFPLDBCQUEwQixDQUFDLFNBQWxDLENBQTRDLENBQUMsT0FBN0MsQ0FBcUQsUUFBckQ7UUFOb0QsQ0FBdEQ7ZUFRQSxFQUFBLENBQUcsK0NBQUgsRUFBb0QsU0FBQTtVQUNsRCxrQkFBQSxDQUFBO1VBRUEsSUFBSSxDQUFDLFVBQUwsQ0FBQTtpQkFFQSxxQkFBQSxDQUFBO1FBTGtELENBQXBEO01BVHVCLENBQXpCO2FBZ0JBLFFBQUEsQ0FBUyxnQkFBVCxFQUEyQixTQUFBO2VBQ3pCLEVBQUEsQ0FBRyxzRUFBSCxFQUEyRSxTQUFBO0FBQ3pFLGNBQUE7VUFBQSxLQUFBLENBQU0sWUFBTixFQUFvQixNQUFwQjtVQUVBLGNBQUEsR0FBcUIsSUFBQSxVQUFBLENBQVc7WUFBRSxLQUFBLEVBQU8sTUFBVDtXQUFYLEVBQThCLElBQUMsQ0FBQSxZQUEvQjtVQUNyQixjQUFjLENBQUMsT0FBZixHQUF5QixTQUFBO21CQUFHO1VBQUg7VUFDekIsSUFBSSxDQUFDLE1BQUwsR0FBYztVQUNkLElBQUksQ0FBQyxZQUFMLENBQUE7VUFFQSxNQUFBLENBQU8sSUFBSSxDQUFDLE1BQVosQ0FBbUIsQ0FBQyxJQUFwQixDQUF5QixjQUF6QjtpQkFDQSxNQUFBLENBQU8sWUFBWSxDQUFDLElBQXBCLENBQXlCLENBQUMsZ0JBQTFCLENBQUE7UUFUeUUsQ0FBM0U7TUFEeUIsQ0FBM0I7SUF0RDJCLENBQTdCO1dBa0VBLFFBQUEsQ0FBUyxxQkFBVCxFQUFnQyxTQUFBO01BQzlCLFVBQUEsQ0FBVyxTQUFBO1FBQ1QsVUFBQSxHQUFhO2VBQ2IsMEJBQUEsR0FBNkI7TUFGcEIsQ0FBWDthQU1BLFFBQUEsQ0FBUyxXQUFULEVBQXNCLFNBQUE7ZUFDcEIsRUFBQSxDQUFHLCtDQUFILEVBQW9ELFNBQUE7VUFDbEQsa0JBQUEsQ0FBQTtVQUVBLElBQUksQ0FBQyxPQUFMLENBQUE7VUFFQSxNQUFBLENBQU8sVUFBVSxDQUFDLFNBQVMsQ0FBQyxVQUE1QixDQUF1QyxDQUFDLGdCQUF4QyxDQUFBO2lCQUNBLE1BQUEsQ0FBTyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQTVCLENBQWdDLENBQUMsb0JBQWpDLENBQUE7UUFOa0QsQ0FBcEQ7TUFEb0IsQ0FBdEI7SUFQOEIsQ0FBaEM7RUEvR3VCLENBQXpCO0FBSkEiLCJzb3VyY2VzQ29udGVudCI6WyJ7JCR9ID0gcmVxdWlyZSAnYXRvbS1zcGFjZS1wZW4tdmlld3MnXG5SdWJ5VGVzdFZpZXcgPSByZXF1aXJlICcuLi9saWIvcnVieS10ZXN0LXZpZXcnXG5UZXN0UnVubmVyID0gcmVxdWlyZSAnLi4vbGliL3Rlc3QtcnVubmVyJ1xuXG5kZXNjcmliZSBcIlJ1YnlUZXN0Vmlld1wiLCAtPlxuICBhY3RpdmVFZGl0b3IgPSBudWxsXG4gIHRlc3RSdW5uZXJJbml0aWFsaXplUGFyYW1zID0gbnVsbFxuICB2aWV3ID0gbnVsbFxuICBmaWxlT3BlbmVkID0gZmFsc2VcbiAgdGVybWluYWxNb2NrID0gbnVsbFxuXG4gIGJlZm9yZUVhY2ggLT5cbiAgICBtb2NrR2V0VGVybWluYWxWaWV3cyA9IFsgeyB0ZXJtaW5hbDogY2xvc2VCdG46IHsgY2xpY2s6IC0+IH0gfSBdXG4gICAgQHRlcm1pbmFsTW9jayA9IHtcbiAgICAgIHJ1bjogKGNvbW1hbmRzKSAtPlxuICAgICAgZ2V0VGVybWluYWxWaWV3czogKCkgPT5cbiAgICAgICAgbW9ja0dldFRlcm1pbmFsVmlld3NcbiAgICB9XG4gICAgdmlldyA9IG5ldyBSdWJ5VGVzdFZpZXcoe30sIEB0ZXJtaW5hbE1vY2spXG5cbiAgc3B5T25UZXN0UnVubmVySW5pdGlhbGl6ZSA9IC0+XG4gICAgc3B5T24oYWN0aXZlRWRpdG9yLCAnc2F2ZScpXG4gICAgc3B5T24oVGVzdFJ1bm5lci5wcm90b3R5cGUsICdpbml0aWFsaXplJykuYW5kQ2FsbEZha2UgKHBhcmFtcykgLT5cbiAgICAgIHRlc3RSdW5uZXJJbml0aWFsaXplUGFyYW1zID0gcGFyYW1zXG4gICAgc3B5T24oVGVzdFJ1bm5lci5wcm90b3R5cGUsICdydW4nKS5hbmRSZXR1cm4obnVsbClcblxuICB2YWxpZGF0ZVRlc3RSdW5uZXJJbml0aWFsaXplID0gLT5cbiAgICBleHBlY3QodGVzdFJ1bm5lckluaXRpYWxpemVQYXJhbXMpLnRvQmVEZWZpbmVkKClcbiAgICBleHBlY3QodGVzdFJ1bm5lckluaXRpYWxpemVQYXJhbXMpLm5vdC50b0JlKG51bGwpXG4gICAgZXhwZWN0KHRlc3RSdW5uZXJJbml0aWFsaXplUGFyYW1zLndyaXRlKS50b0VxdWFsKHZpZXcud3JpdGUpXG5cbiAgc3B5T25UZXN0UnVubmVyUnVuID0gLT5cbiAgICBpZiBhY3RpdmVFZGl0b3I/XG4gICAgICBzcHlPbihhY3RpdmVFZGl0b3IsICdzYXZlJylcbiAgICBzcHlPbihUZXN0UnVubmVyLnByb3RvdHlwZSwgJ2luaXRpYWxpemUnKS5hbmRDYWxsVGhyb3VnaCgpXG4gICAgc3B5T24oVGVzdFJ1bm5lci5wcm90b3R5cGUsICdydW4nKS5hbmRDYWxsVGhyb3VnaCgpXG4gICAgc3B5T24oVGVzdFJ1bm5lci5wcm90b3R5cGUsICdjb21tYW5kJykuYW5kUmV0dXJuICdmb29UZXN0Q29tbWFuZCdcblxuICB2YWxpZGF0ZVRlc3RSdW5uZXJSdW4gPSAtPlxuICAgIGV4cGVjdChUZXN0UnVubmVyLnByb3RvdHlwZS5pbml0aWFsaXplKS50b0hhdmVCZWVuQ2FsbGVkKClcbiAgICBleHBlY3QoVGVzdFJ1bm5lci5wcm90b3R5cGUucnVuKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCgpXG4gICAgZXhwZWN0KGFjdGl2ZUVkaXRvci5zYXZlKS50b0hhdmVCZWVuQ2FsbGVkKClcblxuICBzZXRVcEFjdGl2ZUVkaXRvciA9IC0+XG4gICAgYXRvbS53b3Jrc3BhY2Uub3BlbignL3RtcC90ZXh0LnR4dCcpLnRoZW4gKGVkaXRvcikgLT5cbiAgICAgIGFjdGl2ZUVkaXRvciA9IGVkaXRvclxuICAgICAgZmlsZU9wZW5lZCA9IHRydWVcbiAgICB3YWl0c0ZvciAtPiBmaWxlT3BlbmVkIGlzIHRydWVcblxuICBkZXNjcmliZSBcIndpdGggb3BlbiBlZGl0b3JcIiwgLT5cbiAgICBiZWZvcmVFYWNoIC0+XG4gICAgICBmaWxlT3BlbmVkID0gZmFsc2VcbiAgICAgIHRlc3RSdW5uZXJJbml0aWFsaXplUGFyYW1zID0gbnVsbFxuICAgICAgYWN0aXZlRWRpdG9yID0gbnVsbFxuICAgICAgc2V0VXBBY3RpdmVFZGl0b3IoKVxuXG4gICAgZGVzY3JpYmUgXCI6OnRlc3RBbGxcIiwgLT5cbiAgICAgIGl0IFwiaW5zdGFudGlhdGVzIFRlc3RSdW5uZXIgd2l0aCBzcGVjaWZpYyBhcmd1bWVudHNcIiwgLT5cbiAgICAgICAgc3B5T25UZXN0UnVubmVySW5pdGlhbGl6ZSgpXG5cbiAgICAgICAgdmlldy50ZXN0QWxsKClcblxuICAgICAgICB2YWxpZGF0ZVRlc3RSdW5uZXJJbml0aWFsaXplKClcbiAgICAgICAgZXhwZWN0KHRlc3RSdW5uZXJJbml0aWFsaXplUGFyYW1zLnRlc3RTY29wZSkudG9FcXVhbCgnYWxsJylcblxuICAgICAgaXQgXCJpbnN0YW50aWF0ZXMgVGVzdFJ1bm5lciBhbmQgY2FsbHMgOjpydW4gb24gaXRcIiwgLT5cbiAgICAgICAgc3B5T25UZXN0UnVubmVyUnVuKClcblxuICAgICAgICB2aWV3LnRlc3RBbGwoKVxuXG4gICAgICAgIHZhbGlkYXRlVGVzdFJ1bm5lclJ1bigpXG5cbiAgICBkZXNjcmliZSBcIjo6dGVzdEZpbGVcIiwgLT5cbiAgICAgIGl0IFwiaW5zdGFudGlhdGVzIFRlc3RSdW5uZXIgd2l0aCBzcGVjaWZpYyBhcmd1bWVudHNcIiwgLT5cbiAgICAgICAgc3B5T25UZXN0UnVubmVySW5pdGlhbGl6ZSgpXG5cbiAgICAgICAgdmlldy50ZXN0RmlsZSgpXG5cbiAgICAgICAgdmFsaWRhdGVUZXN0UnVubmVySW5pdGlhbGl6ZSgpXG4gICAgICAgIGV4cGVjdCh0ZXN0UnVubmVySW5pdGlhbGl6ZVBhcmFtcy50ZXN0U2NvcGUpLnRvRXF1YWwoJ2ZpbGUnKVxuXG4gICAgICBpdCBcImNhbGxzIDo6cnVuIG9uIHRoZSBUZXN0UnVubmVyIGluc3RhbmNlXCIsIC0+XG4gICAgICAgIHNweU9uVGVzdFJ1bm5lclJ1bigpXG4gICAgICAgIHZpZXcudGVzdEZpbGUoKVxuXG4gICAgICAgIHZhbGlkYXRlVGVzdFJ1bm5lclJ1bigpXG5cbiAgICBkZXNjcmliZSBcIjo6dGVzdFNpbmdsZVwiLCAtPlxuICAgICAgaXQgXCJpbnN0YW50aWF0ZXMgVGVzdFJ1bm5lciB3aXRoIHNwZWNpZmljIGFyZ3VtZW50c1wiLCAtPlxuICAgICAgICBzcHlPblRlc3RSdW5uZXJJbml0aWFsaXplKClcblxuICAgICAgICB2aWV3LnRlc3RTaW5nbGUoKVxuXG4gICAgICAgIHZhbGlkYXRlVGVzdFJ1bm5lckluaXRpYWxpemUoKVxuICAgICAgICBleHBlY3QodGVzdFJ1bm5lckluaXRpYWxpemVQYXJhbXMudGVzdFNjb3BlKS50b0VxdWFsKCdzaW5nbGUnKVxuXG4gICAgICBpdCBcImluc3RhbnRpYXRlcyBUZXN0UnVubmVyIGFuZCBjYWxscyA6OnJ1biBvbiBpdFwiLCAtPlxuICAgICAgICBzcHlPblRlc3RSdW5uZXJSdW4oKVxuXG4gICAgICAgIHZpZXcudGVzdFNpbmdsZSgpXG5cbiAgICAgICAgdmFsaWRhdGVUZXN0UnVubmVyUnVuKClcblxuICAgIGRlc2NyaWJlIFwiOjp0ZXN0UHJldmlvdXNcIiwgLT5cbiAgICAgIGl0IFwiaW50YW50aWF0ZXMgVGVzdFJ1bm5lciBhbmQgY2FsbHMgOjpydW4gb24gaXQgd2l0aCBzcGVjaWZpYyBhcmd1bWVudHNcIiwgLT5cbiAgICAgICAgc3B5T24oYWN0aXZlRWRpdG9yLCAnc2F2ZScpXG5cbiAgICAgICAgcHJldmlvdXNSdW5uZXIgPSBuZXcgVGVzdFJ1bm5lcih7IHNjb3BlOiAnZmlsZScgfSwgQHRlcm1pbmFsTW9jaylcbiAgICAgICAgcHJldmlvdXNSdW5uZXIuY29tbWFuZCA9IC0+IFwiZm9vXCJcbiAgICAgICAgdmlldy5ydW5uZXIgPSBwcmV2aW91c1J1bm5lclxuICAgICAgICB2aWV3LnRlc3RQcmV2aW91cygpXG5cbiAgICAgICAgZXhwZWN0KHZpZXcucnVubmVyKS50b0JlKHByZXZpb3VzUnVubmVyKVxuICAgICAgICBleHBlY3QoYWN0aXZlRWRpdG9yLnNhdmUpLnRvSGF2ZUJlZW5DYWxsZWQoKVxuXG4gIGRlc2NyaWJlIFwid2l0aG91dCBvcGVuIGVkaXRvclwiLCAtPlxuICAgIGJlZm9yZUVhY2ggLT5cbiAgICAgIGZpbGVPcGVuZWQgPSBmYWxzZVxuICAgICAgdGVzdFJ1bm5lckluaXRpYWxpemVQYXJhbXMgPSBudWxsXG5cbiAgICAjIFJlcHJvZHVjZSBodHRwczovL2dpdGh1Yi5jb20vbW94bGV5L2F0b20tcnVieS10ZXN0L2lzc3Vlcy8zMzpcbiAgICAjIFwiVW5jYXVnaHQgVHlwZUVycm9yOiBDYW5ub3QgcmVhZCBwcm9wZXJ0eSAnc2F2ZScgb2YgdW5kZWZpbmVkXCJcbiAgICBkZXNjcmliZSBcIjo6dGVzdEFsbFwiLCAtPlxuICAgICAgaXQgXCJpbnN0YW50aWF0ZXMgVGVzdFJ1bm5lciBhbmQgY2FsbHMgOjpydW4gb24gaXRcIiwgLT5cbiAgICAgICAgc3B5T25UZXN0UnVubmVyUnVuKClcblxuICAgICAgICB2aWV3LnRlc3RBbGwoKVxuXG4gICAgICAgIGV4cGVjdChUZXN0UnVubmVyLnByb3RvdHlwZS5pbml0aWFsaXplKS50b0hhdmVCZWVuQ2FsbGVkKClcbiAgICAgICAgZXhwZWN0KFRlc3RSdW5uZXIucHJvdG90eXBlLnJ1bikudG9IYXZlQmVlbkNhbGxlZFdpdGgoKVxuIl19
