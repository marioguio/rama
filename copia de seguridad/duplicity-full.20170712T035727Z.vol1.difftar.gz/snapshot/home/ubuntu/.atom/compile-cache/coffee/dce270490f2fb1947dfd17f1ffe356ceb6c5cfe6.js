(function() {
  var Command;

  module.exports = Command = (function() {
    function Command() {}

    Command.testCommand = function(scope, testFramework) {
      if (scope === "single") {
        return this.testSingleCommand(testFramework);
      } else if (scope === "file") {
        return this.testFileCommand(testFramework);
      } else if (scope === "all") {
        return this.testAllCommand(testFramework);
      } else {
        throw "Unknown scope: " + scope;
      }
    };

    Command.testFileCommand = function(testFramework) {
      return atom.config.get("ruby-test." + testFramework + "FileCommand");
    };

    Command.testAllCommand = function(testFramework) {
      return atom.config.get("ruby-test." + testFramework + "AllCommand");
    };

    Command.testSingleCommand = function(testFramework) {
      return atom.config.get("ruby-test." + testFramework + "SingleCommand");
    };

    return Command;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9saWIvY29tbWFuZC5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBRVE7OztJQUNKLE9BQUMsQ0FBQSxXQUFELEdBQWMsU0FBQyxLQUFELEVBQVEsYUFBUjtNQUNaLElBQUcsS0FBQSxLQUFTLFFBQVo7ZUFDRSxJQUFDLENBQUEsaUJBQUQsQ0FBbUIsYUFBbkIsRUFERjtPQUFBLE1BRUssSUFBRyxLQUFBLEtBQVMsTUFBWjtlQUNILElBQUMsQ0FBQSxlQUFELENBQWlCLGFBQWpCLEVBREc7T0FBQSxNQUVBLElBQUcsS0FBQSxLQUFTLEtBQVo7ZUFDSCxJQUFDLENBQUEsY0FBRCxDQUFnQixhQUFoQixFQURHO09BQUEsTUFBQTtBQUdILGNBQU0saUJBQUEsR0FBa0IsTUFIckI7O0lBTE87O0lBVWQsT0FBQyxDQUFBLGVBQUQsR0FBa0IsU0FBQyxhQUFEO2FBQ2hCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixZQUFBLEdBQWEsYUFBYixHQUEyQixhQUEzQztJQURnQjs7SUFHbEIsT0FBQyxDQUFBLGNBQUQsR0FBaUIsU0FBQyxhQUFEO2FBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLFlBQUEsR0FBYSxhQUFiLEdBQTJCLFlBQTNDO0lBRGU7O0lBR2pCLE9BQUMsQ0FBQSxpQkFBRCxHQUFvQixTQUFDLGFBQUQ7YUFDbEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLFlBQUEsR0FBYSxhQUFiLEdBQTJCLGVBQTNDO0lBRGtCOzs7OztBQW5CeEIiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9XG4gICMgQ2FsY3VsYXRlcyB0ZXN0IGNvbW1hbmQsIGJhc2VkIG9uIHRlc3QgZnJhbWV3b3JrIGFuZCB0ZXN0IHNjb3BlXG4gIGNsYXNzIENvbW1hbmRcbiAgICBAdGVzdENvbW1hbmQ6IChzY29wZSwgdGVzdEZyYW1ld29yaykgLT5cbiAgICAgIGlmIHNjb3BlID09IFwic2luZ2xlXCJcbiAgICAgICAgQHRlc3RTaW5nbGVDb21tYW5kKHRlc3RGcmFtZXdvcmspXG4gICAgICBlbHNlIGlmIHNjb3BlID09IFwiZmlsZVwiXG4gICAgICAgIEB0ZXN0RmlsZUNvbW1hbmQodGVzdEZyYW1ld29yaylcbiAgICAgIGVsc2UgaWYgc2NvcGUgPT0gXCJhbGxcIlxuICAgICAgICBAdGVzdEFsbENvbW1hbmQodGVzdEZyYW1ld29yaylcbiAgICAgIGVsc2VcbiAgICAgICAgdGhyb3cgXCJVbmtub3duIHNjb3BlOiAje3Njb3BlfVwiXG5cbiAgICBAdGVzdEZpbGVDb21tYW5kOiAodGVzdEZyYW1ld29yaykgLT5cbiAgICAgIGF0b20uY29uZmlnLmdldChcInJ1YnktdGVzdC4je3Rlc3RGcmFtZXdvcmt9RmlsZUNvbW1hbmRcIilcblxuICAgIEB0ZXN0QWxsQ29tbWFuZDogKHRlc3RGcmFtZXdvcmspIC0+XG4gICAgICBhdG9tLmNvbmZpZy5nZXQoXCJydWJ5LXRlc3QuI3t0ZXN0RnJhbWV3b3JrfUFsbENvbW1hbmRcIilcblxuICAgIEB0ZXN0U2luZ2xlQ29tbWFuZDogKHRlc3RGcmFtZXdvcmspIC0+XG4gICAgICBhdG9tLmNvbmZpZy5nZXQoXCJydWJ5LXRlc3QuI3t0ZXN0RnJhbWV3b3JrfVNpbmdsZUNvbW1hbmRcIilcbiJdfQ==
