(function() {
  var Utility;

  Utility = require('../lib/utility');

  describe("Utility", function() {
    return describe("::saveFile", function() {
      var makeEditor;
      makeEditor = function(opts) {
        var editor;
        editor = {
          save: null,
          buffer: {
            file: {
              path: opts.path
            }
          }
        };
        spyOn(editor, 'save');
        spyOn(atom.workspace, 'getActiveTextEditor').andReturn(editor);
        return editor;
      };
      it("calls save() on the active editor file", function() {
        var editor, util;
        editor = makeEditor({
          path: 'foo/bar.rb'
        });
        util = new Utility;
        util.saveFile();
        return expect(editor.save).toHaveBeenCalled();
      });
      return it("does not call save() when there is no file path", function() {
        var editor, util;
        editor = makeEditor({
          path: null
        });
        util = new Utility;
        util.saveFile();
        return expect(editor.save).not.toHaveBeenCalled();
      });
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9zcGVjL3V0aWxpdHktc3BlYy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLE9BQUEsR0FBVSxPQUFBLENBQVEsZ0JBQVI7O0VBRVYsUUFBQSxDQUFTLFNBQVQsRUFBb0IsU0FBQTtXQUNsQixRQUFBLENBQVMsWUFBVCxFQUF1QixTQUFBO0FBQ3JCLFVBQUE7TUFBQSxVQUFBLEdBQWEsU0FBQyxJQUFEO0FBQ1gsWUFBQTtRQUFBLE1BQUEsR0FBUztVQUNQLElBQUEsRUFBTSxJQURDO1VBRVAsTUFBQSxFQUFRO1lBQUMsSUFBQSxFQUFNO2NBQUMsSUFBQSxFQUFNLElBQUksQ0FBQyxJQUFaO2FBQVA7V0FGRDs7UUFJVCxLQUFBLENBQU0sTUFBTixFQUFjLE1BQWQ7UUFDQSxLQUFBLENBQU0sSUFBSSxDQUFDLFNBQVgsRUFBc0IscUJBQXRCLENBQTRDLENBQUMsU0FBN0MsQ0FBdUQsTUFBdkQ7ZUFDQTtNQVBXO01BU2IsRUFBQSxDQUFHLHdDQUFILEVBQTZDLFNBQUE7QUFDM0MsWUFBQTtRQUFBLE1BQUEsR0FBUyxVQUFBLENBQVc7VUFBQSxJQUFBLEVBQU0sWUFBTjtTQUFYO1FBRVQsSUFBQSxHQUFPLElBQUk7UUFDWCxJQUFJLENBQUMsUUFBTCxDQUFBO2VBRUEsTUFBQSxDQUFPLE1BQU0sQ0FBQyxJQUFkLENBQW1CLENBQUMsZ0JBQXBCLENBQUE7TUFOMkMsQ0FBN0M7YUFRQSxFQUFBLENBQUcsaURBQUgsRUFBc0QsU0FBQTtBQUNwRCxZQUFBO1FBQUEsTUFBQSxHQUFTLFVBQUEsQ0FBVztVQUFBLElBQUEsRUFBTSxJQUFOO1NBQVg7UUFFVCxJQUFBLEdBQU8sSUFBSTtRQUNYLElBQUksQ0FBQyxRQUFMLENBQUE7ZUFFQSxNQUFBLENBQU8sTUFBTSxDQUFDLElBQWQsQ0FBbUIsQ0FBQyxHQUFHLENBQUMsZ0JBQXhCLENBQUE7TUFOb0QsQ0FBdEQ7SUFsQnFCLENBQXZCO0VBRGtCLENBQXBCO0FBRkEiLCJzb3VyY2VzQ29udGVudCI6WyJVdGlsaXR5ID0gcmVxdWlyZSAnLi4vbGliL3V0aWxpdHknXG5cbmRlc2NyaWJlIFwiVXRpbGl0eVwiLCAtPlxuICBkZXNjcmliZSBcIjo6c2F2ZUZpbGVcIiwgLT5cbiAgICBtYWtlRWRpdG9yID0gKG9wdHMpIC0+XG4gICAgICBlZGl0b3IgPSB7XG4gICAgICAgIHNhdmU6IG51bGxcbiAgICAgICAgYnVmZmVyOiB7ZmlsZToge3BhdGg6IG9wdHMucGF0aH19XG4gICAgICB9XG4gICAgICBzcHlPbihlZGl0b3IsICdzYXZlJylcbiAgICAgIHNweU9uKGF0b20ud29ya3NwYWNlLCAnZ2V0QWN0aXZlVGV4dEVkaXRvcicpLmFuZFJldHVybihlZGl0b3IpXG4gICAgICBlZGl0b3JcblxuICAgIGl0IFwiY2FsbHMgc2F2ZSgpIG9uIHRoZSBhY3RpdmUgZWRpdG9yIGZpbGVcIiwgLT5cbiAgICAgIGVkaXRvciA9IG1ha2VFZGl0b3IocGF0aDogJ2Zvby9iYXIucmInKVxuXG4gICAgICB1dGlsID0gbmV3IFV0aWxpdHlcbiAgICAgIHV0aWwuc2F2ZUZpbGUoKVxuXG4gICAgICBleHBlY3QoZWRpdG9yLnNhdmUpLnRvSGF2ZUJlZW5DYWxsZWQoKVxuXG4gICAgaXQgXCJkb2VzIG5vdCBjYWxsIHNhdmUoKSB3aGVuIHRoZXJlIGlzIG5vIGZpbGUgcGF0aFwiLCAtPlxuICAgICAgZWRpdG9yID0gbWFrZUVkaXRvcihwYXRoOiBudWxsKVxuXG4gICAgICB1dGlsID0gbmV3IFV0aWxpdHlcbiAgICAgIHV0aWwuc2F2ZUZpbGUoKVxuXG4gICAgICBleHBlY3QoZWRpdG9yLnNhdmUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKClcbiJdfQ==
