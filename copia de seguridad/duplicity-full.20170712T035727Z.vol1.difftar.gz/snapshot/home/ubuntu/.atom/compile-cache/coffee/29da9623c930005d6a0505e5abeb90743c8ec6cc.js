(function() {
  var SourceInfo, Utility, fs;

  fs = require('fs');

  Utility = require('./utility');

  module.exports = SourceInfo = (function() {
    function SourceInfo() {}

    SourceInfo.prototype.frameworkLookup = {
      test: 'test',
      spec: 'rspec',
      rspec: 'rspec',
      feature: 'cucumber',
      minitest: 'minitest'
    };

    SourceInfo.prototype.regExpForTestStyle = {
      unit: /def\s(.*?)$/,
      spec: /(?:"|')(.*?)(?:"|')/
    };

    SourceInfo.prototype.projectPath = function() {
      var defaultPath, j, len, path, ref;
      defaultPath = atom.project.getPaths()[0];
      if (this.filePath()) {
        ref = atom.project.getPaths();
        for (j = 0, len = ref.length; j < len; j++) {
          path = ref[j];
          if (this.filePath().indexOf(path) === 0) {
            return path;
          }
        }
        return defaultPath;
      } else {
        return defaultPath;
      }
    };

    SourceInfo.prototype.activeFile = function() {
      var fp;
      return this._activeFile || (this._activeFile = (fp = this.filePath()) && atom.project.relativize(fp));
    };

    SourceInfo.prototype.currentLine = function() {
      var cursor, editor;
      return this._currentLine || (this._currentLine = !this._currentLine ? (editor = atom.workspace.getActiveTextEditor(), cursor = editor && editor.getLastCursor(), cursor ? cursor.getBufferRow() + 1 : null) : void 0);
    };

    SourceInfo.prototype.minitestRegExp = function() {
      var file;
      if (this._minitestRegExp !== void 0) {
        return this._minitestRegExp;
      }
      file = this.fileAnalysis();
      return this._minitestRegExp = this.extractMinitestRegExp(file.testHeaderLine, file.testStyle);
    };

    SourceInfo.prototype.extractMinitestRegExp = function(testHeaderLine, testStyle) {
      var match, regExp;
      regExp = this.regExpForTestStyle[testStyle];
      match = (testHeaderLine != null) && testHeaderLine.match(regExp) || null;
      if (match) {
        return match[1];
      } else {
        return "";
      }
    };

    SourceInfo.prototype.fileFramework = function() {
      if (!this._fileAnalysis) {
        this.fileAnalysis();
      }
      return this._fileAnalysis.framework;
    };

    SourceInfo.prototype.testStyle = function() {
      if (!this._fileAnalysis) {
        this.fileAnalysis();
      }
      return this._fileAnalysis.testStyle;
    };

    SourceInfo.prototype.fileAnalysis = function() {
      var editor, i, minitestClassRegExp, minitestMethodRegExp, res, rspecAssertionRegExp, rspecRequireRegExp, sourceLine, specRegExp;
      if (this._fileAnalysis !== void 0) {
        return this._fileAnalysis;
      }
      this._fileAnalysis = {
        testHeaderLine: null,
        testStyle: null,
        framework: null
      };
      editor = atom.workspace.getActiveTextEditor();
      i = this.currentLine() - 1;
      specRegExp = new RegExp(/\b(?:should|test|it)\s+['"](.*)['"]\s+do\b/);
      rspecRequireRegExp = new RegExp(/^require.*(rails|spec)_helper/);
      rspecAssertionRegExp = new RegExp(/^\s*expect\(/);
      minitestClassRegExp = new RegExp(/class\s(.*)<(\s?|\s+)Minitest::Test/);
      minitestMethodRegExp = new RegExp(/^(\s+)def\s(.*)$/);
      while (i >= 0) {
        sourceLine = editor.lineTextForBufferRow(i);
        if (!this._fileAnalysis.testHeaderLine) {
          if (res = sourceLine.match(specRegExp)) {
            this._minitestRegExp = res[1];
            this._fileAnalysis.testStyle = 'spec';
            this._fileAnalysis.testHeaderLine = sourceLine;
          } else if (minitestMethodRegExp.test(sourceLine)) {
            this._fileAnalysis.testStyle = 'unit';
            this._fileAnalysis.testHeaderLine = sourceLine;
          }
        }
        if (rspecRequireRegExp.test(sourceLine)) {
          this._fileAnalysis.testStyle = 'spec';
          this._fileAnalysis.framework = 'rspec';
          break;
        } else if (rspecAssertionRegExp.test(sourceLine)) {
          this._fileAnalysis.testStyle = 'spec';
          this._fileAnalysis.framework = 'rspec';
          break;
        } else if (this._fileAnalysis.testStyle === 'unit' && minitestClassRegExp.test(sourceLine)) {
          this._fileAnalysis.framework = 'minitest';
          return this._fileAnalysis;
        }
        i--;
      }
      if (this._fileAnalysis.framework !== 'rspec' && this._fileAnalysis.testStyle === 'spec') {
        this._fileAnalysis.framework = 'minitest';
      }
      return this._fileAnalysis;
    };

    SourceInfo.prototype.testFramework = function() {
      var t;
      return this._testFramework || (this._testFramework = !this._testFramework ? ((t = this.fileType()) && this.frameworkLookup[t]) || (fs.existsSync(this.projectPath() + '/.rspec') && 'rspec') || this.projectType() : void 0);
    };

    SourceInfo.prototype.fileType = function() {
      var matches;
      return this._fileType || (this._fileType = this._fileType === void 0 ? !this.activeFile() ? null : (matches = this.activeFile().match(/_(test|spec)\.rb$/)) ? matches[1] === 'test' && atom.config.get("ruby-test.testFramework") ? atom.config.get("ruby-test.testFramework") : matches[1] === 'spec' && atom.config.get("ruby-test.specFramework") ? atom.config.get("ruby-test.specFramework") : this.fileFramework() === 'minitest' || (!this.fileFramework() && matches[1] === 'test' && this.testStyle() === 'spec') ? 'minitest' : matches[1] === 'spec' ? 'rspec' : 'test' : (matches = this.activeFile().match(/\.(feature)$/)) ? matches[1] : void 0 : void 0);
    };

    SourceInfo.prototype.projectType = function() {
      if (fs.existsSync(this.projectPath() + '/test')) {
        return atom.config.get("ruby-test.testFramework") || 'test';
      } else if (fs.existsSync(this.projectPath() + '/spec')) {
        return atom.config.get("ruby-test.specFramework") || 'rspec';
      } else if (fs.existsSync(this.projectPath() + '/features')) {
        return 'cucumber';
      } else {
        return null;
      }
    };

    SourceInfo.prototype.filePath = function() {
      var util;
      util = new Utility;
      return util.filePath();
    };

    return SourceInfo;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiL2hvbWUvdWJ1bnR1Ly5hdG9tL3BhY2thZ2VzL3J1YnktdGVzdC9saWIvc291cmNlLWluZm8uY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQSxFQUFBLEdBQUssT0FBQSxDQUFRLElBQVI7O0VBQ0wsT0FBQSxHQUFVLE9BQUEsQ0FBUSxXQUFSOztFQUVWLE1BQU0sQ0FBQyxPQUFQLEdBRVE7Ozt5QkFDSixlQUFBLEdBQ0U7TUFBQSxJQUFBLEVBQVMsTUFBVDtNQUNBLElBQUEsRUFBUyxPQURUO01BRUEsS0FBQSxFQUFTLE9BRlQ7TUFHQSxPQUFBLEVBQVMsVUFIVDtNQUlBLFFBQUEsRUFBVSxVQUpWOzs7eUJBTUYsa0JBQUEsR0FDRTtNQUFBLElBQUEsRUFBTSxhQUFOO01BQ0EsSUFBQSxFQUFNLHFCQUROOzs7eUJBR0YsV0FBQSxHQUFhLFNBQUE7QUFDWCxVQUFBO01BQUEsV0FBQSxHQUFjLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBYixDQUFBLENBQXdCLENBQUEsQ0FBQTtNQUN0QyxJQUFHLElBQUMsQ0FBQSxRQUFELENBQUEsQ0FBSDtBQUNFO0FBQUEsYUFBQSxxQ0FBQTs7VUFDRSxJQUFHLElBQUMsQ0FBQSxRQUFELENBQUEsQ0FBVyxDQUFDLE9BQVosQ0FBb0IsSUFBcEIsQ0FBQSxLQUE2QixDQUFoQztBQUNFLG1CQUFPLEtBRFQ7O0FBREY7QUFHQSxlQUFPLFlBSlQ7T0FBQSxNQUFBO2VBTUUsWUFORjs7SUFGVzs7eUJBVWIsVUFBQSxHQUFZLFNBQUE7QUFDVixVQUFBO2FBQUEsSUFBQyxDQUFBLGdCQUFELElBQUMsQ0FBQSxjQUFnQixDQUFDLEVBQUEsR0FBSyxJQUFDLENBQUEsUUFBRCxDQUFBLENBQU4sQ0FBQSxJQUF1QixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQWIsQ0FBd0IsRUFBeEI7SUFEOUI7O3lCQUdaLFdBQUEsR0FBYSxTQUFBO0FBQ1gsVUFBQTthQUFBLElBQUMsQ0FBQSxpQkFBRCxJQUFDLENBQUEsZUFBaUIsQ0FBTyxJQUFDLENBQUEsWUFBUixHQUNoQixDQUFBLE1BQUEsR0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFmLENBQUEsQ0FBVCxFQUNBLE1BQUEsR0FBUyxNQUFBLElBQVcsTUFBTSxDQUFDLGFBQVAsQ0FBQSxDQURwQixFQUVHLE1BQUgsR0FDRSxNQUFNLENBQUMsWUFBUCxDQUFBLENBQUEsR0FBd0IsQ0FEMUIsR0FHRSxJQUxGLENBRGdCLEdBQUE7SUFEUDs7eUJBU2IsY0FBQSxHQUFnQixTQUFBO0FBQ2QsVUFBQTtNQUFBLElBQTJCLElBQUMsQ0FBQSxlQUFELEtBQW9CLE1BQS9DO0FBQUEsZUFBTyxJQUFDLENBQUEsZ0JBQVI7O01BQ0EsSUFBQSxHQUFPLElBQUMsQ0FBQSxZQUFELENBQUE7YUFDUCxJQUFDLENBQUEsZUFBRCxHQUFtQixJQUFDLENBQUEscUJBQUQsQ0FBdUIsSUFBSSxDQUFDLGNBQTVCLEVBQTRDLElBQUksQ0FBQyxTQUFqRDtJQUhMOzt5QkFLaEIscUJBQUEsR0FBdUIsU0FBQyxjQUFELEVBQWlCLFNBQWpCO0FBQ3JCLFVBQUE7TUFBQSxNQUFBLEdBQVMsSUFBQyxDQUFBLGtCQUFtQixDQUFBLFNBQUE7TUFDN0IsS0FBQSxHQUFRLHdCQUFBLElBQW9CLGNBQWMsQ0FBQyxLQUFmLENBQXFCLE1BQXJCLENBQXBCLElBQW9EO01BQzVELElBQUcsS0FBSDtlQUNFLEtBQU0sQ0FBQSxDQUFBLEVBRFI7T0FBQSxNQUFBO2VBR0UsR0FIRjs7SUFIcUI7O3lCQVF2QixhQUFBLEdBQWUsU0FBQTtNQUNiLElBQUEsQ0FBdUIsSUFBQyxDQUFBLGFBQXhCO1FBQUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxFQUFBOzthQUNBLElBQUMsQ0FBQSxhQUFhLENBQUM7SUFGRjs7eUJBSWYsU0FBQSxHQUFXLFNBQUE7TUFDVCxJQUFBLENBQXVCLElBQUMsQ0FBQSxhQUF4QjtRQUFBLElBQUMsQ0FBQSxZQUFELENBQUEsRUFBQTs7YUFDQSxJQUFDLENBQUEsYUFBYSxDQUFDO0lBRk47O3lCQUlYLFlBQUEsR0FBYyxTQUFBO0FBQ1osVUFBQTtNQUFBLElBQXlCLElBQUMsQ0FBQSxhQUFELEtBQWtCLE1BQTNDO0FBQUEsZUFBTyxJQUFDLENBQUEsY0FBUjs7TUFFQSxJQUFDLENBQUEsYUFBRCxHQUNFO1FBQUEsY0FBQSxFQUFnQixJQUFoQjtRQUNBLFNBQUEsRUFBVyxJQURYO1FBRUEsU0FBQSxFQUFXLElBRlg7O01BSUYsTUFBQSxHQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQWYsQ0FBQTtNQUNULENBQUEsR0FBSSxJQUFDLENBQUEsV0FBRCxDQUFBLENBQUEsR0FBaUI7TUFDckIsVUFBQSxHQUFpQixJQUFBLE1BQUEsQ0FBTyw0Q0FBUDtNQUNqQixrQkFBQSxHQUF5QixJQUFBLE1BQUEsQ0FBTywrQkFBUDtNQUN6QixvQkFBQSxHQUEyQixJQUFBLE1BQUEsQ0FBTyxjQUFQO01BQzNCLG1CQUFBLEdBQTBCLElBQUEsTUFBQSxDQUFPLHFDQUFQO01BQzFCLG9CQUFBLEdBQTJCLElBQUEsTUFBQSxDQUFPLGtCQUFQO0FBQzNCLGFBQU0sQ0FBQSxJQUFLLENBQVg7UUFDRSxVQUFBLEdBQWEsTUFBTSxDQUFDLG9CQUFQLENBQTRCLENBQTVCO1FBRWIsSUFBRyxDQUFJLElBQUMsQ0FBQSxhQUFhLENBQUMsY0FBdEI7VUFFRSxJQUFHLEdBQUEsR0FBTSxVQUFVLENBQUMsS0FBWCxDQUFpQixVQUFqQixDQUFUO1lBQ0UsSUFBQyxDQUFBLGVBQUQsR0FBbUIsR0FBSSxDQUFBLENBQUE7WUFDdkIsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLEdBQTJCO1lBQzNCLElBQUMsQ0FBQSxhQUFhLENBQUMsY0FBZixHQUFnQyxXQUhsQztXQUFBLE1BTUssSUFBRyxvQkFBb0IsQ0FBQyxJQUFyQixDQUEwQixVQUExQixDQUFIO1lBQ0gsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLEdBQTJCO1lBQzNCLElBQUMsQ0FBQSxhQUFhLENBQUMsY0FBZixHQUFnQyxXQUY3QjtXQVJQOztRQWFBLElBQUcsa0JBQWtCLENBQUMsSUFBbkIsQ0FBd0IsVUFBeEIsQ0FBSDtVQUNFLElBQUMsQ0FBQSxhQUFhLENBQUMsU0FBZixHQUEyQjtVQUMzQixJQUFDLENBQUEsYUFBYSxDQUFDLFNBQWYsR0FBMkI7QUFDM0IsZ0JBSEY7U0FBQSxNQUtLLElBQUcsb0JBQW9CLENBQUMsSUFBckIsQ0FBMEIsVUFBMUIsQ0FBSDtVQUNILElBQUMsQ0FBQSxhQUFhLENBQUMsU0FBZixHQUEyQjtVQUMzQixJQUFDLENBQUEsYUFBYSxDQUFDLFNBQWYsR0FBMkI7QUFDM0IsZ0JBSEc7U0FBQSxNQU1BLElBQUcsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLEtBQTRCLE1BQTVCLElBQXNDLG1CQUFtQixDQUFDLElBQXBCLENBQXlCLFVBQXpCLENBQXpDO1VBQ0gsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLEdBQTJCO0FBQzNCLGlCQUFPLElBQUMsQ0FBQSxjQUZMOztRQUlMLENBQUE7TUEvQkY7TUFpQ0EsSUFBRyxJQUFDLENBQUEsYUFBYSxDQUFDLFNBQWYsS0FBNEIsT0FBNUIsSUFBd0MsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLEtBQTRCLE1BQXZFO1FBQ0UsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLEdBQTJCLFdBRDdCOzthQUdBLElBQUMsQ0FBQTtJQW5EVzs7eUJBcURkLGFBQUEsR0FBZSxTQUFBO0FBQ2IsVUFBQTthQUFBLElBQUMsQ0FBQSxtQkFBRCxJQUFDLENBQUEsaUJBQW1CLENBQU8sSUFBQyxDQUFBLGNBQVIsR0FDbEIsQ0FBQyxDQUFDLENBQUEsR0FBSSxJQUFDLENBQUEsUUFBRCxDQUFBLENBQUwsQ0FBQSxJQUFzQixJQUFDLENBQUEsZUFBZ0IsQ0FBQSxDQUFBLENBQXhDLENBQUEsSUFDQSxDQUFDLEVBQUUsQ0FBQyxVQUFILENBQWMsSUFBQyxDQUFBLFdBQUQsQ0FBQSxDQUFBLEdBQWlCLFNBQS9CLENBQUEsSUFBOEMsT0FBL0MsQ0FEQSxJQUVBLElBQUMsQ0FBQSxXQUFELENBQUEsQ0FIa0IsR0FBQTtJQURQOzt5QkFNZixRQUFBLEdBQVUsU0FBQTtBQUNSLFVBQUE7YUFBQSxJQUFDLENBQUEsY0FBRCxJQUFDLENBQUEsWUFBaUIsSUFBQyxDQUFBLFNBQUQsS0FBYyxNQUFqQixHQUVWLENBQUksSUFBQyxDQUFBLFVBQUQsQ0FBQSxDQUFQLEdBQ0UsSUFERixHQUVRLENBQUEsT0FBQSxHQUFVLElBQUMsQ0FBQSxVQUFELENBQUEsQ0FBYSxDQUFDLEtBQWQsQ0FBb0IsbUJBQXBCLENBQVYsQ0FBSCxHQUNBLE9BQVEsQ0FBQSxDQUFBLENBQVIsS0FBYyxNQUFkLElBQXlCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQix5QkFBaEIsQ0FBNUIsR0FDRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IseUJBQWhCLENBREYsR0FFUSxPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsTUFBZCxJQUF5QixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IseUJBQWhCLENBQTVCLEdBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLHlCQUFoQixDQURHLEdBRUcsSUFBQyxDQUFBLGFBQUQsQ0FBQSxDQUFBLEtBQW9CLFVBQXBCLElBQWtDLENBQUMsQ0FBSSxJQUFDLENBQUEsYUFBRCxDQUFBLENBQUosSUFBeUIsT0FBUSxDQUFBLENBQUEsQ0FBUixLQUFjLE1BQXZDLElBQWtELElBQUMsQ0FBQSxTQUFELENBQUEsQ0FBQSxLQUFnQixNQUFuRSxDQUFyQyxHQUNILFVBREcsR0FFRyxPQUFRLENBQUEsQ0FBQSxDQUFSLEtBQWMsTUFBakIsR0FDSCxPQURHLEdBR0gsTUFWQyxHQVdHLENBQUEsT0FBQSxHQUFVLElBQUMsQ0FBQSxVQUFELENBQUEsQ0FBYSxDQUFDLEtBQWQsQ0FBb0IsY0FBcEIsQ0FBVixDQUFILEdBQ0gsT0FBUSxDQUFBLENBQUEsQ0FETCxHQUFBLE1BZlEsR0FBQTtJQURQOzt5QkFtQlYsV0FBQSxHQUFhLFNBQUE7TUFDWCxJQUFHLEVBQUUsQ0FBQyxVQUFILENBQWMsSUFBQyxDQUFBLFdBQUQsQ0FBQSxDQUFBLEdBQWlCLE9BQS9CLENBQUg7ZUFDRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IseUJBQWhCLENBQUEsSUFBOEMsT0FEaEQ7T0FBQSxNQUVLLElBQUcsRUFBRSxDQUFDLFVBQUgsQ0FBYyxJQUFDLENBQUEsV0FBRCxDQUFBLENBQUEsR0FBaUIsT0FBL0IsQ0FBSDtlQUNILElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQix5QkFBaEIsQ0FBQSxJQUE4QyxRQUQzQztPQUFBLE1BRUEsSUFBRyxFQUFFLENBQUMsVUFBSCxDQUFjLElBQUMsQ0FBQSxXQUFELENBQUEsQ0FBQSxHQUFpQixXQUEvQixDQUFIO2VBQ0gsV0FERztPQUFBLE1BQUE7ZUFHSCxLQUhHOztJQUxNOzt5QkFVYixRQUFBLEdBQVUsU0FBQTtBQUNSLFVBQUE7TUFBQSxJQUFBLEdBQU8sSUFBSTthQUNYLElBQUksQ0FBQyxRQUFMLENBQUE7SUFGUTs7Ozs7QUFwSmQiLCJzb3VyY2VzQ29udGVudCI6WyJmcyA9IHJlcXVpcmUoJ2ZzJylcblV0aWxpdHkgPSByZXF1aXJlICcuL3V0aWxpdHknXG5cbm1vZHVsZS5leHBvcnRzID1cbiAgIyBQcm92aWRlcyBpbmZvcm1hdGlvbiBhYm91dCB0aGUgc291cmNlIGNvZGUgYmVpbmcgdGVzdGVkXG4gIGNsYXNzIFNvdXJjZUluZm9cbiAgICBmcmFtZXdvcmtMb29rdXA6XG4gICAgICB0ZXN0OiAgICAndGVzdCdcbiAgICAgIHNwZWM6ICAgICdyc3BlYydcbiAgICAgIHJzcGVjOiAgICdyc3BlYydcbiAgICAgIGZlYXR1cmU6ICdjdWN1bWJlcidcbiAgICAgIG1pbml0ZXN0OiAnbWluaXRlc3QnXG5cbiAgICByZWdFeHBGb3JUZXN0U3R5bGU6XG4gICAgICB1bml0OiAvZGVmXFxzKC4qPykkL1xuICAgICAgc3BlYzogLyg/OlwifCcpKC4qPykoPzpcInwnKS9cblxuICAgIHByb2plY3RQYXRoOiAtPlxuICAgICAgZGVmYXVsdFBhdGggPSBhdG9tLnByb2plY3QuZ2V0UGF0aHMoKVswXVxuICAgICAgaWYgQGZpbGVQYXRoKClcbiAgICAgICAgZm9yIHBhdGggaW4gYXRvbS5wcm9qZWN0LmdldFBhdGhzKClcbiAgICAgICAgICBpZiBAZmlsZVBhdGgoKS5pbmRleE9mKHBhdGgpID09IDBcbiAgICAgICAgICAgIHJldHVybiBwYXRoXG4gICAgICAgIHJldHVybiBkZWZhdWx0UGF0aFxuICAgICAgZWxzZVxuICAgICAgICBkZWZhdWx0UGF0aFxuXG4gICAgYWN0aXZlRmlsZTogLT5cbiAgICAgIEBfYWN0aXZlRmlsZSB8fD0gKGZwID0gQGZpbGVQYXRoKCkpIGFuZCBhdG9tLnByb2plY3QucmVsYXRpdml6ZShmcClcblxuICAgIGN1cnJlbnRMaW5lOiAtPlxuICAgICAgQF9jdXJyZW50TGluZSB8fD0gdW5sZXNzIEBfY3VycmVudExpbmVcbiAgICAgICAgZWRpdG9yID0gYXRvbS53b3Jrc3BhY2UuZ2V0QWN0aXZlVGV4dEVkaXRvcigpXG4gICAgICAgIGN1cnNvciA9IGVkaXRvciBhbmQgZWRpdG9yLmdldExhc3RDdXJzb3IoKVxuICAgICAgICBpZiBjdXJzb3JcbiAgICAgICAgICBjdXJzb3IuZ2V0QnVmZmVyUm93KCkgKyAxXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBudWxsXG5cbiAgICBtaW5pdGVzdFJlZ0V4cDogLT5cbiAgICAgIHJldHVybiBAX21pbml0ZXN0UmVnRXhwIGlmIEBfbWluaXRlc3RSZWdFeHAgIT0gdW5kZWZpbmVkXG4gICAgICBmaWxlID0gQGZpbGVBbmFseXNpcygpXG4gICAgICBAX21pbml0ZXN0UmVnRXhwID0gQGV4dHJhY3RNaW5pdGVzdFJlZ0V4cChmaWxlLnRlc3RIZWFkZXJMaW5lLCBmaWxlLnRlc3RTdHlsZSlcblxuICAgIGV4dHJhY3RNaW5pdGVzdFJlZ0V4cDogKHRlc3RIZWFkZXJMaW5lLCB0ZXN0U3R5bGUpLT5cbiAgICAgIHJlZ0V4cCA9IEByZWdFeHBGb3JUZXN0U3R5bGVbdGVzdFN0eWxlXVxuICAgICAgbWF0Y2ggPSB0ZXN0SGVhZGVyTGluZT8gYW5kIHRlc3RIZWFkZXJMaW5lLm1hdGNoKHJlZ0V4cCkgb3IgbnVsbFxuICAgICAgaWYgbWF0Y2hcbiAgICAgICAgbWF0Y2hbMV1cbiAgICAgIGVsc2VcbiAgICAgICAgXCJcIlxuXG4gICAgZmlsZUZyYW1ld29yazogLT5cbiAgICAgIEBmaWxlQW5hbHlzaXMoKSB1bmxlc3MgQF9maWxlQW5hbHlzaXNcbiAgICAgIEBfZmlsZUFuYWx5c2lzLmZyYW1ld29ya1xuXG4gICAgdGVzdFN0eWxlOiAtPlxuICAgICAgQGZpbGVBbmFseXNpcygpIHVubGVzcyBAX2ZpbGVBbmFseXNpc1xuICAgICAgQF9maWxlQW5hbHlzaXMudGVzdFN0eWxlXG5cbiAgICBmaWxlQW5hbHlzaXM6IC0+XG4gICAgICByZXR1cm4gQF9maWxlQW5hbHlzaXMgaWYgQF9maWxlQW5hbHlzaXMgIT0gdW5kZWZpbmVkXG5cbiAgICAgIEBfZmlsZUFuYWx5c2lzID1cbiAgICAgICAgdGVzdEhlYWRlckxpbmU6IG51bGxcbiAgICAgICAgdGVzdFN0eWxlOiBudWxsXG4gICAgICAgIGZyYW1ld29yazogbnVsbFxuXG4gICAgICBlZGl0b3IgPSBhdG9tLndvcmtzcGFjZS5nZXRBY3RpdmVUZXh0RWRpdG9yKClcbiAgICAgIGkgPSBAY3VycmVudExpbmUoKSAtIDFcbiAgICAgIHNwZWNSZWdFeHAgPSBuZXcgUmVnRXhwKC9cXGIoPzpzaG91bGR8dGVzdHxpdClcXHMrWydcIl0oLiopWydcIl1cXHMrZG9cXGIvKVxuICAgICAgcnNwZWNSZXF1aXJlUmVnRXhwID0gbmV3IFJlZ0V4cCgvXnJlcXVpcmUuKihyYWlsc3xzcGVjKV9oZWxwZXIvKVxuICAgICAgcnNwZWNBc3NlcnRpb25SZWdFeHAgPSBuZXcgUmVnRXhwKC9eXFxzKmV4cGVjdFxcKC8pXG4gICAgICBtaW5pdGVzdENsYXNzUmVnRXhwID0gbmV3IFJlZ0V4cCgvY2xhc3NcXHMoLiopPChcXHM/fFxccyspTWluaXRlc3Q6OlRlc3QvKVxuICAgICAgbWluaXRlc3RNZXRob2RSZWdFeHAgPSBuZXcgUmVnRXhwKC9eKFxccyspZGVmXFxzKC4qKSQvKVxuICAgICAgd2hpbGUgaSA+PSAwXG4gICAgICAgIHNvdXJjZUxpbmUgPSBlZGl0b3IubGluZVRleHRGb3JCdWZmZXJSb3coaSlcblxuICAgICAgICBpZiBub3QgQF9maWxlQW5hbHlzaXMudGVzdEhlYWRlckxpbmVcbiAgICAgICAgICAjIGNoZWNrIGlmIGl0IGlzIHJzcGVjIG9yIG1pbml0ZXN0IHNwZWNcbiAgICAgICAgICBpZiByZXMgPSBzb3VyY2VMaW5lLm1hdGNoKHNwZWNSZWdFeHApXG4gICAgICAgICAgICBAX21pbml0ZXN0UmVnRXhwID0gcmVzWzFdXG4gICAgICAgICAgICBAX2ZpbGVBbmFseXNpcy50ZXN0U3R5bGUgPSAnc3BlYydcbiAgICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLnRlc3RIZWFkZXJMaW5lID0gc291cmNlTGluZVxuXG4gICAgICAgICAgIyBjaGVjayBpZiBpdCBpcyBtaW5pdGVzdCB1bml0XG4gICAgICAgICAgZWxzZSBpZiBtaW5pdGVzdE1ldGhvZFJlZ0V4cC50ZXN0KHNvdXJjZUxpbmUpXG4gICAgICAgICAgICBAX2ZpbGVBbmFseXNpcy50ZXN0U3R5bGUgPSAndW5pdCdcbiAgICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLnRlc3RIZWFkZXJMaW5lID0gc291cmNlTGluZVxuXG4gICAgICAgICMgaWYgaXQgaXMgc3BlYyBhbmQgaGFzIHJlcXVpcmUgc3BlY19oZWxwZXIgd2hpY2ggbWVhbnMgaXQgaXMgcnNwZWMgc3BlY1xuICAgICAgICBpZiByc3BlY1JlcXVpcmVSZWdFeHAudGVzdChzb3VyY2VMaW5lKVxuICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLnRlc3RTdHlsZSA9ICdzcGVjJ1xuICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLmZyYW1ld29yayA9ICdyc3BlYydcbiAgICAgICAgICBicmVha1xuXG4gICAgICAgIGVsc2UgaWYgcnNwZWNBc3NlcnRpb25SZWdFeHAudGVzdChzb3VyY2VMaW5lKVxuICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLnRlc3RTdHlsZSA9ICdzcGVjJ1xuICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLmZyYW1ld29yayA9ICdyc3BlYydcbiAgICAgICAgICBicmVha1xuXG4gICAgICAgICMgaWYgaXQgaXMgdW5pdCB0ZXN0IGFuZCBpbmhlcml0IGZyb20gTWluaXRlc3Q6OlVuaXRcbiAgICAgICAgZWxzZSBpZiBAX2ZpbGVBbmFseXNpcy50ZXN0U3R5bGUgPT0gJ3VuaXQnICYmIG1pbml0ZXN0Q2xhc3NSZWdFeHAudGVzdChzb3VyY2VMaW5lKVxuICAgICAgICAgIEBfZmlsZUFuYWx5c2lzLmZyYW1ld29yayA9ICdtaW5pdGVzdCdcbiAgICAgICAgICByZXR1cm4gQF9maWxlQW5hbHlzaXNcblxuICAgICAgICBpLS1cblxuICAgICAgaWYgQF9maWxlQW5hbHlzaXMuZnJhbWV3b3JrICE9ICdyc3BlYycgYW5kIEBfZmlsZUFuYWx5c2lzLnRlc3RTdHlsZSA9PSAnc3BlYydcbiAgICAgICAgQF9maWxlQW5hbHlzaXMuZnJhbWV3b3JrID0gJ21pbml0ZXN0J1xuXG4gICAgICBAX2ZpbGVBbmFseXNpc1xuXG4gICAgdGVzdEZyYW1ld29yazogLT5cbiAgICAgIEBfdGVzdEZyYW1ld29yayB8fD0gdW5sZXNzIEBfdGVzdEZyYW1ld29ya1xuICAgICAgICAoKHQgPSBAZmlsZVR5cGUoKSkgYW5kIEBmcmFtZXdvcmtMb29rdXBbdF0pIG9yXG4gICAgICAgIChmcy5leGlzdHNTeW5jKEBwcm9qZWN0UGF0aCgpICsgJy8ucnNwZWMnKSBhbmQgJ3JzcGVjJykgb3JcbiAgICAgICAgQHByb2plY3RUeXBlKClcblxuICAgIGZpbGVUeXBlOiAtPlxuICAgICAgQF9maWxlVHlwZSB8fD0gaWYgQF9maWxlVHlwZSA9PSB1bmRlZmluZWRcblxuICAgICAgICBpZiBub3QgQGFjdGl2ZUZpbGUoKVxuICAgICAgICAgIG51bGxcbiAgICAgICAgZWxzZSBpZiBtYXRjaGVzID0gQGFjdGl2ZUZpbGUoKS5tYXRjaCgvXyh0ZXN0fHNwZWMpXFwucmIkLylcbiAgICAgICAgICBpZiBtYXRjaGVzWzFdID09ICd0ZXN0JyBhbmQgYXRvbS5jb25maWcuZ2V0KFwicnVieS10ZXN0LnRlc3RGcmFtZXdvcmtcIilcbiAgICAgICAgICAgIGF0b20uY29uZmlnLmdldChcInJ1YnktdGVzdC50ZXN0RnJhbWV3b3JrXCIpXG4gICAgICAgICAgZWxzZSBpZiBtYXRjaGVzWzFdID09ICdzcGVjJyBhbmQgYXRvbS5jb25maWcuZ2V0KFwicnVieS10ZXN0LnNwZWNGcmFtZXdvcmtcIilcbiAgICAgICAgICAgIGF0b20uY29uZmlnLmdldChcInJ1YnktdGVzdC5zcGVjRnJhbWV3b3JrXCIpXG4gICAgICAgICAgZWxzZSBpZiBAZmlsZUZyYW1ld29yaygpID09ICdtaW5pdGVzdCcgb3IgKG5vdCBAZmlsZUZyYW1ld29yaygpIGFuZCBtYXRjaGVzWzFdID09ICd0ZXN0JyBhbmQgQHRlc3RTdHlsZSgpID09ICdzcGVjJylcbiAgICAgICAgICAgICdtaW5pdGVzdCdcbiAgICAgICAgICBlbHNlIGlmIG1hdGNoZXNbMV0gPT0gJ3NwZWMnXG4gICAgICAgICAgICAncnNwZWMnXG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgJ3Rlc3QnXG4gICAgICAgIGVsc2UgaWYgbWF0Y2hlcyA9IEBhY3RpdmVGaWxlKCkubWF0Y2goL1xcLihmZWF0dXJlKSQvKVxuICAgICAgICAgIG1hdGNoZXNbMV1cblxuICAgIHByb2plY3RUeXBlOiAtPlxuICAgICAgaWYgZnMuZXhpc3RzU3luYyhAcHJvamVjdFBhdGgoKSArICcvdGVzdCcpXG4gICAgICAgIGF0b20uY29uZmlnLmdldChcInJ1YnktdGVzdC50ZXN0RnJhbWV3b3JrXCIpIHx8ICd0ZXN0J1xuICAgICAgZWxzZSBpZiBmcy5leGlzdHNTeW5jKEBwcm9qZWN0UGF0aCgpICsgJy9zcGVjJylcbiAgICAgICAgYXRvbS5jb25maWcuZ2V0KFwicnVieS10ZXN0LnNwZWNGcmFtZXdvcmtcIikgfHwgJ3JzcGVjJ1xuICAgICAgZWxzZSBpZiBmcy5leGlzdHNTeW5jKEBwcm9qZWN0UGF0aCgpICsgJy9mZWF0dXJlcycpXG4gICAgICAgICdjdWN1bWJlcidcbiAgICAgIGVsc2VcbiAgICAgICAgbnVsbFxuXG4gICAgZmlsZVBhdGg6IC0+XG4gICAgICB1dGlsID0gbmV3IFV0aWxpdHlcbiAgICAgIHV0aWwuZmlsZVBhdGgoKVxuIl19
