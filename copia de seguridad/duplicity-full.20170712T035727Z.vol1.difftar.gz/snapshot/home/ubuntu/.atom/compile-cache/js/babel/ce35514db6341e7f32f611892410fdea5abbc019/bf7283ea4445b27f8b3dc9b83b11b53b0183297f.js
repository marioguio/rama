Object.defineProperty(exports, '__esModule', {
  value: true
});

// Automatically added

// From providers

// Automatically added

// From providers

// Automatically added

// From providers
// <-- legacy
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIvaG9tZS91YnVudHUvLmF0b20vcGFja2FnZXMvbGludGVyL2xpYi90eXBlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbXX0=